"""
evaluator.py - Evaluador de ventana deslizante de 60s con pre-gate y puntuación de interés/drama.
Cero APIs externas de pago, cero modelos pesados en vigilancia, CPU < 0.1%.
"""

import re
import unicodedata
from typing import List, Dict, Any, Tuple, Optional

# Palabras vacías que no deben tomarse como nombres propios
STOPWORDS_ES = {
    "el", "la", "los", "las", "un", "una", "unos", "unas", "de", "del", "a", "al", "en", "por",
    "para", "con", "sin", "sobre", "entre", "hasta", "desde", "hacia", "durante", "según",
    "yo", "tú", "él", "ella", "usted", "nosotros", "vosotros", "ellos", "ellas", "ustedes",
    "mi", "tu", "su", "nuestro", "vuestro", "este", "esta", "estos", "estas", "ese", "esa",
    "esos", "esas", "aquel", "aquella", "aquellos", "aquellas", "que", "qué", "quien", "quién",
    "cual", "cuál", "cuyo", "donde", "dónde", "cuando", "cuándo", "como", "cómo", "cuanto",
    "cuánto", "pero", "mas", "aunque", "sino", "porque", "pues", "ya", "si", "sí", "no",
    "bien", "mal", "muy", "más", "menos", "tan", "tanto", "así", "aquí", "ahí", "allí",
    "acá", "allá", "ahora", "antes", "después", "luego", "siempre", "nunca", "jamás",
    "ayer", "hoy", "mañana", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado",
    "domingo", "bueno", "claro", "vale", "oigan", "hola", "adiós", "gracias", "youtube", "vivo",
    "directo", "canal", "like", "suscríbete", "comenta", "amigos", "gente", "todos", "todas",
    "entonces", "también", "además", "igual", "bueno", "mira", "oye", "miren", "cállate", "escuchen",
    "espera", "vamos", "venga", "tengo", "puedo", "saben", "vean", "tienen", "creo", "pienso", "digo"
}

KEYWORDS_CONFESSION = [
    "confieso", "confesion", "la verdad es", "te voy a decir", "nadie sabe", "nunca lo dije",
    "secreto", "revelo", "descubrio", "traicion", "mentira", "engano", "exclusiva", "realidad",
    "sinceramente", "te juro", "no te miento", "ocultar", "ocultaron", "revelacion", "admito",
    "lo admito", "me equivoque", "hice trampa", "era mentira", "lo sabia", "te soy honesto",
    "la neta", "al chile", "en confianza", "me arrepiento", "no lo habia contado", "primicia"
]

KEYWORDS_CONFLICT = [
    "callate", "no te permito", "mentiroso", "mentirosa", "pelea", "discutir", "discusion",
    "renuncia", "fraude", "denuncia", "demanda", "gritos", "verguenza", "abuso", "ataque",
    "enemigo", "odio", "violencia", "traidor", "falso", "falsa", "basta ya", "te pasaste",
    "hipocrita", "cara dura", "sinverguenza", "estafador", "injusticia", "cobarde", "fuera de aqui",
    "no te metas", "calmate", "deja de hablar", "callate la boca", "irrespetuoso",
    "tiradera", "bobo", "se prendio", "humillo", "humillacion", "cancelado", "cancelada",
    "escandalo", "polemica", "pleito", "chisme", "bronca", "troleo", "ragequit", "factos"
]

KEYWORDS_SHOCK = [
    "increible", "impactante", "locura", "dios mio", "brutal", "wtf", "no me lo creo",
    "insolito", "peligro", "urgente", "alerta", "grave", "muerte", "tragedia", "catastrofe",
    "terrible", "espeluznante", "inedito", "pesadilla", "shock", "no puede ser", "estoy temblando",
    "se cayo", "se rompio", "accidente", "emergencia", "historico", "inaudito",
    "viral", "rompio", "la rompi", "se viralizo", "barbaridad", "madre mia", "ostia", "hostia",
    "no manches", "no mames", "que vaina", "que baina", "de locos", "clutch", "remontada",
    "basado", "fuego", "heavy", "montro"
]

KEYWORDS_HUMOR = [
    "jajaja", "jaja", "jeje", "risas", "me muero de risa", "parti de risa", "gracioso",
    "ridiculo", "broma", "troleo", "chiste", "payaso", "meme", "casi me ahogo", "verguenza ajena",
    "mori", "me meo", "de locos", "coro", "vacilon", "me rei", "cagado de risa", "panas",
    "klk", "que lo que", "wey", "no mms", "gg", "ez", "payasada", "me mato", "que risa"
]

CATEGORY_KEYWORDS = (
    ("conflict", KEYWORDS_CONFLICT),
    ("confession", KEYWORDS_CONFESSION),
    ("shock", KEYWORDS_SHOCK),
    ("humor", KEYWORDS_HUMOR),
)
ALL_EMOTIONAL_KEYWORDS = KEYWORDS_CONFLICT + KEYWORDS_CONFESSION + KEYWORDS_SHOCK + KEYWORDS_HUMOR


def strip_accents(s: str) -> str:
    """Elimina tildes para búsqueda léxica robusta."""
    return ''.join(c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn')


def _count_keyword_hits(norm_text: str, keywords: List[str]) -> int:
    """Cuenta coincidencias léxicas normalizadas respetando límites en tokens cortos."""
    hits = 0
    for kw in keywords:
        kw_norm = strip_accents(kw.lower())
        if len(kw_norm) <= 3 and " " not in kw_norm:
            if re.search(rf"\b{re.escape(kw_norm)}\b", norm_text):
                hits += 1
        elif kw_norm in norm_text:
            hits += 1
    return hits


def classify_dominant_category(text: str) -> Tuple[str, int]:
    """Clasifica la categoría dominante del texto usando jerga y palabras clave sin tildes."""
    if not text or not text.strip():
        return "normal", 0
    norm_text = strip_accents(text.lower())
    best_cat = "normal"
    best_hits = 0
    for cat, kw_list in CATEGORY_KEYWORDS:
        hits = _count_keyword_hits(norm_text, kw_list)
        if hits > best_hits:
            best_hits = hits
            best_cat = cat
    return best_cat, best_hits


def extract_protagonists(text: str) -> List[str]:
    """
    Deduce nombres propios o protagonistas por contexto y patrones vocativos/menciones.
    """
    protagonists = []
    
    # 1. Patrones vocativos o directos: 'mira Juan', 'oye Maria', 'dijo Carlos', 'pero Carlos'
    vocative_patterns = [
        r'\b(?:mira|oye|dijo|dice|con|contra|a|de|sobre|para|pero|que|y|ni|señor|señora|don|doña)\s+([A-ZÁÉÍÓÚÑ][a-záéíóúñ]{2,15})\b',
        r'\b@([a-zA-Z0-9_]{3,20})\b'
    ]
    
    for pattern in vocative_patterns:
        matches = re.findall(pattern, text)
        for m in matches:
            clean_name = m.strip()
            if clean_name.lower() not in STOPWORDS_ES and len(clean_name) > 2:
                if clean_name not in protagonists:
                    protagonists.append(clean_name)
                    
    # 2. Palabras en mayúscula que NO estén inmediatamente después de un punto
    # (es decir, en medio de la oración, típico de nombres propios)
    mid_sentence_caps = re.findall(r'(?<![.?!]\s)\b([A-ZÁÉÍÓÚÑ][a-záéíóúñ]{2,15})\b', text)
    for w in mid_sentence_caps:
        if w.lower() not in STOPWORDS_ES and len(w) > 2:
            if w not in protagonists:
                protagonists.append(w)
            
    return protagonists[:3]


def _truncate_whole_words(text_val: str, max_len: int = 52) -> str:
    """Trunca a max_len caracteres respetando palabras completas."""
    s_clean = re.sub(r"\s+", " ", text_val).strip()
    if len(s_clean) <= max_len:
        return s_clean
    cut_limit = max_len - 3
    cut = s_clean[:cut_limit]
    if cut_limit < len(s_clean) and s_clean[cut_limit] != " " and " " in cut:
        word_cut = cut.rsplit(" ", 1)[0].rstrip(" ,;:-")
        if len(word_cut) >= 12:
            cut = word_cut
    return cut.rstrip(" ,;:-") + "..."


def generate_hook_title(dominant_category: str, protagonists: List[str], text: str) -> str:
    """
    Genera un título gancho viral de alta retención basado en lo que REALMENTE dijo el hablante.
    Puntúa cada oración por keywords emocionales, signos ?/!, protagonistas y longitud ideal (22-65 chars),
    truncando a máx 52 chars respetando palabras completas.
    """
    clean = re.sub(r'\b(eh+|ah+|um+|uh+)\b', '', text, flags=re.IGNORECASE)
    clean = re.sub(r'\s+', ' ', clean).strip()
    sentences = [s.strip() for s in re.split(r'(?<=[.?!])\s+|\n+', clean) if len(s.strip()) >= 8]

    if not sentences:
        sample_quote = _truncate_whole_words(clean or text, max_len=52)
    else:
        prot_lowers = [p.lower() for p in protagonists if p]
        best_sent = sentences[0]
        best_score = float("-inf")
        for s in sentences:
            s_norm = strip_accents(s.lower())
            kw_hits = _count_keyword_hits(s_norm, ALL_EMOTIONAL_KEYWORDS)
            has_punct = 1 if any(ch in s for ch in ("?", "¿", "!", "¡")) else 0
            prot_hits = sum(1 for p in prot_lowers if p in s.lower())
            s_len = len(s)
            if 22 <= s_len <= 65:
                len_score = 2.0
            elif 12 <= s_len < 22:
                len_score = 0.5
            elif s_len > 90:
                len_score = -0.5
            else:
                len_score = 1.0

            sent_score = (kw_hits * 3.0) + (has_punct * 2.0) + (prot_hits * 1.5) + len_score
            if sent_score > best_score:
                best_score = sent_score
                best_sent = s

        sample_quote = _truncate_whole_words(best_sent, max_len=52)

    # Formar titular con la cita real entre comillas
    if dominant_category == "conflict":
        return f"¡MÁXIMA TENSIÓN! \"{sample_quote}\""
    elif dominant_category == "confession":
        return f"¡CONFESIÓN EN DIRECTO! \"{sample_quote}\""
    elif dominant_category == "shock":
        return f"¡NO PUEDE SER! \"{sample_quote}\""
    elif dominant_category == "humor":
        return f"¡MOMENTO ÉPICO! \"{sample_quote}\""
    else:
        return f"¡MOMENTO CLAVE! \"{sample_quote}\""


def evaluate_harvest_window(
    acoustic_metrics: Dict[str, Any],
    entries: Optional[List[Dict[str, Any]]] = None,
    custom_threshold: float = 7.0
) -> Dict[str, Any]:
    """
    MODO COSECHA CONTINUA (PROHIBIDO DESCARTAR CICLOS EN ESTA VERSIÓN):
    Evalúa la sub-ventana seleccionada directamente por métricas acústicas en RAM (/dev/shm)
    y opcionalmente enriquece con subtítulos/transcripción si existen.
    
    El estado SIEMPRE es 'harvest' (trigger garantizado ininterrumpido).
    """
    peak_level = float(acoustic_metrics.get("peak_level", 0.0))
    rms_energy = float(acoustic_metrics.get("rms_energy", 0.0))
    dynamic_variance = float(acoustic_metrics.get("dynamic_variance", 0.0))
    no_speech_prob = float(acoustic_metrics.get("no_speech_prob", 0.0))
    
    full_text = " ".join([e.get("text", "").strip() for e in (entries or []) if e.get("text")]).strip()
    words = [w for w in full_text.split() if len(w) > 1]
    word_count = len(words)
    has_subtitles = word_count >= 5

    protagonists = extract_protagonists(full_text) if has_subtitles else []

    # Normalización de notas escaladas entre 5.0 y 9.8 según los picos reales y ViralBrain
    base_score = 5.2
    peak_points = peak_level * 2.8
    rms_points = min(rms_energy * 15.0, 1.0)
    var_points = min(dynamic_variance * 150.0, 0.5)
    text_bonus = 0.5 if has_subtitles else 0.0
    final_score = round(min(max(base_score + peak_points + rms_points + var_points + text_bonus, 5.0), 9.8), 1)

    # Evaluación avanzada con Mini-IA ViralBrain (Híbrido Universal + Calibración de Usuario)
    viral_meta = None
    try:
        from viral_brain import get_viral_brain
        brain = get_viral_brain()
        brain.update_rms_history(rms_energy)
        dur = float(acoustic_metrics.get("duration_sec", 60.0))
        viral_pred = brain.predict(
            acoustic_metrics,
            full_text,
            duration_sec=dur,
            no_speech_prob=no_speech_prob
        )
        final_score = viral_pred["score"]
        viral_meta = viral_pred
    except Exception:
        pass

    # Clasificación real por categoría dominante para el titular gancho
    dominant_cat, _ = classify_dominant_category(full_text)
    effective_cat = "shock" if (dominant_cat == "normal" and peak_level >= 0.75) else dominant_cat

    # Generar título gancho contextual o acústico
    if has_subtitles:
        hook_title = generate_hook_title(effective_cat, protagonists, full_text)
    else:
        if peak_level >= 0.85:
            hook_title = f"¡CLÍMAX TOTAL EN DIRECTO! Pico acústico récord ({peak_level:.2f})"
        elif peak_level >= 0.70:
            hook_title = f"¡MOMENTO EXPLOSIVO! Reacción enérgica en vivo ({peak_level:.2f})"
        elif rms_energy >= 0.04:
            hook_title = f"¡MOMENTO DE ALTA ACTIVIDAD! Sonido intenso ({peak_level:.2f})"
        else:
            hook_title = f"¡MOMENTO DESTACADO EN VIVO! Clímax de la ventana ({peak_level:.2f})"

    reason_str = f"Cosecha continua: Máxima actividad en ventana (Pico: {peak_level:.2f}, RMS: {rms_energy:.4f}, Dinamismo: {dynamic_variance:.6f})"
    if viral_meta and viral_meta.get("is_calibrated"):
        reason_str += f" | IA Calibrada ({viral_meta['n_samples']} clips)"

    return {
        "score": final_score,
        "status": "harvest",
        "dominant_category": effective_cat,
        "peak_level": peak_level,
        "rms_energy": rms_energy,
        "dynamic_variance": dynamic_variance,
        "spectral_flux": float(acoustic_metrics.get("spectral_flux", 0.0)),
        "has_subtitles": has_subtitles,
        "reason": reason_str,
        "protagonistas": protagonists,
        "titulo_gancho": hook_title,
        "texto_completo": full_text,
        "palabras": word_count,
        "max_peak": peak_level,
        "viral_brain": viral_meta
    }


def evaluate_window(
    entries: List[Dict[str, Any]],
    audio_peaks: Optional[List[Dict[str, Any]]] = None,
    custom_threshold: float = 7.0,
    transcription_segments: Optional[List[Dict[str, Any]]] = None,
    asr_mode: bool = False
) -> Dict[str, Any]:
    """
    Evalúa ventana garantizando trigger de cosecha continua sin descartes de ciclos.
    """
    full_text = " ".join([e.get("text", "").strip() for e in (entries or []) if e.get("text")]).strip()
    words = [w for w in full_text.split() if len(w) > 1]
    word_count = len(words)
    
    peaks_from_entries = [float(e.get("peak", 0.0)) for e in (entries or []) if "peak" in e]
    peaks_from_audio = [float(p.get("peak", 0.0)) for p in (audio_peaks or []) if "peak" in p]
    all_peaks = peaks_from_entries + peaks_from_audio
    max_peak = max(all_peaks) if all_peaks else 0.50

    protagonists = extract_protagonists(full_text)
    dominant_cat, _ = classify_dominant_category(full_text)
    effective_cat = "shock" if (dominant_cat == "normal" and max_peak >= 0.75) else dominant_cat
    if word_count >= 5:
        hook_title = generate_hook_title(effective_cat, protagonists, full_text)
    else:
        hook_title = f"¡MOMENTO DESTACADO EN DIRECTO! Pico ({max_peak:.2f})"

    score = round(min(max(5.0 + (max_peak * 3.5), 5.0), 10.0), 1)

    return {
        "score": score,
        "status": "harvest",
        "peak_level": round(max_peak, 4),
        "rms_energy": 0.03,
        "dynamic_variance": 0.0001,
        "has_subtitles": word_count >= 5,
        "dominant_category": effective_cat,
        "reason": f"Cosecha continua: Actividad detectada ({word_count} palabras, pico {max_peak:.2f})",
        "protagonistas": protagonists,
        "titulo_gancho": hook_title,
        "texto_completo": full_text,
        "palabras": word_count,
        "max_peak": max_peak,
        "transcripcion_segmentos": transcription_segments or [],
        "modo_transcripcion": "harvest_continuous"
    }


if __name__ == "__main__":
    # Test unitario rápido
    sample_dialogue = [
        {"text": "Miren, les voy a decir la verdad porque ya no puedo callármelo más.", "peak": 0.55},
        {"text": "Nadie sabe esto, pero Carlos me traicionó por la espalda y robó el proyecto.", "peak": 0.88},
        {"text": "¡Es mentira! ¡Cállate la boca, no te permito que me ensucies así frente a todos!", "peak": 0.95},
        {"text": "¡Tengo las pruebas aquí mismo y las voy a mostrar ahora!", "peak": 0.90}
    ]
    res = evaluate_window(sample_dialogue)
    print("Test Resultado:")
    print(f"Score: {res['score']}/10")
    print(f"Status: {res['status']}")
    print(f"Gancho: {res['titulo_gancho']}")
    print(f"Protagonistas: {res['protagonistas']}")
    print(f"Razón: {res['reason']}")
