"""
extractor.py - Extractor Rewind con compensación de latencia de 12 segundos (Pre-Roll).
Empaqueta 60-65 segundos continuos desde /dev/shm en menos de 1 segundo vía ffmpeg -c copy.
Guarda en ./inbox_brutos/ el video .mp4 y el archivo hermano .json con metadatos.
Incluye ventana de enfriamiento (cooldown) anti-duplicados.
"""

import os
import json
import time
import logging
import subprocess
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple
import numpy as np
from ring_buffer import RingBufferManager
from os_compat import get_shm_path, get_ffmpeg_cmd, get_ffprobe_cmd

logger = logging.getLogger("extractor")

DEFAULT_INBOX = Path(__file__).resolve().parent / "inbox_brutos"
CONCAT_MANIFEST = get_shm_path("concat_clip.txt")


def trim_leading_dead_air(
    audio_pcm: np.ndarray,
    sr: int = 16000,
    max_trim_sec: float = 1.5,
    lead_in_sec: float = 0.08
) -> float:
    """
    Trim-Zero Energy Gate: Divide los primeros max_trim_sec en ventanas de 50 ms.
    Busca el primer bloque cuya rms > 0.15 * global_rms.
    Devuelve offset = max(0.0, t_first - lead_in_sec).
    Asegura que el segundo 0.0 de un clip nunca arranque con silencio muerto.
    """
    if len(audio_pcm) == 0:
        return 0.0
    global_rms = float(np.sqrt(np.mean(audio_pcm ** 2)))
    if global_rms < 1e-6:
        return 0.0
    max_trim_samples = int(max_trim_sec * sr)
    win_samples = int(0.050 * sr)  # Ventana de 50 ms
    thresh = 0.15 * global_rms

    for i in range(0, min(len(audio_pcm), max_trim_samples), win_samples):
        win = audio_pcm[i : i + win_samples]
        if len(win) == 0:
            continue
        win_rms = float(np.sqrt(np.mean(win ** 2)))
        if win_rms > thresh:
            t_first = i / float(sr)
            offset = max(0.0, t_first - lead_in_sec)
            return round(float(offset), 4)
    return 0.0


def snap_to_sentence_boundaries(
    start_sec: float,
    end_sec: float,
    transcript_segments: Optional[List[Dict[str, Any]]] = None,
    margin_sec: float = 3.0
) -> Tuple[float, float]:
    """
    Sentence Snapping: Ajusta start_time y end_time al silencio más cercano o final de frase
    de Whisper en un margen de +- 3.0s para evitar cortar palabras a la mitad.
    """
    if not transcript_segments or len(transcript_segments) == 0:
        return start_sec, end_sec

    new_start = start_sec
    new_end = end_sec

    # 1. Ajustar start_sec: evitar cortar la primera palabra a la mitad
    for seg in transcript_segments:
        s_start = float(seg.get("start", 0.0))
        s_end = float(seg.get("end", 0.0))
        # Si el corte inicial cae dentro de un segmento con palabra en curso
        if s_start <= start_sec <= s_end:
            if (start_sec - s_start) <= margin_sec:
                new_start = s_start
                break
        elif abs(s_start - start_sec) <= margin_sec:
            new_start = s_start
            break

    # 2. Ajustar end_sec: extender o recortar al final de la oración más cercana
    best_diff = margin_sec + 1.0
    for seg in transcript_segments:
        s_end = float(seg.get("end", 0.0))
        diff = abs(s_end - end_sec)
        if diff <= margin_sec and diff < best_diff:
            best_diff = diff
            new_end = s_end

    # Asegurar duración mínima coherente (>= 15s)
    if (new_end - new_start) < 15.0:
        return start_sec, end_sec

    return round(new_start, 2), round(new_end, 2)


class RewindExtractor:
    def __init__(self, output_dir: Path = DEFAULT_INBOX, cooldown_seconds: int = 0):
        self.output_dir = output_dir
        self.cooldown_seconds = cooldown_seconds
        self.last_extraction_time: float = 0.0
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def is_in_cooldown(self) -> bool:
        """Verifica si el enfriamiento está activo. En modo cosecha continua es 0."""
        if self.cooldown_seconds <= 0:
            return False
        elapsed = time.time() - self.last_extraction_time
        return elapsed < self.cooldown_seconds

    def extract_clip(
        self,
        evaluation_result: Dict[str, Any],
        ring_buffer: RingBufferManager,
        youtube_url: str = "",
        selected_segments: Optional[List[Path]] = None,
        target_duration_sec: Optional[float] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Empaqueta el clip de forma continua desde /dev/shm en menos de 0.5s vía ffmpeg -c copy.
        Si se proporcionan selected_segments (sub-ventana óptima acústica), los usa directamente.
        Si se especifica target_duration_sec, ajusta exactamente la duración sin exceder los segundos deseados.
        """
        if self.is_in_cooldown():
            remaining = int(self.cooldown_seconds - (time.time() - self.last_extraction_time))
            logger.info(f"⏳ Enfriamiento activo ({remaining}s restantes). Omitiendo extracción duplicada.")
            return None

        # 1. Obtener segmentos específicos o del buffer con compensación
        if selected_segments and len(selected_segments) >= 3:
            segments = selected_segments
        else:
            fetch_dur = int(target_duration_sec or 60)
            segments = ring_buffer.get_segments_for_clip(duration_sec=fetch_dur, pre_roll_sec=5)

        # Filtrar fragmentos .ts corruptos o truncados menores a 10 KB
        valid_segments = []
        for seg in segments:
            try:
                if seg.exists() and seg.stat().st_size >= 10240:
                    valid_segments.append(seg)
                else:
                    logger.warning(f"⚠️ Omitiendo fragmento .ts corrupto o menor a 10 KB: {seg.name}")
            except Exception:
                pass
        segments = valid_segments

        if len(segments) < 3:
            logger.warning(f"⚠️ Buffer insuficiente para clip tras filtrar tramos corruptos (solo {len(segments)} fragmentos válidos >= 10KB en RAM). Esperando acumulación...")
            return None

        ts_str = time.strftime("%Y%m%d_%H%M%S")
        video_filename = f"clip_{ts_str}.mp4"
        json_filename = f"clip_{ts_str}.json"
        
        output_mp4 = self.output_dir / video_filename
        output_json = self.output_dir / json_filename
        output_existed_before = output_mp4.exists()

        # 2. Generar manifiesto de concatenación rápido en memoria volátil
        try:
            with open(CONCAT_MANIFEST, "w", encoding="utf-8") as f:
                for seg in segments:
                    f.write(f"file '{seg.resolve().as_posix()}'\n")

            # Aplicar Sentence Snapping si hay segmentos de transcripción
            final_clip_dur = target_duration_sec
            sub_segments = evaluation_result.get("transcripcion_segmentos") or []
            if final_clip_dur and final_clip_dur > 0 and sub_segments:
                _, snapped_dur = snap_to_sentence_boundaries(0.0, float(final_clip_dur), sub_segments, margin_sec=3.0)
                final_clip_dur = snapped_dur

            # Aplicar Trim-Zero Dead-Air Gate sobre el inicio tras Sentence Snapping
            trim_offset = 0.0
            if segments:
                try:
                    lead_cmd = [
                        get_ffmpeg_cmd(), "-y", "-hide_banner", "-loglevel", "error",
                        "-i", str(segments[0].resolve()),
                        "-t", "2.0", "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1",
                        "-f", "s16le", "-"
                    ]
                    pr = subprocess.run(lead_cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=2.0)
                    if pr.stdout and len(pr.stdout) >= 320:
                        pcm_lead = np.frombuffer(pr.stdout, dtype=np.int16).astype(np.float32) / 32768.0
                        trim_offset = trim_leading_dead_air(pcm_lead, sr=16000, max_trim_sec=1.5, lead_in_sec=0.08)
                except Exception:
                    trim_offset = 0.0

            clip_timeout = max(45.0, min(300.0, float(final_clip_dur or 60.0) * 1.5))

            # 3. Empaquetado instantáneo con ffmpeg en modo copia directa (< 0.5s)
            # NOTA CRÍTICA A/V SYNC: En modo -c copy jamás aplicar -ss arbitrario sobre concat demuxer
            # porque desincroniza video (anclado a keyframes IDR) y audio (corte en muestras).
            # Se añade -avoid_negative_ts make_zero para normalizar PTS de salida sin -fflags +genpts en copy.
            t0 = time.time()
            cmd = [
                get_ffmpeg_cmd(), "-y", "-hide_banner", "-loglevel", "error",
                "-err_detect", "ignore_err",
                "-f", "concat", "-safe", "0",
                "-i", str(CONCAT_MANIFEST)
            ]
            if final_clip_dur and final_clip_dur > 0:
                cmd.extend(["-t", str(round(float(final_clip_dur), 2))])
            cmd.extend([
                "-c", "copy",
                "-bsf:a", "aac_adtstoasc",
                "-avoid_negative_ts", "make_zero",
                "-movflags", "+faststart",
                str(output_mp4)
            ])
            res = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=clip_timeout)
            t1 = time.time()

            if res.returncode != 0 or not output_mp4.exists() or output_mp4.stat().st_size < 1000:
                err_msg = res.stderr.decode("utf-8", errors="ignore") if res.stderr else "Error desconocido"
                logger.warning(f"⚠️ Fallo en concatenación con -c copy ({err_msg.strip()[:80]}). Reintentando con transcodificación de audio segura (-c:v copy -c:a aac -b:a 192k)...")
                retry_cmd = [
                    get_ffmpeg_cmd(), "-y", "-hide_banner", "-loglevel", "error",
                    "-err_detect", "ignore_err",
                    "-fflags", "+genpts",
                    "-f", "concat", "-safe", "0",
                    "-i", str(CONCAT_MANIFEST)
                ]
                if final_clip_dur and final_clip_dur > 0:
                    retry_cmd.extend(["-t", str(round(float(final_clip_dur), 2))])
                retry_cmd.extend([
                    "-c:v", "copy",
                    "-c:a", "aac",
                    "-af", "aresample=async=1:first_pts=0",
                    "-b:a", "192k",
                    "-avoid_negative_ts", "make_zero",
                    "-movflags", "+faststart",
                    str(output_mp4)
                ])
                res = subprocess.run(retry_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=clip_timeout)
                t1 = time.time()

            if res.returncode != 0 or not output_mp4.exists() or output_mp4.stat().st_size < 1000:
                logger.error(f"Error definitivo concatenando clip con ffmpeg (fallback aac falló): {res.stderr.decode('utf-8', errors='ignore') if res.stderr else ''}")
                return None

            # Verificar alineación A/V de arranque (corte .ts sin keyframe IDR alineado)
            try:
                pr_sync = subprocess.run(
                    [
                        get_ffprobe_cmd(), "-v", "error",
                        "-show_entries", "stream=codec_type,start_time",
                        "-of", "json", str(output_mp4)
                    ],
                    capture_output=True, text=True, timeout=10
                )
                if pr_sync.returncode == 0 and pr_sync.stdout:
                    streams = json.loads(pr_sync.stdout).get("streams", [])
                    v_st = next((s for s in streams if s.get("codec_type") == "video"), None)
                    a_st = next((s for s in streams if s.get("codec_type") == "audio"), None)
                    if v_st and a_st:
                        v_start = float(v_st.get("start_time") or 0.0)
                        a_start = float(a_st.get("start_time") or 0.0)
                        diff_start = abs(v_start - a_start)
                        if 0.15 < diff_start < 10.0:
                            lead_trim = round(max(max(v_start, a_start), diff_start) + 0.04, 3)
                            aligned_tmp = output_mp4.with_suffix(".aligned.mp4")
                            logger.info(f"🔧 [Extractor] Desfase IDR inicial detectado (V={v_start:.3f}s, A={a_start:.3f}s, diff={diff_start:.3f}s). Re-alineando desde {lead_trim}s...")
                            align_cmd = [
                                get_ffmpeg_cmd(), "-y", "-hide_banner", "-loglevel", "error",
                                "-fflags", "+genpts",
                                "-accurate_seek", "-ss", str(lead_trim),
                                "-i", str(output_mp4),
                                "-c:v", "libx264", "-preset", "ultrafast", "-crf", "22", "-pix_fmt", "yuv420p",
                                "-c:a", "aac", "-b:a", "160k",
                                "-af", "aresample=async=1:first_pts=0",
                                "-fps_mode", "cfr",
                                "-shortest",
                                "-avoid_negative_ts", "make_zero",
                                "-movflags", "+faststart",
                                str(aligned_tmp)
                            ]
                            try:
                                align_res = subprocess.run(align_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=60)
                                if align_res.returncode == 0 and aligned_tmp.exists() and aligned_tmp.stat().st_size > 1000:
                                    os.replace(aligned_tmp, output_mp4)
                                else:
                                    logger.warning(f"⚠️ Re-alineado A/V en extractor falló; se conserva clip original.")
                            finally:
                                if aligned_tmp.exists():
                                    try:
                                        aligned_tmp.unlink()
                                    except Exception:
                                        pass
            except Exception as e_sync:
                logger.debug(f"Aviso verificando start_time post-concatenación: {e_sync}")

            file_size_mb = round(output_mp4.stat().st_size / (1024 * 1024), 2)
            concat_duration = round(t1 - t0, 3)
            logger.info(f"⚡ Clip cosechado en {concat_duration}s ({file_size_mb} MB): {output_mp4.name}")

            peak = float(evaluation_result.get("peak_level", evaluation_result.get("max_peak", 0.0)))
            rms = float(evaluation_result.get("rms_energy", 0.0))
            variance = float(evaluation_result.get("dynamic_variance", 0.0))
            has_subs = bool(evaluation_result.get("has_subtitles", False))
            sub_text = evaluation_result.get("texto_completo", "")

            # 4. Guardar archivo hermano con metadatos completos y telemetría de audio
            dur_sec = round(float(target_duration_sec), 2) if target_duration_sec else len(segments) * 5
            metadata = {
                "id": f"clip_{ts_str}",
                "clip_id": f"clip_{ts_str}",
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
                "video_file": video_filename,
                "video_path": str(output_mp4),
                "file_size_mb": file_size_mb,
                "score": evaluation_result.get("score", 7.0),
                "peak_level": round(peak, 4),
                "rms_energy": round(rms, 4),
                "dynamic_variance": round(variance, 6),
                "has_subtitles": has_subs,
                "titulo_gancho": evaluation_result.get("titulo_gancho", f"¡CLÍMAX EN DIRECTO! Pico {peak:.2f}"),
                "protagonistas_detectados": evaluation_result.get("protagonistas", []),
                "motivo": evaluation_result.get("reason", "Cosecha continua: Sub-ventana con mayor pico y actividad acústica"),
                "transcripcion_base": sub_text,
                "palabras": evaluation_result.get("palabras", len(sub_text.split()) if sub_text else 0),
                "duracion_segundos": dur_sec,
                "fragmentos_usados": len(segments),
                "youtube_url": youtube_url,
                "etapa4_ready": {
                    "source_url": youtube_url,
                    "source_type": "live",
                    "duration": dur_sec,
                    "timeline_tracks": {
                        "video": [{"src": video_filename, "start": 0.0, "end": dur_sec}],
                        "subtitles": evaluation_result.get("transcripcion_segmentos", []),
                        "cuts": [],
                        "overlays": []
                    }
                }
            }

            with open(output_json, "w", encoding="utf-8") as jf:
                json.dump(metadata, jf, ensure_ascii=False, indent=2)

            # Actualizar tiempo de última extracción
            self.last_extraction_time = time.time()
            return metadata

        except Exception as e:
            logger.error(f"Excepción durante la extracción del clip: {e}")
            if "output_existed_before" in locals() and not output_existed_before and output_mp4.exists() and not output_json.exists():
                try:
                    output_mp4.unlink()
                except Exception:
                    pass
            return None

    def list_clips(self) -> List[Dict[str, Any]]:
        """Retorna todos los clips extraídos ordenados del más reciente al más antiguo."""
        clips = []
        if not self.output_dir.exists():
            return []

        for json_file in sorted(self.output_dir.glob("clip_*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
            try:
                with open(json_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    # Verificar que el video siga existiendo
                    mp4_path = self.output_dir / data.get("video_file", "")
                    if mp4_path.exists():
                        clips.append(data)
            except Exception as e:
                logger.warning(f"Error leyendo {json_file}: {e}")

        return clips
