"""
reframer.py - Motor de Encuadre Inteligente 9:16 (Auto-Reframe) para Shorts.
Utiliza OpenCV y YuNet ONNX para detección facial ultrarrápida en CPU (< 5ms).
Modos de encuadre disponibles (Salida estricta 1080x1920):
- GAMING_BLUR: Fondo difuminado 9:16 + video 16:9 nítido centrado (ideal para gameplay / streaming).
- SINGLE_SPEAKER: Seguimiento y recorte centrado en el rostro del hablante principal.
- SPLIT_SCREEN: Apilado vertical (vstack) de dos hablantes (podcast / debates).
- AUTO: Muestrea 5 fotogramas y selecciona automáticamente el mejor modo según el contenido.
"""

import json
import logging
import subprocess
from pathlib import Path
from typing import Dict, Any, Tuple, Optional, List
import cv2
import numpy as np

from os_compat import get_binary_path, get_ffmpeg_cmd, get_ffprobe_cmd, escape_ass_path

logger = logging.getLogger("reframer")
YUNET_MODEL_PATH = Path(__file__).resolve().parent / "models" / "face_detection_yunet.onnx"

# Constantes de Zona Segura Universal (Shorts, TikTok, Reels)
SAFE_TOP = 0.14      # Evita barra superior / pestañas
SAFE_BOTTOM = 0.70   # Evita descripción y barra de progreso (TikTok/Shorts/Reels)
SAFE_LEFT = 0.06     # Evita bordes curvos
SAFE_RIGHT = 0.82    # Evita botones derechos (Like/Comentar/Compartir)


def get_video_info(video_path: Path) -> Dict[str, Any]:
    """Obtiene dimensiones y duración del video mediante ffprobe."""
    try:
        ffprobe_bin = get_ffprobe_cmd()
        cmd = [
            ffprobe_bin, "-v", "error",
            "-select_streams", "v:0",
            "-show_entries", "stream=width,height,duration",
            "-of", "json",
            str(video_path)
        ]
        res = subprocess.run(cmd, capture_output=True, text=True, check=True)
        data = json.loads(res.stdout)
        stream = data["streams"][0]
        return {
            "width": int(stream.get("width", 1920)),
            "height": int(stream.get("height", 1080)),
            "duration": float(stream.get("duration", 0.0))
        }
    except Exception as e:
        logger.warning(f"Error extrayendo info de video con ffprobe ({video_path}): {e}")
        return {"width": 1920, "height": 1080, "duration": 30.0}


def optimize_shots(shots: List[Dict[str, Any]], max_shots: int = 12) -> List[Dict[str, Any]]:
    """
    BLINDAJE FFMPEG: Limita el número de tramos condicionales a un máximo de 12 cortes por video.
    Agrupa cambios de plano menores a 3 segundos o con diferencias mínimas para evitar
    superar el límite de expresiones anidadas en FFmpeg en clips de 60s, 90s o 120s.
    """
    if not shots or len(shots) <= max_shots:
        return shots

    # 1. Agrupar tramos con duración menor a 3.0 segundos
    cleaned: List[Dict[str, Any]] = []
    for s in shots:
        dur = s.get("end_t", 0.0) - s.get("start_t", 0.0)
        if dur < 3.0 and cleaned:
            cleaned[-1]["end_t"] = s["end_t"]
            cx_list = cleaned[-1].get("cx_list", []) + s.get("cx_list", [s.get("center_x_norm", 0.5)])
            cleaned[-1]["cx_list"] = cx_list
            cleaned[-1]["center_x_norm"] = round(sum(cx_list) / max(1, len(cx_list)), 3)
        else:
            cleaned.append(dict(s))

    # 2. Si todavía excede max_shots, fusionar iterativamente los tramos consecutivos más cercanos
    while len(cleaned) > max_shots:
        min_diff = float("inf")
        merge_idx = 0
        for i in range(len(cleaned) - 1):
            diff = abs(cleaned[i]["center_x_norm"] - cleaned[i+1]["center_x_norm"])
            if diff < min_diff:
                min_diff = diff
                merge_idx = i

        merged_cx = cleaned[merge_idx].get("cx_list", []) + cleaned[merge_idx+1].get("cx_list", [])
        cleaned[merge_idx]["end_t"] = cleaned[merge_idx+1]["end_t"]
        cleaned[merge_idx]["cx_list"] = merged_cx
        cleaned[merge_idx]["center_x_norm"] = round(sum(merged_cx) / max(1, len(merged_cx)), 3)
        cleaned.pop(merge_idx + 1)

    return cleaned


def validate_webcam_candidate(
    rect: Dict[str, float],
    frame_w: int,
    frame_h: int,
    faces: List[Dict[str, Any]]
) -> bool:
    """
    Valida un rectángulo candidato a webcam para evitar falsos positivos en podcasts y debates:
    1. Relación de aspecto entre 1.2 y 1.9.
    2. Área mínima > 4% del frame (rect_area / frame_area > 0.04).
    3. Detección real de rostro dentro de ese recuadro.
    Si no hay rostro confirmado (cintillos, banners, logos de TV), se descarta.
    """
    rx = float(rect.get("x", 0.0))
    ry = float(rect.get("y", 0.0))
    rw = float(rect.get("w", 0.0))
    rh = float(rect.get("h", 0.0))
    if rw <= 0.0 or rh <= 0.0 or frame_w <= 0 or frame_h <= 0:
        return False

    aspect = rw / rh
    if not (1.2 <= aspect <= 1.9):
        return False

    area_ratio = (rw * rh) / float(frame_w * frame_h)
    if area_ratio <= 0.04:
        return False

    # Detección real de rostro dentro del recuadro
    face_inside = False
    for f in faces:
        fcx = float(f.get("cx", 0.5)) * frame_w if f.get("cx", 0.5) <= 1.0 else float(f.get("cx", 0.0))
        fcy = float(f.get("cy", 0.5)) * frame_h if f.get("cy", 0.5) <= 1.0 else float(f.get("cy", 0.0))
        if rx <= fcx <= (rx + rw) and ry <= fcy <= (ry + rh):
            face_inside = True
            break

    return face_inside


def detect_faces_in_video(video_path: Path, sample_interval_sec: float = 2.0) -> Dict[str, Any]:
    """
    Muestrea fotogramas cada 2 segundos a lo largo del video y detecta rostros con YuNet.
    SINGLE_SPEAKER es el modo por defecto del sistema y de AUTO (prohibido split-screen en paneles).
    Detecta cambios de plano entre panelistas y genera segmentos de encuadre dinámico.
    """
    fallback_res = {
        "mode": "SINGLE_SPEAKER",
        "avg_faces": 1.0,
        "center_x_norm": 0.5,
        "shots": []
    }

    if not YUNET_MODEL_PATH.exists():
        logger.warning(f"Modelo YuNet no encontrado en {YUNET_MODEL_PATH}. Usando SINGLE_SPEAKER centrado.")
        return fallback_res

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        return fallback_res

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    duration = total_frames / fps if total_frames > 0 and fps > 0 else 30.0
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    if total_frames <= 0 or width <= 0 or height <= 0:
        cap.release()
        return fallback_res

    # Downsampling a 320px de ancho para detección YuNet 15x-45x más rápida en CPU
    scale_w = 320.0 / width
    target_w = 320
    target_h = max(16, int(round(height * scale_w)))

    try:
        detector = cv2.FaceDetectorYN_create(
            str(YUNET_MODEL_PATH),
            "",
            (target_w, target_h),
            score_threshold=0.80,
            nms_threshold=0.3,
            top_k=10
        )
    except Exception as e:
        logger.warning(f"No se pudo inicializar FaceDetectorYN: {e}")
        cap.release()
        return fallback_res

    # Muestrear cada 2 segundos (t = 1.0, 3.0, 5.0, ...)
    sample_timestamps = [float(t) for t in range(1, int(duration) + 1, int(sample_interval_sec))]
    if not sample_timestamps:
        sample_timestamps = [duration / 2.0]

    samples: List[Dict[str, Any]] = []
    last_known_cx = 0.5

    for t_sec in sample_timestamps:
        cap.set(cv2.CAP_PROP_POS_MSEC, t_sec * 1000.0)
        ret, frame = cap.read()
        if not ret or frame is None:
            continue

        # Inferencia ultrarrápida (< 3 ms) sobre frame reducido a 320px
        small_frame = cv2.resize(frame, (target_w, target_h), interpolation=cv2.INTER_LINEAR)
        detector.setInputSize((target_w, target_h))
        _, faces = detector.detect(small_frame)
        
        valid_faces = []
        if faces is not None and len(faces) > 0:
            for face in faces:
                score = float(face[-1])
                if score >= 0.80:
                    x = float(face[0]) / scale_w
                    y = float(face[1]) / scale_w
                    w_f = float(face[2]) / scale_w
                    h_f = float(face[3]) / scale_w
                    h_norm = h_f / float(frame.shape[0])
                    # Exigir que el rostro mida al menos 4% de la altura
                    if h_norm >= 0.04:
                        cx_norm = (x + (w_f / 2.0)) / frame.shape[1]
                        cy_norm = (y + (h_f / 2.0)) / frame.shape[0]
                        valid_faces.append({
                            "cx": cx_norm, "cy": cy_norm,
                            "h_norm": h_norm, "w": w_f, "h": h_f,
                            "x": x, "y": y, "score": score
                        })

        if valid_faces:
            # Seleccionar el rostro principal (mayor área o score)
            valid_faces.sort(key=lambda f: f["h_norm"] * f["score"], reverse=True)
            chosen = valid_faces[0]
            chosen_cx = chosen["cx"]
            # Si está cerca del centro (0.44 a 0.56), centrar suavemente a 0.50 exacto
            if 0.44 <= chosen_cx <= 0.56:
                chosen_cx = 0.50
            last_known_cx = chosen_cx

            # Comprobar si coincide con patrón de webcam de videojuego con recuadro validado:
            # Aspecto 1.2-1.9, área > 4% del frame y rostro confirmado dentro
            is_gaming_cam = False
            if chosen["h_norm"] < 0.16 and (chosen["cx"] < 0.36 or chosen["cx"] > 0.64) and len(valid_faces) == 1:
                f_h_full = float(frame.shape[0])
                f_w_full = float(frame.shape[1])
                prop_h = min(f_h_full, chosen["h"] * 2.8)
                prop_w = prop_h * 1.55  # aspect ~1.55 (entre 1.2 y 1.9)
                cand_rx = max(0.0, (chosen["cx"] * f_w_full) - (prop_w / 2.0))
                cand_ry = max(0.0, (chosen["cy"] * f_h_full) - (prop_h / 2.0))
                cand_rect = {"x": cand_rx, "y": cand_ry, "w": prop_w, "h": prop_h}
                is_gaming_cam = validate_webcam_candidate(cand_rect, int(f_w_full), int(f_h_full), [chosen])
            samples.append({
                "t": t_sec,
                "cx": round(chosen_cx, 3),
                "faces_count": len(valid_faces),
                "is_gaming": is_gaming_cam,
                "face_detail": chosen
            })
        else:
            # Mantener la posición del último plano conocido
            samples.append({"t": t_sec, "cx": round(last_known_cx, 3), "faces_count": 0, "is_gaming": False})

    cap.release()

    if not samples:
        return fallback_res

    total_detected = sum(s["faces_count"] for s in samples)
    avg_faces = total_detected / len(samples)

    # Detección automática de Gaming Webcam
    gaming_samples = [s["face_detail"] for s in samples if s.get("is_gaming") and "face_detail" in s]
    detected_frames = sum(1 for s in samples if s.get("faces_count", 0) > 0)
    is_gaming_split = False
    cam_face = None

    if detected_frames > 0 and (len(gaming_samples) / detected_frames) >= 0.35:
        is_gaming_split = True
        avg_w = sum(f["w"] for f in gaming_samples) / len(gaming_samples)
        avg_h = sum(f["h"] for f in gaming_samples) / len(gaming_samples)
        avg_cx = sum(f["cx"] for f in gaming_samples) / len(gaming_samples)
        avg_cy = sum(f["cy"] for f in gaming_samples) / len(gaming_samples)
        cam_face = {
            "w": avg_w,
            "h": avg_h,
            "cx_norm": round(avg_cx, 3),
            "cy_norm": round(avg_cy, 3)
        }
        logger.info(f"🎮 [Reframer] Detección automática: GAMING_SPLIT activo (Webcam cx={avg_cx:.2f}, h={avg_h:.0f}px)")

    # Agrupar muestras en planos de cámara estables (shots)
    shots: List[Dict[str, Any]] = []
    current_shot = {"start_t": 0.0, "end_t": duration, "cx_list": [samples[0]["cx"]]}

    for i in range(1, len(samples)):
        prev_cx = samples[i-1]["cx"]
        curr_cx = samples[i]["cx"]
        curr_t = samples[i]["t"]

        if abs(curr_cx - prev_cx) >= 0.08:
            current_shot["end_t"] = round(curr_t, 2)
            avg_cx = sum(current_shot["cx_list"]) / len(current_shot["cx_list"])
            current_shot["center_x_norm"] = round(avg_cx, 3)
            shots.append(current_shot)
            current_shot = {"start_t": round(curr_t, 2), "end_t": duration, "cx_list": [curr_cx]}
        else:
            current_shot["cx_list"].append(curr_cx)

    if current_shot["cx_list"]:
        current_shot["end_t"] = duration
        avg_cx = sum(current_shot["cx_list"]) / len(current_shot["cx_list"])
        current_shot["center_x_norm"] = round(avg_cx, 3)
        shots.append(current_shot)

    shots = optimize_shots(shots, max_shots=12)

    all_cx = [s["cx"] for s in samples]
    overall_center = sum(all_cx) / len(all_cx) if all_cx else 0.5

    if is_gaming_split:
        auto_mode = "GAMING_SPLIT"
    elif avg_faces >= 1.6:
        auto_mode = "PODCAST_SPLIT"
    else:
        auto_mode = "SINGLE_SPEAKER"

    return {
        "mode": auto_mode,
        "avg_faces": round(avg_faces, 2),
        "center_x_norm": round(overall_center, 3),
        "shots": shots,
        "cam_face": cam_face
    }


def build_reframe_filtergraph(
    framing_mode: str,
    ass_path: Optional[Path],
    video_info: Dict[str, Any],
    detection_data: Optional[Dict[str, Any]] = None,
    crop_offset_x: float = 0.0,
    crop_offset_y: float = 0.0,
    zoom: float = 1.0,
    gaming_cam_offset_x: float = 0.0,
    gaming_cam_offset_y: float = 0.0,
    gaming_cam_zoom: float = 1.0,
    start_trim: float = 0.0,
    logo_path: Optional[Path] = None,
    logo_position: str = "top_right",
    logo_opacity: float = 0.7,
    overlay_path: Optional[Path] = None,
    overlay_x: float = 0.85,
    overlay_y: float = 0.10,
    overlay_scale: float = 0.20,
    overlay_opacity: float = 1.0,
    overlays: Optional[List[Dict[str, Any]]] = None,
    out_w: int = 1080,
    out_h: int = 1920,
    fade_out: bool = False,
    effective_duration: Optional[float] = None,
    target_fps: float = 30.0
) -> str:
    """
    Construye la cadena de filtros FFmpeg para transformar 16:9 en resolución vertical (out_w x out_h) con subtítulos .ass.
    En SINGLE_SPEAKER utiliza encuadre dinámico adaptado a cambios de plano entre panelistas.
    Permite ajuste manual horizontal y vertical fino (crop_offset_x, crop_offset_y, zoom),
    soporte para gaming split independiente (cam vs juego), y capa de marca de agua/overlay con opacidad.
    Dimensiones siempre proporcionales y pares (divisibles entre 2 para libx264).
    """
    out_w = int(out_w)
    out_h = int(out_h)
    if out_w % 2 != 0:
        out_w -= 1
    if out_h % 2 != 0:
        out_h -= 1

    req_mode = (framing_mode or "AUTO").upper()

    if req_mode == "AUTO":
        mode = (detection_data or {}).get("mode", "SINGLE_SPEAKER")
        if mode == "PODCAST_SPLIT":
            mode = "SPLIT_SCREEN"
    elif req_mode in ["GAMING_SPLIT", "GAMINGSPLIT"]:
        mode = "GAMING_SPLIT"
    elif req_mode in ["GAMING_BLUR", "GAMING_SINGLE", "GAMINGSINGLE", "BLUR_CROP"]:
        mode = "GAMING_BLUR"
    elif req_mode in ["SINGLE_SPEAKER", "SINGLE_SPEAKER_AMPLIO", "WIDE_SPEAKER"]:
        mode = "SINGLE_SPEAKER"
    elif req_mode in ["SINGLE_SPEAKER_TIGHT", "SINGLE_SPEAKER_FIXED"]:
        mode = "SINGLE_SPEAKER_TIGHT"
    elif req_mode in ["SPLIT_SCREEN", "SPLIT_PODCAST", "PODCAST_SPLIT"]:
        mode = "SPLIT_SCREEN"
    elif req_mode == "ALREADY_VERTICAL":
        mode = "ALREADY_VERTICAL"
    else:
        mode = (detection_data or {}).get("mode", "SINGLE_SPEAKER")

    w = video_info.get("width", 1920)
    h = video_info.get("height", 1080)

    # Desplazamiento manual en píxeles (-1.0 = izquierda/arriba, +1.0 = derecha/abajo)
    shift_px = int(round(crop_offset_x * (out_w / 2.0)))
    shift_y_px = int(round(crop_offset_y * (out_h / 4.0)))

    # Escapar ruta de ASS para FFmpeg (evitar problemas con ':' y backslashes en Windows y Linux)
    if ass_path:
        escaped_ass = escape_ass_path(ass_path)
        ass_str = f"ass='{escaped_ass}'"
    else:
        ass_str = "null"

    # Determinar si hay overlays multi-PNG o logo/overlay único legacy
    if overlays and len(overlays) > 0:
        filter_parts = [f"[base]{ass_str}[subbed]"]
        curr_tag = "[subbed]"
        m_count = len(overlays)
        for idx, ov in enumerate(overlays):
            input_idx = idx + 1
            next_tag = "[outv]" if idx == m_count - 1 else f"[ov_step{idx+1}]"

            # Escala y dimensiones
            width_norm = max(0.02, min(1.0, float(ov.get("width", ov.get("scale", 0.20)))))
            ov_w = int(round(out_w * width_norm))
            if ov_w % 2 != 0:
                ov_w += 1
            ov_w = max(16, min(out_w, ov_w))

            # Opacidad
            op_val = f"{max(0.0, min(1.0, float(ov.get('opacity', 1.0)))):.2f}"

            # Rotación opcional
            rot_deg = float(ov.get("rotation", 0.0))
            if abs(rot_deg) > 0.5:
                rot_rad = f"{rot_deg * 3.14159265 / 180.0:.4f}"
                rot_filter = f",rotate={rot_rad}:c=none:ow='hypot(iw,ih)':oh=ow"
            else:
                rot_filter = ""

            filter_parts.append(
                f"[{input_idx}:v]scale={ov_w}:-1{rot_filter},format=rgba,colorchannelmixer=aa={op_val}[ov_layer{idx}]"
            )

            # Tiempos de activación (relativos a inicio de video recortado)
            st = float(ov.get("start", 0.0))
            en = float(ov.get("end", 999999.0))
            t_s = max(0.0, st - start_trim)
            t_e = max(0.0, en - start_trim)
            enable_clause = f":enable='between(t,{t_s:.2f},{t_e:.2f})'"

            # Posicionamiento centrado
            cx = float(ov.get("x", 0.5))
            cy = float(ov.get("y", 0.5))
            px = int(round(cx * out_w))
            py = int(round(cy * out_h))
            pos_xy = f"x={px}-w/2:y={py}-h/2{enable_clause}"

            filter_parts.append(f"{curr_tag}[ov_layer{idx}]overlay={pos_xy}{next_tag}")
            curr_tag = next_tag

        ass_filter = ";".join(filter_parts)
    else:
        active_overlay = overlay_path if (overlay_path and Path(overlay_path).exists()) else logo_path
        if active_overlay and Path(active_overlay).exists():
            if overlay_path and Path(overlay_path).exists():
                logo_scale_w = int(round(out_w * max(0.05, min(0.6, overlay_scale))))
                pos_xy = f"{int(round(overlay_x * out_w))}:{int(round(overlay_y * out_h))}"
                opacity_val = f"{max(0.0, min(1.0, float(overlay_opacity))):.2f}"
            else:
                logo_scale_w = int(round(180 * (out_w / 1080.0)))
                if logo_position == "top_left":
                    pos_xy = "50:60"
                elif logo_position == "bottom_center":
                    pos_xy = f"(W-w)/2:H-h-{int(round(480 * out_h / 1920.0))}"
                else:  # top_right
                    pos_xy = "W-w-50:60"
                opacity_val = f"{max(0.1, min(1.0, float(logo_opacity))):.2f}"

            if logo_scale_w % 2 != 0:
                logo_scale_w += 1

            ass_filter = (
                f"[base]{ass_str}[subbed];"
                f"[1:v]scale={logo_scale_w}:-1,format=rgba,colorchannelmixer=aa={opacity_val}[logo];"
                f"[subbed][logo]overlay={pos_xy}[outv]"
            )
        else:
            ass_filter = f"[base]{ass_str}[outv]"

    def _apply_fade(fg: str) -> str:
        if fade_out and effective_duration and float(effective_duration) > 0.4:
            fade_st = max(0.0, float(effective_duration) - 0.35)
            if "[outv]" in fg:
                return fg.replace("[outv]", f"[pre_fade];[pre_fade]fade=t=out:st={fade_st:.2f}:d=0.35[outv]")
        return fg

    fps_val = min(60.0, max(24.0, round(float(target_fps or 30.0), 2)))

    # DETECCIÓN DIRECTA: Si el video original ya es vertical (TikTok Live, YouTube Shorts, etc.)
    if h > w or mode == "ALREADY_VERTICAL":
        logger.info(f"📱 [Reframer] Video original ya es vertical ({w}x{h}). Omitiendo recorte YuNet y adaptando a {out_w}x{out_h}.")
        if w == out_w and h == out_h:
            return _apply_fade(f"[0:v]fps={fps_val},setpts=PTS-STARTPTS[vin];[vin]null[base];{ass_filter}")
        else:
            return _apply_fade(f"[0:v]fps={fps_val},setpts=PTS-STARTPTS[vin];[vin]scale={out_w}:{out_h}:force_original_aspect_ratio=decrease,pad={out_w}:{out_h}:(ow-iw)/2:(oh-ih)/2:black[base];{ass_filter}")

    if mode == "GAMING_SPLIT":
        cam_info = (detection_data or {}).get("cam_face") or {}
        face_w_px = float(cam_info.get("w") or int(w * 0.10))
        face_h_px = float(cam_info.get("h") or int(h * 0.12))
        cx_norm = float(cam_info.get("cx_norm") if cam_info.get("cx_norm") is not None else 0.18)
        cy_norm = float(cam_info.get("cy_norm") if cam_info.get("cy_norm") is not None else 0.25)
        
        # 1. ARRIBA: Recuadro de la webcam alrededor de la cara
        top_h = int(round(out_h * (640.0 / 1920.0)))
        if top_h % 2 != 0:
            top_h -= 1
        bot_h = out_h - top_h
        if bot_h % 2 != 0:
            bot_h -= 1
            top_h = out_h - bot_h

        cam_zoom_val = max(1.0, min(3.0, float(gaming_cam_zoom or zoom or 1.0)))
        cam_shift_x = int(round(gaming_cam_offset_x * (w / 4.0))) + shift_px
        cam_shift_y = int(round(gaming_cam_offset_y * (h / 4.0)))

        face_cx_px = (cx_norm * w) + cam_shift_x
        face_cy_px = (cy_norm * h) + cam_shift_y

        cam_h = min(h, int(round((face_h_px * 2.8) / cam_zoom_val)))
        cam_w = int(round(cam_h * (float(out_w) / float(top_h))))
        if cam_w > w:
            cam_w = w
            cam_h = int(round(cam_w * (float(top_h) / float(out_w))))

        cam_x = int(round(face_cx_px - (cam_w / 2.0)))
        cam_y = int(round(face_cy_px - (cam_h / 2.0)))
        cam_x = max(0, min(w - cam_w, cam_x))
        cam_y = max(0, min(h - cam_h, cam_y))

        if cam_w % 2 != 0: cam_w -= 1
        if cam_h % 2 != 0: cam_h -= 1
        if cam_x % 2 != 0: cam_x -= 1
        if cam_y % 2 != 0: cam_y -= 1

        # 2. ABAJO: Centro de acción del juego con altura completa
        game_center_x = (int(round(w * 0.58)) if cx_norm < 0.5 else int(round(w * 0.42))) + shift_px
        game_center_y = int(round(h / 2.0)) + shift_y_px
        game_h = h
        game_w = int(round(game_h * (float(out_w) / float(bot_h))))
        if game_w > w:
            game_w = w
            game_h = int(round(game_w * (float(bot_h) / float(out_w))))

        game_x = int(round(game_center_x - (game_w / 2.0)))
        game_y = int(round(game_center_y - (game_h / 2.0)))
        game_x = max(0, min(w - game_w, game_x))
        game_y = max(0, min(h - game_h, game_y))

        if game_w % 2 != 0: game_w -= 1
        if game_h % 2 != 0: game_h -= 1
        if game_x % 2 != 0: game_x -= 1
        if game_y % 2 != 0: game_y -= 1

        logger.info(f"🎮 [Reframer] GAMING_SPLIT: Cam ({cam_w}x{cam_h} -> {out_w}x{top_h}), Game ({game_w}x{game_h} -> {out_w}x{bot_h})")
        filtergraph = (
            f"[0:v]fps={fps_val},setpts=PTS-STARTPTS[vin];"
            f"[vin]split=2[vin1][vin2];"
            f"[vin1]crop={cam_w}:{cam_h}:{cam_x}:{cam_y},scale={out_w}:{top_h},setsar=1[top];"
            f"[vin2]crop={game_w}:{game_h}:{game_x}:{game_y},scale={out_w}:{bot_h},setsar=1[bot];"
            f"[top][bot]vstack[base];"
            f"{ass_filter}"
        )
        return _apply_fade(filtergraph)

    elif mode == "SINGLE_SPEAKER":
        # SINGLE_SPEAKER Amplio (+30% contexto) con zoom interactivo y offset X/Y
        zoom_val = max(1.0, min(3.0, float(zoom or 1.0)))
        center_x_norm = (detection_data or {}).get("center_x_norm", 0.5)
        crop_w = min(w, int(round((h * 0.72) / zoom_val)))
        crop_h = min(h, int(round(h / zoom_val)))
        center_x = int(round((center_x_norm * w) + shift_px))
        center_y = int(round((h / 2.0) + shift_y_px))
        crop_x = int(round(center_x - (crop_w / 2.0)))
        crop_y = int(round(center_y - (crop_h / 2.0)))
        crop_x = max(0, min(w - crop_w, crop_x))
        crop_y = max(0, min(h - crop_h, crop_y))

        if crop_w % 2 != 0: crop_w -= 1
        if crop_h % 2 != 0: crop_h -= 1
        if crop_x % 2 != 0: crop_x -= 1
        if crop_y % 2 != 0: crop_y -= 1

        logger.info(f"👤 [Reframer] SINGLE_SPEAKER: crop {crop_w}x{crop_h} en ({crop_x},{crop_y}) zoom={zoom_val}x sobre fondo {out_w}x{out_h} difuminado")
        filtergraph = (
            f"[0:v]fps={fps_val},setpts=PTS-STARTPTS[vin];"
            f"[vin]split=2[vin1][vin2];"
            f"[vin1]scale=270:480:force_original_aspect_ratio=increase,crop=270:480,boxblur=6:2,scale={out_w}:{out_h}:flags=fast_bilinear[bg];"
            f"[vin2]crop={crop_w}:{crop_h}:{crop_x}:{crop_y},scale={out_w}:-2[fg];"
            f"[bg][fg]overlay=0:(H-h)/2[base];"
            f"{ass_filter}"
        )
        return _apply_fade(filtergraph)

    elif mode == "SINGLE_SPEAKER_TIGHT":
        # Recorte estricto out_w x out_h directo con seguimiento de planos
        scaled_w = int(round(w * float(out_h) / float(h)))
        if scaled_w % 2 != 0:
            scaled_w += 1
            
        max_crop = max(0, scaled_w - out_w)
        shots = (detection_data or {}).get("shots", [])

        if len(shots) >= 2:
            if len(shots) > 12:
                shots = optimize_shots(shots, max_shots=12)
            shot_crops = []
            half_w = out_w / 2.0
            for s in shots:
                cx_norm = s.get("center_x_norm", 0.5)
                c_px = int(round((cx_norm * scaled_w) - half_w)) + shift_px
                c_px = max(0, min(max_crop, c_px))
                if c_px % 2 != 0:
                    c_px += 1
                shot_crops.append(c_px)

            if max(shot_crops) - min(shot_crops) > 40:
                expr = str(shot_crops[-1])
                for k in range(len(shots) - 2, -1, -1):
                    t_end = max(0.1, shots[k]["end_t"] - start_trim)
                    expr = f"if(lt(t\\,{t_end:.2f})\\,{shot_crops[k]}\\,{expr})"
                
                logger.info(f"🎥 Aplicando encuadre dinámico ({len(shots)} planos, shift={shift_px}px): {expr[:80]}...")
                filtergraph = (
                    f"[0:v]fps={fps_val},setpts=PTS-STARTPTS[vin];"
                    f"[vin]scale={scaled_w}:{out_h},crop={out_w}:{out_h}:'{expr}':0[base];"
                    f"{ass_filter}"
                )
                return _apply_fade(filtergraph)

        center_x_norm = 0.5
        if detection_data and "center_x_norm" in detection_data:
            center_x_norm = detection_data["center_x_norm"]

        face_px = (center_x_norm * scaled_w) + shift_px
        crop_x = int(round(face_px - (out_w / 2.0)))
        crop_x = max(0, min(max_crop, crop_x))
        if crop_x % 2 != 0:
            crop_x += 1

        filtergraph = (
            f"[0:v]fps={fps_val},setpts=PTS-STARTPTS[vin];"
            f"[vin]scale={scaled_w}:{out_h},crop={out_w}:{out_h}:{crop_x}:0[base];"
            f"{ass_filter}"
        )
        return _apply_fade(filtergraph)

    elif mode == "SPLIT_SCREEN":
        # Apilar 2 paneles verticales (SOLO cuando el usuario lo selecciona explícitamente)
        top_panel_h = out_h // 2
        if top_panel_h % 2 != 0:
            top_panel_h -= 1
        bot_panel_h = out_h - top_panel_h

        scaled_w = int(round(w * float(top_panel_h) / float(h)))
        if scaled_w % 2 != 0:
            scaled_w += 1

        face1_norm = 0.3
        face2_norm = 0.7
        if detection_data:
            face1_norm = detection_data.get("face1_x_norm", 0.3)
            face2_norm = detection_data.get("face2_x_norm", 0.7)

        max_crop = max(0, scaled_w - out_w)
        half_w = out_w // 2
        crop1_x = max(0, min(max_crop, int(round((face1_norm * scaled_w) - half_w)) + shift_px))
        crop2_x = max(0, min(max_crop, int(round((face2_norm * scaled_w) - half_w)) + shift_px))
        if crop1_x % 2 != 0:
            crop1_x += 1
        if crop2_x % 2 != 0:
            crop2_x += 1

        filtergraph = (
            f"[0:v]fps={fps_val},setpts=PTS-STARTPTS[vin];"
            f"[vin]split=2[vin1][vin2];"
            f"[vin1]scale={scaled_w}:{top_panel_h},crop={out_w}:{top_panel_h}:{crop1_x}:0,setsar=1[top];"
            f"[vin2]scale={scaled_w}:{bot_panel_h},crop={out_w}:{bot_panel_h}:{crop2_x}:0,setsar=1[bot];"
            f"[top][bot]vstack[base];"
            f"{ass_filter}"
        )
        return _apply_fade(filtergraph)

    else:
        # Modo GAMING_BLUR (fondo difuminado) con soporte para zoom y offset X/Y
        zoom_val = max(1.0, min(3.0, float(zoom or 1.0)))
        crop_w = min(w, int(round(w / zoom_val)))
        crop_h = min(h, int(round(h / zoom_val)))
        center_x = int(round((w / 2.0) + shift_px))
        center_y = int(round((h / 2.0) + shift_y_px))
        crop_x = max(0, min(w - crop_w, int(round(center_x - (crop_w / 2.0)))))
        crop_y = max(0, min(h - crop_h, int(round(center_y - (crop_h / 2.0)))))
        if crop_w % 2 != 0: crop_w -= 1
        if crop_h % 2 != 0: crop_h -= 1
        if crop_x % 2 != 0: crop_x -= 1
        if crop_y % 2 != 0: crop_y -= 1

        filtergraph = (
            f"[0:v]fps={fps_val},setpts=PTS-STARTPTS[vin];"
            f"[vin]split=2[vin1][vin2];"
            f"[vin1]scale=270:480:force_original_aspect_ratio=increase,crop=270:480,boxblur=6:2,scale={out_w}:{out_h}:flags=fast_bilinear[bg];"
            f"[vin2]crop={crop_w}:{crop_h}:{crop_x}:{crop_y},scale={out_w}:-2[fg];"
            f"[bg][fg]overlay=0:(H-h)/2[base];"
            f"{ass_filter}"
        )
        return _apply_fade(filtergraph)
