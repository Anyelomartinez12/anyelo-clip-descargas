"""
version.py — Versión canónica oficial de Anyelo Clip
"""
VERSION = "2.3.4"
