"""Licencias offline de Anyelo Clip mediante claves RSA ligadas a una PC."""

import base64
import binascii
import hashlib
import hmac
import json
import logging
import os
import platform
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from config_manager import load_config, save_config

logger = logging.getLogger("anyelo_clip.license")

PRODUCT_CODE = "anyelo-clip-v1"
LICENSE_PREFIX = "AC1"
RSA_PUBLIC_MODULUS_B64URL = "wu5lrmWnggaqzQc6XBhbDiGQ6vRz1vzPHeIVZJ6oztQVta4RYG3axc0Se28c8HKsnD1Aa6t2kQRG-QIsTgK7YHzLWEcanQHeDwRwH6CsxjMIyyuZid-Qki7fOf_j__5xpTm_Gmd_PLJhb7OVw6709Qi9h8E7lABigmTtqIF61Vm_iFpwB5vAki30JotoxuvieoWPo8p63xqHOg9RFBTEBiF17OOEqWH2ZUcbPbcrtbcs3WH-z9OH7TvC02sRzPFb7tMUul-TxdjoyVa702uoNgFr8-yTFhkPZr1OE_spvtK3RdKImSSbnDwuilG-bFjRA3bjl2mclW3c8hEQ3PIHHiL8HshyJP6lR-74wf2WsEOotCd8U7r5WzgcE7ByJdvqvw1-ORvSXn0KL4bc1NL28lX28MKMd7pzNL2_sH65hXzXc90csM0_NhRwsO7s5k0XWR5iTf_JaxtQD4e5ZX0Mfv9uoaBvQ_ctaBdZt0BqgAnbgT0zuBXuxWcSDPZxpuEV"
RSA_PUBLIC_EXPONENT = 65537
SHA256_DIGEST_INFO_PREFIX = bytes.fromhex("3031300d060960864801650304020105000420")
_RSA_MODULUS = int.from_bytes(
    base64.urlsafe_b64decode(RSA_PUBLIC_MODULUS_B64URL + "=" * (-len(RSA_PUBLIC_MODULUS_B64URL) % 4)),
    "big",
)
_RSA_SIGNATURE_SIZE = (_RSA_MODULUS.bit_length() + 7) // 8


def _b64url_decode(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def get_machine_id() -> str:
    """Devuelve un ID anónimo de hardware de 24 caracteres hexadecimales."""
    raw_id = ""

    if os.name == "nt":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography") as key:
                raw_id, _ = winreg.QueryValueEx(key, "MachineGuid")
        except Exception:
            pass

    if not raw_id:
        for path in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
            if os.path.exists(path):
                try:
                    raw_id = Path(path).read_text(encoding="utf-8").strip()
                    if raw_id:
                        break
                except Exception:
                    pass

    if not raw_id:
        raw_id = f"{uuid.getnode()}:{platform.node()}:{platform.machine()}"

    return hashlib.sha256(raw_id.strip().encode("utf-8")).hexdigest()[:24].upper()


def _verify_rsa_signature(message: bytes, signature: bytes) -> bool:
    if len(signature) != _RSA_SIGNATURE_SIZE:
        return False

    signature_int = int.from_bytes(signature, "big")
    if signature_int >= _RSA_MODULUS:
        return False

    encoded = pow(signature_int, RSA_PUBLIC_EXPONENT, _RSA_MODULUS).to_bytes(
        _RSA_SIGNATURE_SIZE, "big"
    )
    digest_info = SHA256_DIGEST_INFO_PREFIX + hashlib.sha256(message).digest()
    padding_length = _RSA_SIGNATURE_SIZE - len(digest_info) - 3
    if padding_length < 8:
        return False

    expected = b"\x00\x01" + (b"\xff" * padding_length) + b"\x00" + digest_info
    return hmac.compare_digest(encoded, expected)


def verify_license_key(
    license_key: str,
    expected_machine_id: Optional[str] = None,
) -> Tuple[bool, str, Dict[str, Any]]:
    """Verifica firma, producto, equipo y vencimiento sin conexión a Internet."""
    clean_key = (license_key or "").strip()
    if len(clean_key) > 4096:
        return False, "La clave es demasiado larga", {}

    parts = clean_key.split(".")
    if len(parts) != 3 or parts[0] != LICENSE_PREFIX:
        return False, "Formato de licencia inválido", {}

    payload_b64 = parts[1]
    try:
        payload_bytes = _b64url_decode(payload_b64)
        signature = _b64url_decode(parts[2])
        if len(payload_bytes) > 2048:
            return False, "La licencia contiene demasiados datos", {}
        signed_message = f"{LICENSE_PREFIX}.{payload_b64}".encode("ascii")
        if not _verify_rsa_signature(signed_message, signature):
            return False, "La firma de la licencia no es válida", {}
        payload = json.loads(payload_bytes.decode("utf-8"))
    except (ValueError, UnicodeError, binascii.Error, json.JSONDecodeError):
        return False, "No se pudo leer la licencia", {}

    if payload.get("product") != PRODUCT_CODE:
        return False, "Esta licencia no corresponde a Anyelo Clip", {}
    machine_id = str(payload.get("machine_id", "")).upper()
    if not re.fullmatch(r"[A-F0-9]{24}", machine_id):
        return False, "La licencia contiene un ID de PC inválido", {}
    if expected_machine_id and not hmac.compare_digest(machine_id, expected_machine_id.upper()):
        return False, "Esta licencia fue creada para otra PC", {}

    expires_at = payload.get("expires_at")
    if expires_at:
        try:
            expiry = datetime.fromisoformat(str(expires_at).replace("Z", "+00:00"))
            if expiry.tzinfo is None:
                expiry = expiry.replace(tzinfo=timezone.utc)
            if datetime.now(timezone.utc) > expiry.astimezone(timezone.utc):
                return False, "La licencia venció", {}
        except ValueError:
            return False, "La fecha de vencimiento de la licencia no es válida", {}

    return True, "Licencia válida", payload


def is_system_activated() -> Tuple[bool, str, Dict[str, Any]]:
    """Comprueba la clave guardada y la liga al ID de esta PC."""
    config = load_config()
    current_machine_id = get_machine_id()
    key = str(config.get("license_key", "")).strip()

    if not config.get("license_active") or not key:
        return False, "Anyelo Clip no ha sido activado todavía", {
            "machine_id": current_machine_id
        }

    valid, message, payload = verify_license_key(key, current_machine_id)
    if not valid:
        return False, message, {"machine_id": current_machine_id}

    masked = key[:12] + "..." + key[-8:]
    return True, "Licencia activa y validada offline", {
        "machine_id": current_machine_id,
        "license_masked": masked,
        "license_id": payload.get("license_id", ""),
        "expires_at": payload.get("expires_at") or "Permanente",
        "activated_at": config.get("license_activated_at", ""),
    }


def activate_system(
    license_key: str,
    product_permalink: Optional[str] = None,
) -> Tuple[bool, str]:
    """Activa una clave firmada para esta PC y guarda la licencia para uso offline."""
    clean_key = (license_key or "").strip()
    if not clean_key:
        return False, "Pega la clave de licencia que recibiste"

    current_machine_id = get_machine_id()
    valid, message, payload = verify_license_key(clean_key, current_machine_id)
    if not valid:
        return False, message

    config = load_config()
    if (
        config.get("license_active")
        and config.get("machine_id") == current_machine_id
        and config.get("license_key", "").strip() == clean_key
    ):
        return True, "Esta PC ya tiene esta licencia activa"

    save_config({
        "license_active": True,
        "license_key": clean_key,
        "license_signature": "",
        "machine_id": current_machine_id,
        "license_activated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "license_id": payload.get("license_id", ""),
        "license_expires_at": payload.get("expires_at"),
    })

    logger.info("Anyelo Clip activado con licencia %s", payload.get("license_id", ""))
    return True, "Licencia activada en esta PC; ya funciona offline."