"""
native_audio.py - Analizador acústico nativo directo desde /dev/shm (Independiente de CDP).
Extrae PCM 16kHz en memoria vía FFmpeg y calcula métricas con NumPy:
- peak_level (0.0 a 1.0)
- rms_energy (energía media de voz/sonido)
- dynamic_variance (varianza temporal de energía para distinguir voz de ruido plano)
Localiza la sub-ventana de 30-45s con mayor actividad relativa.
"""

import time
import logging
import subprocess
from pathlib import Path
from typing import Dict, Any, List, Tuple, Optional
import numpy as np

from os_compat import get_ffmpeg_cmd, get_subprocess_flags

logger = logging.getLogger("native_audio")

# Caché en memoria de fragmentos analizados: {filepath: (mtime, size, metrics)}
_CHUNK_CACHE: Dict[str, Tuple[float, int, Dict[str, float]]] = {}


class RingEnergyBuffer:
    """
    Arreglo circular pre-asignado en memoria plana para almacenar el historial de energía RMS (últimos 3 min / 180s).
    Evita allocaciones dinámicas y listas crecientes en streams largos de 24/7.
    """
    def __init__(self, max_len: int = 180):
        self.max_len = max_len
        self.buffer = np.zeros(max_len, dtype=np.float32)
        self.idx = 0
        self.count = 0

    def append(self, val: float):
        self.buffer[self.idx] = float(val)
        self.idx = (self.idx + 1) % self.max_len
        self.count = min(self.count + 1, self.max_len)

    def get_history(self) -> np.ndarray:
        if self.count == 0:
            return np.array([], dtype=np.float32)
        if self.count < self.max_len:
            return self.buffer[:self.count].copy()
        return np.concatenate((self.buffer[self.idx:], self.buffer[:self.idx]))


def calculate_modified_zscore(hist: Any, current_rms: float) -> float:
    """
    Modified Z-Score basado en la Mediana de las Desviaciones Absolutas (MAD).
    Inmune a outliers extremos que descalibran la media y varianza clásicas.
    """
    arr = np.asarray(hist, dtype=np.float32)
    if len(arr) < 3:
        return 0.0
    med = float(np.median(arr))
    mad = float(np.median(np.abs(arr - med))) + 1e-6
    mod_z = float(np.clip(0.6745 * (current_rms - med) / mad, -3.0, 10.0))
    return round(float(mod_z), 4)


def compute_vocal_metrics(pcm: np.ndarray, sr: int = 16000) -> Dict[str, Any]:
    """
    Separa energía de voz humana (300-3400 Hz) vs sub-graves (<180 Hz) y calcula la
    Entropía de Wiener (Spectral Flatness) para distinguir voz humana nítida de
    ruido blanco, explosiones de juegos o música saturada.
    """
    if len(pcm) < 16:
        return {
            "vocal_ratio": 0.0,
            "sub_ratio": 0.0,
            "flatness": 0.0,
            "is_voice_clear": False,
            "is_noise_or_explosion": False
        }
    spec = np.abs(np.fft.rfft(pcm * np.hanning(len(pcm)))) + 1e-9
    freqs = np.fft.rfftfreq(len(pcm), d=1.0 / sr)
    power = spec ** 2
    vocal_mask = (freqs >= 300.0) & (freqs <= 3400.0)
    sub_mask = freqs < 180.0
    vocal_ratio = float(np.sum(power[vocal_mask]) / (np.sum(power) + 1e-9))
    sub_ratio = float(np.sum(power[sub_mask]) / (np.sum(power) + 1e-9))
    flatness = float(np.exp(np.mean(np.log(spec))) / (np.mean(spec) + 1e-9))

    is_voice_clear = bool(vocal_ratio > 0.45 and flatness < 0.35)
    is_noise_or_explosion = bool(flatness > 0.55 or sub_ratio > 0.50)

    return {
        "vocal_ratio": round(vocal_ratio, 4),
        "sub_ratio": round(sub_ratio, 4),
        "flatness": round(flatness, 4),
        "is_voice_clear": is_voice_clear,
        "is_noise_or_explosion": is_noise_or_explosion
    }


def compute_spectral_flux(samples: np.ndarray, frame_size: int = 1024, hop_size: int = 512) -> float:
    """
    Calcula el flujo espectral medio (half-wave rectified spectral flux) con numpy.fft.rfft.
    Permite diferenciar transiciones acústicas bruscas (risas, gritos, remates) de música plana de fondo.
    """
    if len(samples) < frame_size * 2:
        return 0.0
    n_frames = (len(samples) - frame_size) // hop_size
    if n_frames < 2:
        return 0.0
    # Limitar frames procesados para velocidad instantánea en tiempo real (< 1.5ms)
    step = max(1, n_frames // 40)
    indices = list(range(0, len(samples) - frame_size, hop_size * step))
    
    spectra = []
    window = np.hanning(frame_size).astype(np.float32)
    for idx in indices:
        frame = samples[idx : idx + frame_size] * window
        spec = np.abs(np.fft.rfft(frame))
        # Normalizar energía del espectro
        spec_norm = spec / (np.sum(spec) + 1e-6)
        spectra.append(spec_norm)
    
    if len(spectra) < 2:
        return 0.0
    
    diffs = []
    for i in range(1, len(spectra)):
        diff = spectra[i] - spectra[i - 1]
        diffs.append(np.sum(np.maximum(0, diff)))
    
    flux = float(np.mean(diffs))
    return round(float(flux), 6)


def analyze_chunk(chunk_path: Path) -> Dict[str, float]:
    """
    Analiza un fragmento .ts extrayendo audio PCM mono 16kHz en memoria.
    Retorna peak_level, rms_energy, dynamic_variance y duración en segundos.
    Usa caché para nunca reprocesar el mismo fragmento si su mtime y tamaño no han cambiado.
    """
    global _CHUNK_CACHE
    
    if not chunk_path.exists():
        return {"peak_level": 0.0, "rms_energy": 0.0, "dynamic_variance": 0.0, "duration": 0.0}

    try:
        stat = chunk_path.stat()
        mtime, size = stat.st_mtime, stat.st_size
    except Exception:
        return {"peak_level": 0.0, "rms_energy": 0.0, "dynamic_variance": 0.0, "duration": 0.0}

    path_str = str(chunk_path.resolve())
    if path_str in _CHUNK_CACHE:
        cached_mtime, cached_size, cached_metrics = _CHUNK_CACHE[path_str]
        if cached_mtime == mtime and cached_size == size:
            return cached_metrics

    # Extraer PCM 16kHz mono directamente en memoria (stdout)
    cmd = [
        get_ffmpeg_cmd(), "-y", "-i", str(chunk_path),
        "-f", "s16le", "-ac", "1", "-ar", "16000",
        "-v", "quiet", "-"
    ]
    try:
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=8.0,
            **get_subprocess_flags(low_priority=False)
        )
        raw_bytes = proc.stdout
    except Exception as e:
        logger.warning(f"Error extrayendo PCM de {chunk_path.name} (carga alta de CPU): {e}")
        return {"peak_level": 0.0, "rms_energy": 0.0, "dynamic_variance": 0.0, "duration": 0.0}

    if not raw_bytes or len(raw_bytes) < 320:
        return {"peak_level": 0.0, "rms_energy": 0.0, "dynamic_variance": 0.0, "duration": 0.0}

    try:
        # Convertir a array NumPy normalizado en rango [-1.0, 1.0]
        samples = np.frombuffer(raw_bytes, dtype=np.int16).astype(np.float32) / 32768.0
        
        # 1. Peak level (pico absoluto máximo)
        peak_level = float(np.max(np.abs(samples))) if len(samples) > 0 else 0.0

        # 2. RMS Energy (energía cuadrática media)
        rms_energy = float(np.sqrt(np.mean(samples ** 2))) if len(samples) > 0 else 0.0

        # 3. Dynamic Variance (varianza de RMS en ventanas de 100ms = 1600 muestras a 16kHz)
        frame_size = 1600
        n_frames = len(samples) // frame_size
        if n_frames > 1:
            frames = samples[:n_frames * frame_size].reshape((n_frames, frame_size))
            frame_rms = np.sqrt(np.mean(frames ** 2, axis=1))
            dynamic_variance = float(np.var(frame_rms))
        else:
            dynamic_variance = 0.0

        duration = float(len(samples) / 16000.0)

        # 4. Flujo Espectral (diferencia espectral con FFT para detectar clímax y risas)
        spectral_flux = compute_spectral_flux(samples)

        # 5. Métricas vocales avanzadas (300-3400Hz vs sub-graves y Wiener Flatness)
        vocal_met = compute_vocal_metrics(samples, 16000)

        metrics = {
            "peak_level": round(peak_level, 4),
            "rms_energy": round(rms_energy, 4),
            "dynamic_variance": round(dynamic_variance, 6),
            "spectral_flux": round(spectral_flux, 6),
            "vocal_ratio": vocal_met["vocal_ratio"],
            "sub_ratio": vocal_met["sub_ratio"],
            "flatness": vocal_met["flatness"],
            "is_voice_clear": vocal_met["is_voice_clear"],
            "is_noise_or_explosion": vocal_met["is_noise_or_explosion"],
            "duration": round(duration, 2)
        }

        # Actualizar historial para Z-Score en ViralBrain
        try:
            from viral_brain import get_viral_brain
            get_viral_brain().update_rms_history(rms_energy)
        except Exception:
            pass

        # Guardar en caché
        _CHUNK_CACHE[path_str] = (mtime, size, metrics)
        
        # Limitar tamaño de caché para no crecer indefinidamente
        if len(_CHUNK_CACHE) > 200:
            for k in list(_CHUNK_CACHE.keys())[:50]:
                del _CHUNK_CACHE[k]

        return metrics
    except Exception as e:
        logger.error(f"Error calculando métricas NumPy para {chunk_path.name}: {e}")
        return {"peak_level": 0.0, "rms_energy": 0.0, "dynamic_variance": 0.0, "duration": 0.0}


def find_best_acoustic_window(
    segments: List[Path],
    target_duration_sec: int = 40,
    segment_duration_sec: int = 5
) -> Tuple[List[Path], Dict[str, Any]]:
    """
    Dada una lista de fragmentos .ts disponibles en /dev/shm,
    analiza cada uno y localiza la sub-ventana contigua de 30-45s
    que tuvo el mayor pico y actividad sonora relativa.
    
    Retorna (selected_segments, window_metrics).
    """
    if not segments:
        return [], {
            "peak_level": 0.0,
            "rms_energy": 0.0,
            "dynamic_variance": 0.0,
            "activity_score": 0.0,
            "duration_sec": 0
        }

    # Descartar el último segmento si ffmpeg aún está escribiendo en él
    valid_candidates = segments[:-1] if len(segments) > 1 else segments
    if not valid_candidates:
        valid_candidates = segments

    # Cantidad de segmentos necesarios para la duración objetivo (ej. 60s / 5s = 12 segmentos, 120s / 5s = 24 segmentos)
    target_count = max(3, int(round(target_duration_sec / segment_duration_sec)))

    # Si hay menos segmentos que target_count, usamos todos los disponibles
    if len(valid_candidates) <= target_count:
        selected = valid_candidates
    else:
        # Analizar métricas de cada segmento
        metrics_by_seg = [analyze_chunk(p) for p in valid_candidates]

        # Calcular puntuación de actividad acústica para cada segmento:
        # Combina pico (0.35) + energía RMS (0.30) + dinamismo/varianza (0.20) + flujo espectral (0.15)
        scores = []
        for m in metrics_by_seg:
            p = m["peak_level"]
            rms = m["rms_energy"]
            var = m["dynamic_variance"]
            flux = m.get("spectral_flux", 0.0)
            # Normalización heurística
            seg_score = (p * 3.5) + (min(rms, 0.25) * 18.0) + (min(var, 0.01) * 250.0) + (min(flux, 0.5) * 12.0)
            scores.append(seg_score)

        # Encontrar la ventana deslizante de tamaño target_count con la suma máxima de score
        max_sum = -1.0
        best_start = 0
        for i in range(len(valid_candidates) - target_count + 1):
            w_sum = sum(scores[i : i + target_count])
            if w_sum > max_sum:
                max_sum = w_sum
                best_start = i

        selected = valid_candidates[best_start : best_start + target_count]

    # Calcular métricas consolidadas de la sub-ventana seleccionada
    sel_metrics = [analyze_chunk(p) for p in selected]
    peak_level = max((m["peak_level"] for m in sel_metrics), default=0.0)
    rms_energy = float(np.mean([m["rms_energy"] for m in sel_metrics])) if sel_metrics else 0.0
    dynamic_variance = float(np.mean([m["dynamic_variance"] for m in sel_metrics])) if sel_metrics else 0.0
    spectral_flux = float(np.mean([m.get("spectral_flux", 0.0) for m in sel_metrics])) if sel_metrics else 0.0
    vocal_ratio = float(np.mean([m.get("vocal_ratio", 0.0) for m in sel_metrics])) if sel_metrics else 0.0
    sub_ratio = float(np.mean([m.get("sub_ratio", 0.0) for m in sel_metrics])) if sel_metrics else 0.0
    flatness = float(np.mean([m.get("flatness", 0.0) for m in sel_metrics])) if sel_metrics else 0.0
    total_duration = sum(m["duration"] for m in sel_metrics)

    # Z-score de RMS relativo (usando Modified Z-Score)
    rms_zscore = 0.0
    try:
        from viral_brain import get_viral_brain
        rms_zscore = get_viral_brain().calculate_rms_zscore(rms_energy)
    except Exception:
        pass

    # Score de interés de 1 a 10 para la base de datos y dashboard
    # Base mínima 5.0 (Cosecha Continua garantizada), sube hasta 10.0 con picos, energía y flujo tímbrico
    # Premia voz nítida y penaliza ruido plano/sub-graves
    vocal_bonus = 0.4 if (vocal_ratio > 0.45 and flatness < 0.35) else 0.0
    if flatness > 0.55 or sub_ratio > 0.50:
        vocal_bonus -= 0.3

    activity_score = 5.0 + (peak_level * 2.3) + (min(rms_energy * 18.0, 1.4)) + (min(dynamic_variance * 180.0, 0.8)) + (min(spectral_flux * 4.0, 0.5)) + vocal_bonus
    if rms_zscore > 1.0:
        activity_score += min((rms_zscore - 1.0) * 0.4, 0.8)
    activity_score = round(min(max(activity_score, 5.0), 10.0), 1)

    window_metrics = {
        "peak_level": round(peak_level, 4),
        "rms_energy": round(rms_energy, 4),
        "dynamic_variance": round(dynamic_variance, 6),
        "spectral_flux": round(spectral_flux, 6),
        "vocal_ratio": round(vocal_ratio, 4),
        "sub_ratio": round(sub_ratio, 4),
        "flatness": round(flatness, 4),
        "rms_zscore": round(rms_zscore, 2),
        "activity_score": activity_score,
        "duration_sec": round(total_duration, 1),
        "fragment_count": len(selected)
    }

    return selected, window_metrics


if __name__ == "__main__":
    from os_compat import get_ring_buffer_dir
    test_dir = get_ring_buffer_dir()
    files = list(test_dir.glob("seg_*.ts"))
    print(f"Probando native_audio con {len(files)} fragmentos...")
    if files:
        sel, met = find_best_acoustic_window(files, target_duration_sec=35)
        print("Ventana seleccionada:", len(sel), "fragmentos")
        print("Métricas:", met)
