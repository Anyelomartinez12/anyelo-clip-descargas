"""
asr_fallback.py - Micro-Transcripción Perezosa (Lazy ASR Fallback) con faster-whisper.
Se activa ÚNICAMENTE bajo demanda cuando el directo no tiene CC y hay un pico de audio (>= 0.70).
Extrae audio en RAM (/dev/shm/temp_check.wav, 16kHz mono, ~0.1s) y transcribe con VAD en < 2s.
"""

import os
import time
import logging
import threading
import subprocess
from pathlib import Path
from typing import List, Dict, Any, Optional, Callable

from os_compat import get_shm_path, get_ffmpeg_cmd

logger = logging.getLogger("asr_fallback")

TEMP_CONCAT = get_shm_path("temp_audio_concat.txt")
TEMP_WAV = get_shm_path("temp_check.wav")

# Singleton global thread-safe para evitar inicialización concurrente o crashes CTranslate2/OpenMP en Windows
_GLOBAL_WHISPER_LOCK = threading.RLock()
_SHARED_WHISPER_MODEL = None
_SHARED_WHISPER_PROFILE = None


class LazyWhisperASR:
    def __init__(self, model_size: str = "small"):
        self.model_size = model_size
        self._model = None

    def _load_model(self):
        """Carga el modelo en RAM solo la primera vez como singleton global thread-safe."""
        global _SHARED_WHISPER_MODEL, _SHARED_WHISPER_PROFILE
        with _GLOBAL_WHISPER_LOCK:
            if _SHARED_WHISPER_MODEL is None:
                t0 = time.time()
                from faster_whisper import WhisperModel
                from os_compat import resolve_safe_whisper_profile
                profile = resolve_safe_whisper_profile()
                model_sz = profile.get("model_size") or self.model_size or "small"
                comp_type = profile.get("compute_type") or "int8"
                f_isa = profile.get("force_isa")
                if f_isa:
                    os.environ["CT2_FORCE_CPU_ISA"] = f_isa

                cpu_threads = min(4, max(2, (os.cpu_count() or 4) // 2))
                logger.info(f"⏳ Inicializando modelo faster-whisper singleton ('{model_sz}' {comp_type} CPU, threads={cpu_threads}, ISA: {f_isa or 'default'})...")
                try:
                    _SHARED_WHISPER_MODEL = WhisperModel(
                        model_sz,
                        device="cpu",
                        compute_type=comp_type,
                        cpu_threads=cpu_threads
                    )
                except Exception as e:
                    logger.warning(f"No se pudo cargar modelo '{model_sz}' ({e}), intentando fallback a 'tiny' float32...")
                    os.environ["CT2_FORCE_CPU_ISA"] = "GENERIC"
                    _SHARED_WHISPER_MODEL = WhisperModel(
                        "tiny",
                        device="cpu",
                        compute_type="float32",
                        cpu_threads=cpu_threads
                    )
                t1 = time.time()
                logger.info(f"✅ Modelo faster-whisper singleton cargado en {t1 - t0:.2f}s (< 300MB RAM).")
                _SHARED_WHISPER_PROFILE = profile
            self._model = _SHARED_WHISPER_MODEL
            return _SHARED_WHISPER_MODEL

    def extract_audio_to_shm(self, segments: List[Path], output_wav: Path = TEMP_WAV) -> bool:
        """
        Extrae en /dev/shm un audio .wav 16kHz mono de los últimos 30-40 segundos.
        Toma menos de 0.2 segundos vía FFmpeg sin decodificar video.
        """
        if not segments:
            return False

        try:
            with open(TEMP_CONCAT, "w", encoding="utf-8") as f:
                for seg in segments:
                    f.write(f"file '{seg.resolve().as_posix()}'\n")

            cmd = [
                get_ffmpeg_cmd(), "-y", "-hide_banner", "-loglevel", "error",
                "-f", "concat", "-safe", "0",
                "-i", str(TEMP_CONCAT),
                "-vn",
                "-acodec", "pcm_s16le",
                "-ar", "16000",
                "-ac", "1",
                str(output_wav)
            ]
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, check=True, timeout=20.0)
            return output_wav.exists() and output_wav.stat().st_size > 1024
        except Exception as e:
            logger.error(f"Error extrayendo WAV temporal en RAM: {e}")
            return False

    def transcribe_wav(self, wav_path: Path = TEMP_WAV, cancel_check: Optional[Callable[[], bool]] = None) -> Dict[str, Any]:
        """
        Transcribe el audio de 30-45s usando faster-whisper con filtro VAD y beam_size=1.
        Retorna el texto unificado y los segmentos con marcas de tiempo.
        Protegido por _GLOBAL_WHISPER_LOCK para ejecución serializada en CPU.
        Soporta aborto inmediato en < 1s vía cancel_check() si cambia la sesión o el usuario detiene el stream.
        """
        if not wav_path.exists():
            return {"text": "", "words": 0, "segments": [], "avg_no_speech_prob": 0.0}

        if cancel_check and cancel_check():
            logger.info("🛑 [ASR] Transcripción cancelada antes de iniciar.")
            return {"text": "", "words": 0, "segments": [], "avg_no_speech_prob": 0.0}

        with _GLOBAL_WHISPER_LOCK:
            if cancel_check and cancel_check():
                logger.info("🛑 [ASR] Transcripción cancelada tras adquirir lock.")
                return {"text": "", "words": 0, "segments": [], "avg_no_speech_prob": 0.0}

            model = self._load_model()
            t0 = time.time()
            
            try:
                # Guía fonética en español enriquecida con el diccionario de jerga personalizado
                base_prompt = "Transcripción natural en español, conversación en directo, podcast o streaming."
                try:
                    from config_manager import load_config
                    cfg = load_config()
                    custom_vocab = cfg.get("vocabulary", "").strip()
                    if custom_vocab:
                        initial_prompt = f"{base_prompt} Vocabulario y nombres clave: {custom_vocab}."
                    else:
                        initial_prompt = base_prompt
                except Exception:
                    initial_prompt = base_prompt

                # Whisper en español con guía fonética, beam_size=2 y protección anti-alucinación en música/silencio
                segments_gen, info = model.transcribe(
                    str(wav_path),
                    beam_size=2,
                    language="es",
                    task="transcribe",
                    initial_prompt=initial_prompt,
                    condition_on_previous_text=False,
                    no_speech_threshold=0.6,
                    log_prob_threshold=-1.0,
                    compression_ratio_threshold=2.4,
                    vad_filter=True,
                    vad_parameters=dict(min_silence_duration_ms=400)
                )

                segments_list = []
                no_speech_probs = []
                for s in segments_gen:
                    if cancel_check and cancel_check():
                        logger.info("🛑 [ASR] Generador de segmentos cancelado rápidamente (< 1s).")
                        break
                    no_speech_probs.append(float(getattr(s, "no_speech_prob", 0.0)))
                    clean_text = s.text.strip()
                    if clean_text:
                        segments_list.append({
                            "start": round(s.start, 2),
                            "end": round(s.end, 2),
                            "text": clean_text
                        })

                full_text = " ".join([s["text"] for s in segments_list]).strip()
                words_list = [w for w in full_text.split() if len(w) > 1]
                avg_no_speech_prob = round(sum(no_speech_probs) / len(no_speech_probs), 4) if no_speech_probs else 1.0
                t1 = time.time()
                
                logger.info(f"🎙️ ASR completado en {t1 - t0:.2f}s: {len(words_list)} palabras (no_speech={avg_no_speech_prob:.2f}).")
                return {
                    "text": full_text,
                    "words": len(words_list),
                    "segments": segments_list,
                    "duration": round(info.duration, 2) if info else 0.0,
                    "language": info.language if info else "es",
                    "avg_no_speech_prob": avg_no_speech_prob
                }
            except Exception as e:
                logger.error(f"Error durante la micro-transcripción: {e}")
                return {"text": "", "words": 0, "segments": [], "avg_no_speech_prob": 0.0}


if __name__ == "__main__":
    asr = LazyWhisperASR()
    print("Módulo ASR Fallback preparado.")
