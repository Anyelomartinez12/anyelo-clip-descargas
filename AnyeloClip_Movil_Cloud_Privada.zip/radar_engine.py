"""
radar_engine.py - Orquestador Maestro: Analizador de Audio Nativo en RAM + Modo Cosecha Continua.
Genera clips 1080p ininterrumpidos leyendo directamente fragmentos .ts en /dev/shm.
Independiente de CDP o subtítulos, blindado contra caídas con Watchdog automático.
Ejecuta ASR perezoso a partir de 0.35 de pico y filtro mínimo de 3 palabras.
"""

import os
import time
import signal
import logging
import threading
from pathlib import Path
from typing import Dict, Any, List, Optional, Callable, Set

from ring_buffer import RingBufferManager
from native_audio import analyze_chunk, find_best_acoustic_window
from evaluator import evaluate_harvest_window, evaluate_window
from extractor import RewindExtractor
from sensor_cdp import BrowserSensor
from asr_fallback import LazyWhisperASR
from stage2_worker import stage2_queue
from vod_engine import vod_engine
from config_manager import load_config

logger = logging.getLogger("radar_engine")
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")


class RadarEngine:
    def __init__(self):
        self.ring_buffer = RingBufferManager()
        self.ring_buffer.on_fatal_error = lambda msg: self._on_ring_buffer_fatal_error(msg)
        self.ring_buffer.on_stream_ended = lambda msg: self._on_live_stream_ended(msg)
        self.extractor = RewindExtractor(cooldown_seconds=0)  # Cero cooldown para cosecha continua
        self.sensor = BrowserSensor()
        self.asr = LazyWhisperASR(model_size="small")
        
        self.threshold: float = 7.0
        self.clip_duration_sec: int = 60       # Duración objetivo unificada (15s a 600s)
        self.video_quality: str = "1080p"      # "480p" | "720p" | "1080p" | "max"
        self.audio_threshold: float = 0.35     # Umbral de activación de audio bajado a 0.35
        self.min_words_filter: int = 3         # Mínimo 3 palabras habladas para considerar texto
        self.mode: str = "live"                # "live" | "vod"
        self.auto_render_916: bool = True      # Toggle automático de Etapa 2
        self.min_render_score: float = 5.0     # Nota mínima para auto-render a 9:16
        self.last_error: str = ""
        from config_manager import load_config
        _cfg = load_config()
        self.burn_subtitles: bool = _cfg.get("burn_subtitles", True)
        self.auto_titles: bool = _cfg.get("auto_titles", True)
        self.is_active: bool = False
        self.current_url: str = ""
        self.max_clips: int = 5
        self.clips_harvested_count: int = 0
        
        # Buffer de subtítulos en memoria (enriquecimiento opcional de CDP si existe)
        self.caption_history: List[Dict[str, Any]] = []
        self.lock = threading.RLock()
        
        # Control de concurrencia y sesiones para evitar hilos duplicados
        self.session_id: int = 0
        self.stop_event: threading.Event = threading.Event()
        self.harvest_lock: threading.RLock = threading.RLock()

        # Registro de fragmentos .ts ya cosechados en la sesión para evitar clips duplicados
        self.harvested_segments: Set[str] = set()

        # Hilo de Cosecha Continua ininterrumpida
        self.harvest_thread: Optional[threading.Thread] = None
        self.last_harvest_time: float = 0.0
        
        # Último resultado evaluado
        self.last_evaluation: Dict[str, Any] = {
            "score": 0.0,
            "status": "idle",
            "reason": "Radar esperando inicio",
            "protagonistas": [],
            "titulo_gancho": "",
            "palabras": 0,
            "peak_level": 0.0,
            "rms_energy": 0.0,
            "dynamic_variance": 0.0,
            "has_subtitles": False
        }
        
        # Telemetría en vivo para Dashboard y WebSocket (calculada directo en /dev/shm)
        self.current_telemetry: Dict[str, Any] = {
            "last_text": "",
            "player_time": 0.0,
            "peak": 0.0,
            "peak_level": 0.0,
            "rms_energy": 0.0,
            "dynamic_variance": 0.0,
            "buffered_seconds": 0,
            "ram_mb": 0.0,
            "watchdog_ok": True
        }
        
        self.listeners: List[Callable[[Dict[str, Any]], None]] = []

    def add_listener(self, listener: Callable[[Dict[str, Any]], None]):
        self.listeners.append(listener)

    def remove_listener(self, listener: Callable[[Dict[str, Any]], None]):
        if listener in self.listeners:
            self.listeners.remove(listener)

    def _get_seg_sig(self, p: Path) -> str:
        """Firma identificadora única del fragmento por nombre y st_mtime."""
        try:
            return f"{p.name}_{round(p.stat().st_mtime, 1)}"
        except Exception:
            return p.name

    def _broadcast(self, event_type: str, data: Dict[str, Any]):
        msg = {"type": event_type, "data": data, "timestamp": time.time()}
        if isinstance(data, dict):
            if "filename" in data:
                msg["filename"] = data["filename"]
            if "clip" in data:
                msg["clip"] = data["clip"]
            if "short" in data:
                msg["short"] = data["short"]
        for listener in list(self.listeners):
            try:
                listener(msg)
            except Exception as e:
                logger.error(f"Error despachando evento a listener: {e}")

    def _on_ring_buffer_fatal_error(self, err_msg: str):
        """Detiene el radar y despacha notificación roja ante un error fatal de stream."""
        logger.error(f"🛑 [RadarEngine] Error fatal en buffer: {err_msg}")
        self.is_active = False
        self._broadcast("notification", {
            "type": "error",
            "message": f"⛔ {err_msg}"
        })
        self._broadcast("radar_state", {
            "active": False,
            "url": self.current_url,
            "mode": self.mode,
            "status": f"⛔ Detenido: {err_msg}"
        })

    def _on_live_stream_ended(self, reason: str):
        """Si un directo finaliza en vivo, conmuta automáticamente a modo VOD para cosechar clips del directo grabado."""
        if not self.is_active or self.mode != "live":
            return
        logger.info(f"🏁 [RadarEngine] Directo finalizado detectado ({reason}). Conmutando automáticamente a MODO VOD para cosechar clips del video grabado...")
        self._broadcast("notification", {
            "type": "info",
            "message": "🎬 El directo ha finalizado. Conmutando a modo VOD para procesar los mejores momentos del video grabado..."
        })
        # Detener componentes exclusivos de live
        try:
            self.ring_buffer.stop()
        except Exception:
            pass
        try:
            self.sensor.stop()
        except Exception:
            pass

        # Conmutar a VOD de inmediato
        self.mode = "vod"
        vod_engine.start_vod_harvest(
            url=self.current_url,
            max_clips=5,
            clip_duration_sec=self.clip_duration_sec,
            progress_cb=self._on_vod_progress,
            auto_render_916=self.auto_render_916,
            min_render_score=self.min_render_score,
            video_quality=self.video_quality,
            burn_subtitles=self.burn_subtitles,
            auto_titles=self.auto_titles
        )

    def _on_vod_progress(self, info: Any):
        """Callback de progreso de procesamiento VOD."""
        if isinstance(info, dict):
            self.current_telemetry["vod_progress"] = info.get("text", "")
            self.current_telemetry["vod_progress_info"] = info
            self._broadcast("vod_progress", info)
            if info.get("percentage", 0.0) >= 100.0:
                self.is_active = False
                self._broadcast("radar_state", {
                    "active": False,
                    "url": self.current_url,
                    "mode": "vod",
                    "status": info.get("text", "✅ Cosecha VOD completada")
                })
        else:
            self.current_telemetry["vod_progress"] = str(info)
            self._broadcast("vod_progress", {"text": str(info), "percentage": 0.0})

    def trigger_manual_live_clip(self, duration_sec: Optional[float] = None):
        """
        Clipear Momento en directo activo con espera cooperativa pre-roll / post-roll:
        1. Calcula el pre-roll disponible en buffer (hasta 35% de duration_sec).
        2. Si pre-roll < duration_sec, espera cooperativamente acumulando post-roll en RAM.
        3. Empaqueta el video completo con ffmpeg, transcribe con faster-whisper,
           guarda en inbox_brutos/ y encola a 9:16 si auto-render está activo.
        """
        manual_session = self.session_id
        stop_evt = self.stop_event
        target_dur = max(15.0, min(600.0, float(duration_sec or self.clip_duration_sec)))

        def _record_live():
            available_segs = self.ring_buffer.get_ordered_segments()
            available_sec = len(available_segs) * 5.0
            pre_roll = min(available_sec, max(10.0, target_dur * 0.35))
            post_roll = max(0.0, target_dur - pre_roll)
            
            logger.info(f"🔴 [Live Clip Manual] Objetivo: {target_dur:.0f}s (Pre-roll: {pre_roll:.1f}s en buffer | Post-roll: {post_roll:.1f}s a esperar)...")
            
            t_start_wait = time.time()
            while time.time() - t_start_wait < post_roll:
                if not self.is_active or self.session_id != manual_session or stop_evt.is_set():
                    logger.info("ℹ️ [Live Clip Manual] Cancelado por cambio de sesión o detención.")
                    return
                elapsed = time.time() - t_start_wait
                rem = max(0, int(round(post_roll - elapsed)))
                self._broadcast("live_clip_progress", {
                    "status": "recording",
                    "remaining_sec": rem,
                    "total_sec": int(target_dur),
                    "message": f"⏳ Grabando desenlace... faltan {rem}s"
                })
                if stop_evt.wait(timeout=1.0):
                    return
            
            if not self.is_active or self.session_id != manual_session or stop_evt.is_set():
                return

            # Al terminar el tiempo, tomar los fragmentos correspondientes a target_dur
            num_segs = max(3, int(round(target_dur / 5.0)))
            available_segs = self.ring_buffer.get_ordered_segments()
            selected_segs = available_segs[-num_segs:] if len(available_segs) >= num_segs else available_segs
            
            extracted_ok = False
            with self.harvest_lock:
                if not self.is_active or self.session_id != manual_session or stop_evt.is_set():
                    return

                valid_segs = [s for s in selected_segs if s.exists()]
                if len(valid_segs) < 2:
                    logger.warning("Fragmentos insuficientes para clip manual.")
                    return

                # Extraer audio rápidamente a SHM (< 0.1s)
                extracted_ok = self.asr.extract_audio_to_shm(valid_segs)

            # Micro-transcripción ASR 100% FUERA de harvest_lock (con cancel_check < 1s)
            asr_res = {"text": "", "words": 0, "segments": []}
            if extracted_ok:
                asr_res = self.asr.transcribe_wav(
                    cancel_check=lambda: not self.is_active or self.session_id != manual_session or stop_evt.is_set()
                )
            
            if not self.is_active or self.session_id != manual_session or stop_evt.is_set():
                logger.info("🛑 [Live Clip Manual] Sesión invalidada post-ASR. Abortando.")
                return

            asr_text = asr_res.get("text", "").strip()
            acoustic = dict(analyze_chunk(valid_segs[-1]) if valid_segs else {})
            acoustic["no_speech_prob"] = float(asr_res.get("avg_no_speech_prob", 0.0))
            eval_res = evaluate_harvest_window(
                acoustic_metrics=acoustic,
                entries=[{"text": asr_text}] if asr_text else []
            )
            
            sample_quote = asr_text[:35].rstrip() + ("..." if len(asr_text) > 35 else "")
            eval_res["titulo_gancho"] = f"¡CLÍMAX MANUAL! \"{sample_quote}\"" if asr_text else "¡MOMENTO CLAVE EN DIRECTO!"
            eval_res["transcripcion_segmentos"] = asr_res.get("segments", [])
            eval_res["texto_completo"] = asr_text
            eval_res["palabras"] = asr_res.get("words", 0)
            
            # Empaquetado protegido brevemente por harvest_lock (< 0.4s)
            with self.harvest_lock:
                if not self.is_active or self.session_id != manual_session or stop_evt.is_set():
                    return
                valid_render_segs = [s for s in valid_segs if s.exists()]
                if len(valid_render_segs) < 2:
                    return
                clip_meta = self.extractor.extract_clip(
                    evaluation_result=eval_res,
                    ring_buffer=self.ring_buffer,
                    youtube_url=self.current_url,
                    selected_segments=valid_render_segs,
                    target_duration_sec=target_dur
                )
            
            if clip_meta and self.session_id == manual_session and not stop_evt.is_set():
                logger.info(f"✨ [Live Clip Manual] Guardado con éxito: {clip_meta['video_file']}")
                # Marcar fragmentos usados como cosechados para que la cosecha automática no los duplique
                if valid_segs:
                    last_seg = valid_segs[-1]
                    try:
                        last_idx = available_segs.index(last_seg)
                        for s in available_segs[:last_idx + 1]:
                            self.harvested_segments.add(self._get_seg_sig(s))
                    except ValueError:
                        for s in valid_segs:
                            self.harvested_segments.add(self._get_seg_sig(s))
                self._broadcast("live_clip_progress", {
                    "status": "completed",
                    "remaining_sec": 0,
                    "total_sec": int(target_dur),
                    "message": "✅ Clip manual completado"
                })
                self._broadcast("new_clip_extracted", clip_meta)
                self._broadcast("clip_created", {
                    "filename": clip_meta.get("video_file", f"{clip_meta['clip_id']}.mp4"),
                    "clip": clip_meta
                })
                if self.auto_render_916 and self.session_id == manual_session and not stop_evt.is_set():
                    cfg_mode = load_config().get("default_framing_mode", "AUTO")
                    stage2_queue.enqueue(
                        clip_meta["clip_id"],
                        framing_mode=cfg_mode,
                        video_quality=self.video_quality,
                        session_id=self.session_id,
                        is_manual=True,
                        burn_subtitles=getattr(self, "burn_subtitles", True),
                        auto_titles=getattr(self, "auto_titles", True)
                    )
            else:
                self._broadcast("live_clip_progress", {
                    "status": "error",
                    "remaining_sec": 0,
                    "total_sec": int(target_dur),
                    "message": "❌ Error empaquetando clip manual"
                })

        th = threading.Thread(target=_record_live, daemon=True)
        th.start()

    def start(self, youtube_url: str, threshold: float = 7.0, max_clips: int = 5, clip_duration_sec: int = 60, video_quality: Optional[str] = None, burn_subtitles: Optional[bool] = None, auto_titles: Optional[bool] = None):
        """Inicia el radar detectando automáticamente si es LIVE o VOD grabado con duración y calidad dinámicas."""
        if not youtube_url.strip():
            raise ValueError("URL de YouTube requerida")
            
        self.stop()
        
        with self.lock:
            self.session_id += 1
            current_session = self.session_id
            self.stop_event = threading.Event()
            self.harvested_segments.clear()

        # Descartar renders pendientes de sesiones viejas
        try:
            stage2_queue.cancel_stale_session_jobs(current_session)
        except Exception:
            pass

        self.threshold = threshold
        self.max_clips = max_clips
        self.clip_duration_sec = max(15, min(600, int(clip_duration_sec or 60)))
        self.video_quality = video_quality or "1080p"
        if burn_subtitles is not None:
            self.burn_subtitles = burn_subtitles
        if auto_titles is not None:
            self.auto_titles = auto_titles
        vod_engine.burn_subtitles = self.burn_subtitles
        vod_engine.auto_titles = self.auto_titles
        self.clips_harvested_count = 0
        self.last_error = ""
        self.current_url = youtube_url.strip()
        self.caption_history.clear()

        # Inspeccionar URL para Motor Dual (Live vs VOD)
        logger.info(f"🔍 Inspeccionando tipo de stream/video: {self.current_url}")
        self._broadcast("notification", {
            "message": f"🔍 Inspeccionando URL: {self.current_url}",
            "level": "info"
        })
        meta = vod_engine.inspect_url(self.current_url)
        if meta.get("error"):
            err_raw = str(meta.get("error"))
            if err_raw == "search_url_not_supported":
                err_msg = "URL no válida o búsqueda no soportada. Introduce el enlace directo a un video o directo."
            elif "timed out" in err_raw.lower():
                err_msg = "Tiempo de espera agotado al conectar con el video. Revisa tu conexión o intenta nuevamente."
            else:
                err_msg = err_raw
            self.is_active = False
            self.last_error = err_msg
            logger.error(f"❌ {err_msg} ({self.current_url}) [Detalle: {err_raw}]")
            self._broadcast("notification", {"message": err_msg, "level": "error"})
            self._broadcast("vod_progress", {"text": f"❌ {err_msg}", "percentage": 0})
            self._broadcast("radar_state", {
                "active": False,
                "url": self.current_url,
                "status": "error",
                "error": err_msg
            })
            return

        is_live = meta.get("is_live", False)
        was_live = meta.get("was_live", False)
        duration = meta.get("duration", 0.0)

        if not is_live and (duration > 30.0 or was_live):
            # Modo Video Normal / Directo Finalizado (VOD)
            self.mode = "vod"
            self.is_active = True
            video_title = meta.get("title", "Video VOD")
            logger.info(f"🎥 MODO VOD DETECTADO: '{video_title}' ({duration:.0f}s). Iniciando cosecha de {max_clips} momentos cumbre de {self.clip_duration_sec}s (Calidad: {self.video_quality})...")
            self._broadcast("radar_state", {
                "active": True,
                "url": self.current_url,
                "threshold": self.threshold,
                "mode": "vod",
                "title": video_title,
                "duration": duration,
                "clip_duration_sec": self.clip_duration_sec,
                "video_quality": self.video_quality
            })
            vod_engine.start_vod_harvest(
                url=self.current_url,
                max_clips=max_clips,
                clip_duration_sec=self.clip_duration_sec,
                progress_cb=self._on_vod_progress,
                auto_render_916=self.auto_render_916,
                min_render_score=self.min_render_score,
                video_quality=self.video_quality,
                burn_subtitles=self.burn_subtitles,
                auto_titles=self.auto_titles
            )
            return

        # Modo Directo en Vivo (LIVE)
        self.mode = "live"
        self.is_active = True
        logger.info(f"🔴 MODO DIRECTO EN VIVO: {self.current_url} | Duración: {self.clip_duration_sec}s | Calidad: {self.video_quality}")
        
        # 1. Iniciar Anillo de Retención en RAM con duración y calidad dinámicas
        self.ring_buffer.start(self.current_url, clip_duration_sec=self.clip_duration_sec, video_quality=self.video_quality)

        # 2. Iniciar Sensor de Navegador de forma desacoplada (opcional en segundo plano)
        try:
            self.sensor.start(self.current_url, self._on_sensor_event)
        except Exception as e:
            logger.warning(f"Sensor CDP no disponible (modo 100% nativo activo): {e}")

        # 3. Iniciar Hilo de Cosecha Continua e Ininterrumpida
        self.harvest_thread = threading.Thread(
            target=self._harvest_loop,
            args=(current_session, self.stop_event),
            daemon=True
        )
        self.harvest_thread.start()

        self._broadcast("radar_state", {
            "active": True,
            "url": self.current_url,
            "threshold": self.threshold,
            "mode": "live",
            "title": meta.get("title", "Directo en Vivo"),
            "clip_duration_sec": self.clip_duration_sec,
            "video_quality": self.video_quality
        })

    def stop(self):
        """Detiene todos los componentes del radar, vacía la cola y limpia huérfanos."""
        self.is_active = False
        with self.lock:
            self.session_id += 1
            if hasattr(self, "stop_event") and self.stop_event:
                self.stop_event.set()
            self.harvested_segments.clear()
        
        try:
            vod_engine.stop()
        except Exception:
            pass
        
        try:
            self.sensor.stop()
        except Exception:
            pass
            
        self.ring_buffer.stop_and_reset_pipeline()
        
        # Vaciar inmediatamente la cola de renders pendientes de Stage 2
        try:
            stage2_queue.clear_queue()
        except Exception as e:
            logger.warning(f"Error vaciando cola en stop(): {e}")

        if self.harvest_thread and self.harvest_thread.is_alive():
            self.harvest_thread.join(timeout=1.5)
        self.harvest_thread = None

        logger.info("🛑 Radar detenido, cola 9:16 vaciada y pipeline reseteado limpiamente.")
        self._broadcast("radar_state", {
            "active": False,
            "url": "",
            "threshold": self.threshold,
            "mode": self.mode,
            "status": "⏹️ Detenido por el usuario"
        })

    def set_threshold(self, new_threshold: float):
        """Ajusta dinámicamente la nota de corte."""
        self.threshold = round(float(new_threshold), 1)
        logger.info(f"Sensibilidad ajustada a {self.threshold}/10")
        self._broadcast("threshold_updated", {"threshold": self.threshold})

    def _on_sensor_event(self, event: Dict[str, Any]):
        """Receptor desacoplado de eventos opcionales desde el navegador vía CDP/Inyector."""
        evt_type = event.get("type")
        player_time = float(event.get("player_time", 0.0))
        now = time.time()

        if evt_type == "caption":
            text = event.get("text", "").strip()
            if text:
                with self.lock:
                    self.caption_history.append({
                        "text": text,
                        "player_time": player_time,
                        "timestamp": now
                    })
                    cutoff = now - 180.0
                    self.caption_history = [c for c in self.caption_history if c["timestamp"] >= cutoff]

                self.current_telemetry["last_text"] = text
                self.current_telemetry["player_time"] = player_time
                self._broadcast("live_caption", {
                    "text": text,
                    "player_time": round(player_time, 1)
                })

    def _harvest_loop(self, session_id: int, stop_event: threading.Event):
        """
        Bucle de Cosecha Continua (PROHIBIDO DETENERSE O DESCARTAR):
        Cada ciclo (45s) analiza los fragmentos .ts en buffer, selecciona la sub-ventana
        de 30-45s con mayor pico y dinamismo acústico, ejecuta ASR (umbral 0.35, filtro 3 palabras)
        y extrae el clip garantizado. Protegido por session_id y harvest_lock para evitar hilos duplicados.
        """
        logger.info(f"🌾 Iniciando motor de Cosecha Continua (Sesión #{session_id})...")
        
        # Esperar 20 segundos iniciales para acumular los primeros fragmentos en el buffer
        if stop_event.wait(timeout=20.0):
            logger.info(f"🌾 Cosecha (Sesión #{session_id}) cancelada durante espera inicial.")
            return

        cycle_interval_sec = max(30.0, float(self.clip_duration_sec))  # Generar clip continuo ajustado a duración objetivo
        min_candidate_segs = max(3, int(round(self.clip_duration_sec / 5.0)))

        while self.is_active and self.session_id == session_id and not stop_event.is_set():
            loop_start = time.time()
            sleep_time = cycle_interval_sec

            try:
                # 1. Watchdog: verificar estancamiento del buffer en RAM (> 15s)
                revived = self.ring_buffer.check_watchdog(max_staleness_sec=15.0)
                if revived:
                    logger.warning("⚠️ Watchdog reinició el stream por estancamiento. Esperando 6s...")
                    if stop_event.wait(timeout=6.0):
                        break

                if not self.is_active or self.session_id != session_id or stop_event.is_set():
                    break

                # 2. Obtener fragmentos ordenados disponibles en el buffer
                available_segments = self.ring_buffer.get_ordered_segments()
                buf_status = self.ring_buffer.get_status()

                # Deduplicación inteligente: descartar fragmentos ya cosechados
                unharvested_segments = [s for s in available_segments if self._get_seg_sig(s) not in self.harvested_segments]

                if self.harvested_segments and len(unharvested_segments) < min(5, min_candidate_segs):
                    logger.info(f"⏳ Esperando fragmentos nuevos en buffer ({len(unharvested_segments)}/{min(5, min_candidate_segs)} nuevos tras último clip)...")
                    if stop_event.wait(timeout=5.0):
                        break
                    continue

                if self.harvested_segments and unharvested_segments:
                    first_new_idx = available_segments.index(unharvested_segments[0])
                    overlap_idx = max(0, first_new_idx - 2)
                    candidate_segments = available_segments[overlap_idx:]
                else:
                    candidate_segments = available_segments

                if len(candidate_segments) >= min_candidate_segs:
                    # 3. Localizar la sub-ventana con mayor pico y actividad acústica relativa
                    selected_segs, acoustic_metrics = find_best_acoustic_window(
                        candidate_segments,
                        target_duration_sec=self.clip_duration_sec,
                        segment_duration_sec=5
                    )

                    # Verificar que la sub-ventana contenga al menos 70% de fragmentos nuevos
                    if self.harvested_segments:
                        new_count = sum(1 for s in selected_segs if self._get_seg_sig(s) not in self.harvested_segments)
                        if len(selected_segs) > 0 and (new_count / len(selected_segs)) < 0.70:
                            logger.info(f"⏳ Sub-ventana candidata contiene menos del 70% de fragmentos nuevos ({new_count}/{len(selected_segs)} nuevos). Esperando...")
                            if stop_event.wait(timeout=5.0):
                                break
                            continue

                    peak_level = acoustic_metrics["peak_level"]
                    rms_energy = acoustic_metrics["rms_energy"]
                    dynamic_variance = acoustic_metrics["dynamic_variance"]

                    # Actualizar telemetría directa desde audio nativo
                    self.current_telemetry["peak_level"] = peak_level
                    self.current_telemetry["peak"] = peak_level
                    self.current_telemetry["rms_energy"] = rms_energy
                    self.current_telemetry["dynamic_variance"] = dynamic_variance
                    self.current_telemetry["buffered_seconds"] = buf_status.get("seconds_buffered", 0)
                    self.current_telemetry["ram_mb"] = buf_status.get("ram_mb", 0.0)
                    self._broadcast("telemetry", self.current_telemetry)

                    # 4. Micro-transcripción ASR protegida por harvest_lock y verificación de sesión
                    asr_text = ""
                    asr_words = 0
                    asr_segments = []
                    asr_no_speech_prob = 0.0
                    has_spoken_words = False
                    clip_metadata = None

                    # 4. Preparación de audio bajo harvest_lock breve (< 0.1s)
                    extracted_ok = False
                    with self.harvest_lock:
                        if not self.is_active or self.session_id != session_id or stop_event.is_set():
                            logger.info(f"🛑 [ASR Cosecha] Sesión #{session_id} abortada antes de ASR.")
                            break

                        existing_segs = [s for s in selected_segs if s.exists()]
                        if len(existing_segs) < 3:
                            logger.warning(f"⚠️ Fragmentos borrados durante preparación ASR ({len(existing_segs)}/{len(selected_segs)}). Reintentando ciclo...")
                            if stop_event.wait(timeout=5.0):
                                break
                            continue

                        if peak_level >= self.audio_threshold or rms_energy >= 0.01:
                            logger.info(f"🎙️ [ASR Cosecha] Extrayendo audio a SHM (Pico: {peak_level:.2f}, RMS: {rms_energy:.4f})...")
                            self._broadcast("notification", {
                                "message": f"🎙️ Analizando momento de audio con Whisper (Pico: {peak_level:.2f})...",
                                "level": "info"
                            })
                            extracted_ok = self.asr.extract_audio_to_shm(existing_segs)

                    # Micro-transcripción ASR 100% FUERA de harvest_lock (con cancel_check < 1s)
                    if extracted_ok:
                        asr_data = self.asr.transcribe_wav(
                            cancel_check=lambda: not self.is_active or self.session_id != session_id or stop_event.is_set()
                        )
                        asr_text = asr_data.get("text", "").strip()
                        asr_words = asr_data.get("words", 0)
                        asr_segments = asr_data.get("segments", [])
                        asr_no_speech_prob = float(asr_data.get("avg_no_speech_prob", 0.0))
                        logger.info(f"🎙️ ASR resultado: {asr_words} palabras ('{asr_text[:60]}...')")
                        if asr_words > 0:
                            snippet = asr_text[:50] + ("..." if len(asr_text) > 50 else "")
                            self._broadcast("notification", {
                                "message": f"🎙️ Whisper: {asr_words} palabras transcribidas (\"{snippet}\")",
                                "level": "info"
                            })
                        
                        if asr_words >= self.min_words_filter:
                            has_spoken_words = True

                    # VERIFICACIÓN CRÍTICA POST-ASR:
                    if not self.is_active or self.session_id != session_id or stop_event.is_set():
                        logger.info(f"🛑 [ASR Cosecha] Sesión #{session_id} invalidada tras transcripción ASR. Abortando extracción.")
                        break

                    # 5. Respaldo opcional de subtítulos de CDP si ASR no arrojó palabras
                    with self.lock:
                        recent_subs = list(self.caption_history)
                        self.caption_history.clear()

                    if not has_spoken_words and recent_subs:
                        cdp_text = " ".join([s.get("text", "") for s in recent_subs]).strip()
                        cdp_words = len(cdp_text.split())
                        if cdp_words >= self.min_words_filter:
                            asr_text = cdp_text
                            asr_words = cdp_words
                            has_spoken_words = True

                    # 6. Evaluar en Modo Cosecha Continua
                    sub_entries = [{"text": asr_text}] if asr_text else []
                    eval_metrics = dict(acoustic_metrics)
                    eval_metrics["no_speech_prob"] = asr_no_speech_prob
                    evaluation = evaluate_harvest_window(
                        acoustic_metrics=eval_metrics,
                        entries=sub_entries,
                        custom_threshold=self.threshold
                    )

                    # Enriquecer con transcripción y generar título gancho con cita textual
                    if has_spoken_words:
                        evaluation["has_subtitles"] = True
                        evaluation["texto_completo"] = asr_text
                        evaluation["palabras"] = asr_words
                        evaluation["transcripcion_segmentos"] = asr_segments
                        evaluation["modo_transcripcion"] = "lazy_whisper_asr"
                        
                        sample_quote = asr_text[:38].rstrip()
                        if len(asr_text) > 38:
                            sample_quote += "..."
                        if peak_level >= 0.70:
                            evaluation["titulo_gancho"] = f"¡MOMENTO CLAVE! \"{sample_quote}\""
                        else:
                            evaluation["titulo_gancho"] = f"¡EN DIRECTO! \"{sample_quote}\""
                    else:
                        evaluation["has_subtitles"] = False
                        evaluation["modo_transcripcion"] = "native_audio_harvest"

                    self.last_evaluation = evaluation
                    self._broadcast("window_evaluated", evaluation)

                    # 7. Extracción y Empaquetado Inmediato del Clip bajo harvest_lock (< 0.5s)
                    with self.harvest_lock:
                        valid_render_segs = [s for s in selected_segs if s.exists()]
                        if len(valid_render_segs) < 3 or not self.is_active or self.session_id != session_id or stop_event.is_set():
                            logger.warning("Fragmentos seleccionados no disponibles o sesión finalizada. Cancelando empaquetado.")
                            break

                        logger.info(
                            f"🎬 [Cosecha Continua #{session_id}] Extrayendo clip: {len(valid_render_segs)} fragmentos (~{len(valid_render_segs)*5}s) | "
                            f"Pico: {peak_level:.2f} | RMS: {rms_energy:.4f} | "
                            f"Palabras: {asr_words} | Titular: {evaluation['titulo_gancho']}"
                        )
                        clip_metadata = self.extractor.extract_clip(
                            evaluation_result=evaluation,
                            ring_buffer=self.ring_buffer,
                            youtube_url=self.current_url,
                            selected_segments=valid_render_segs,
                            target_duration_sec=self.clip_duration_sec
                        )
                    if not self.is_active or self.session_id != session_id or stop_event.is_set():
                        logger.info(f"🛑 [Cosecha #{session_id}] Sesión cerrada tras extracción. No se emitirá ni encolará.")
                        break

                    if clip_metadata:
                        self.clips_harvested_count += 1
                        clip_fname = clip_metadata.get("video_file", f"{clip_metadata['clip_id']}.mp4")

                        # Registrar fragmentos consumidos en esta sesión para evitar cosechas duplicadas
                        if valid_render_segs:
                            last_seg = valid_render_segs[-1]
                            try:
                                last_idx = available_segments.index(last_seg)
                                for s in available_segments[:last_idx + 1]:
                                    self.harvested_segments.add(self._get_seg_sig(s))
                            except ValueError:
                                for s in valid_render_segs:
                                    self.harvested_segments.add(self._get_seg_sig(s))

                        logger.info(f"✨ ¡CLIP COSECHADO CON ÉXITO! ({self.clips_harvested_count}/{self.max_clips}) {clip_fname} ({clip_metadata.get('file_size_mb', 0)} MB)")
                        self._broadcast("new_clip_extracted", clip_metadata)
                        self._broadcast("clip_created", {
                            "filename": clip_fname,
                            "clip": clip_metadata
                        })

                        # Encolar automáticamente a Etapa 2 (9:16) si está habilitado y supera nota
                        if self.auto_render_916 and self.session_id == session_id and not stop_event.is_set():
                            clip_score = float(clip_metadata.get("score", 7.0))
                            if clip_score >= self.min_render_score:
                                cfg_mode = load_config().get("default_framing_mode", "AUTO")
                                logger.info(f"🚀 Auto-enviando {clip_metadata['clip_id']} (score {clip_score}, modo {cfg_mode}, calidad {self.video_quality}) a cola de Shorts 9:16...")
                                stage2_queue.enqueue(
                                    clip_metadata["clip_id"],
                                    framing_mode=cfg_mode,
                                    video_quality=self.video_quality,
                                    session_id=self.session_id,
                                    is_manual=False,
                                    burn_subtitles=getattr(self, "burn_subtitles", True),
                                    auto_titles=getattr(self, "auto_titles", True)
                                )
                            else:
                                logger.warning(f"⏭️ [Live] Clip {clip_metadata['clip_id']} omitido de cola 9:16 por nota baja ({clip_score:.1f} < {self.min_render_score:.1f}).")

                        # Verificar si se alcanzó el límite máximo de clips configurado
                        if self.max_clips > 0 and self.clips_harvested_count >= self.max_clips:
                            logger.info(f"✅ Límite de clips alcanzado: {self.clips_harvested_count}/{self.max_clips} clips. Finalizando captura automática.")
                            self.is_active = False
                            self._broadcast("radar_state", {
                                "active": False,
                                "url": self.current_url,
                                "mode": "live",
                                "status": f"✅ Completado ({self.clips_harvested_count}/{self.max_clips} clips generados)"
                            })
                            self.ring_buffer.stop_and_reset_pipeline()
                            break
                    else:
                        logger.warning("Fallo en empaquetado del clip, reintentando en próximo ciclo...")

                    elapsed = time.time() - loop_start
                    sleep_time = max(5.0, cycle_interval_sec - elapsed)
                else:
                    logger.info(f"⏳ Acumulando buffer en {self.ring_buffer.buffer_dir} ({len(available_segments)}/5 fragmentos necesarios)...")
                    sleep_time = 5.0  # Revisar en 5s sin esperar 45s enteros

            except Exception as e:
                # Blindaje global: una excepción jamás interrumpe la cosecha continua
                logger.error(f"❌ Excepción capturada en ciclo de cosecha: {e}", exc_info=True)
                sleep_time = 10.0

            # Esperar hasta el próximo ciclo respetando stop_event
            if stop_event.wait(timeout=sleep_time):
                break

        logger.info(f"🛑 Motor de Cosecha Continua (Sesión #{session_id}) finalizado.")

    def get_status(self) -> Dict[str, Any]:
        """Estado global consolidado para la API y Dashboard."""
        buf_status = self.ring_buffer.get_status()
        return {
            "active": self.is_active,
            "url": self.current_url,
            "threshold": self.threshold,
            "clip_duration_sec": self.clip_duration_sec,
            "video_quality": self.video_quality,
            "mode": self.mode,
            "auto_render_916": self.auto_render_916,
            "min_render_score": self.min_render_score,
            "telemetry": self.current_telemetry,
            "ring_buffer": buf_status,
            "last_evaluation": self.last_evaluation,
            "total_clips": len(self.extractor.list_clips())
        }

    def list_clips(self) -> List[Dict[str, Any]]:
        return self.extractor.list_clips()
