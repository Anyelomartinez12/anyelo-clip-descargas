"""Muestra la URL LAN para abrir Anyelo Clip desde un teléfono en la misma Wi-Fi."""
import socket

def main():
    ip = None
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # UDP connect solo selecciona la interfaz local; no envía datos.
        sock.connect(("192.0.2.1", 80))
        candidate = sock.getsockname()[0]
        if candidate and not candidate.startswith("127."):
            ip = candidate
    except OSError:
        pass
    finally:
        sock.close()
    if not ip:
        for item in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            candidate = item[4][0]
            if candidate and not candidate.startswith(("127.", "169.254.")):
                ip = candidate
                break
    if ip:
        print(f"En el teléfono, conectado a la misma Wi-Fi, abre: http://{ip}:8765")
    else:
        print("No pude detectar una IP Wi-Fi. En la PC ejecuta ipconfig y usa su IPv4 con :8765")

if __name__ == "__main__":
    main()
