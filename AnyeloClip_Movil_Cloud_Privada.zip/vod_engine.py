"""
vod_engine.py - Motor de Procesamiento y Clipping para Videos Normales (VOD).
Inspecciona metadatos con yt-dlp, extrae únicamente audio mono 16kHz a /dev/shm/vod_audio.wav,
escanea ventanas acústicas con NumPy (+ heatmap de YouTube), transcribe momentos cumbre con
faster-whisper, y descarga únicamente los fragmentos seleccionados en 1080p sin bajar el video completo.
Incluye reporte de progreso porcentual en tiempo real y soporte para clipeo manual instantáneo.
"""

import os
import wave
import json
import time
import math
import logging
import threading
import subprocess
from pathlib import Path
from typing import Dict, Any, List, Optional, Callable
import numpy as np

from asr_fallback import LazyWhisperASR
from evaluator import evaluate_harvest_window
from extractor import snap_to_sentence_boundaries
from native_audio import compute_vocal_metrics, compute_spectral_flux
from stage2_worker import stage2_queue
from os_compat import (
    get_shm_dir, get_shm_path, get_ffmpeg_cmd, get_ffprobe_cmd, get_ytdlp_cmd,
    build_ytdlp_js_runtime_args, clean_dir_patterns, kill_process_tree, get_subprocess_flags
)
import stream_resolver

logger = logging.getLogger("vod_engine")
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

BASE_DIR = Path(__file__).resolve().parent
INBOX_BRUTOS = BASE_DIR / "inbox_brutos"
VOD_AUDIO_PATH = get_shm_path("vod_audio.wav")


def format_time_hms(seconds: float) -> str:
    """Convierte segundos a formato HH:MM:SS."""
    if seconds < 0:
        seconds = 0
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def deduplicate_windows(
    candidates: List[Any],
    iou_thresh: float = 0.25,
    min_gap_sec: float = 15.0
) -> List[Any]:
    """
    1D NMS: Ordena los candidatos por score descendente.
    Acepta un candidato solo si para todos los ya aceptados:
    iou <= iou_thresh AND gap >= min_gap_sec
    donde gap = max(0.0, max(a_start, b_start) - min(a_end, b_end)).
    """
    if not candidates:
        return []

    is_tuple = isinstance(candidates[0], (tuple, list))
    parsed = []
    for idx, c in enumerate(candidates):
        if is_tuple:
            s, e, sc = c[0], c[1], c[2]
        else:
            s, e, sc = c.get("start", c.get("start_sec", 0.0)), c.get("end", c.get("end_sec", 0.0)), c.get("score", 0.0)
        parsed.append({"idx": idx, "start": float(s), "end": float(e), "score": float(sc), "orig": c})

    parsed.sort(key=lambda x: x["score"], reverse=True)

    accepted = []
    for cand in parsed:
        c_start, c_end = cand["start"], cand["end"]
        keep = True
        for acc in accepted:
            a_start, a_end = acc["start"], acc["end"]
            inter = max(0.0, min(c_end, a_end) - max(c_start, a_start))
            union = (c_end - c_start) + (a_end - a_start) - inter
            iou = inter / (union + 1e-6)
            gap = max(0.0, max(c_start, a_start) - min(c_end, a_end))
            if iou > iou_thresh or gap < min_gap_sec:
                keep = False
                break
        if keep:
            accepted.append(cand)

    return [x["orig"] for x in accepted]


class VODEngine:
    def __init__(self, inbox_dir: Path = INBOX_BRUTOS):
        self.inbox_dir = inbox_dir
        self.inbox_dir.mkdir(parents=True, exist_ok=True)
        self.asr = LazyWhisperASR()
        self.is_running = False
        self.session_id: int = 0
        self.stop_event: threading.Event = threading.Event()
        self.active_processes: set = set()
        self.proc_lock: threading.RLock = threading.RLock()
        self.worker_thread: Optional[threading.Thread] = None
        self.current_progress: Dict[str, Any] = {
            "text": "Inactivo",
            "percentage": 0.0,
            "current_sec": 0.0,
            "total_sec": 0.0,
            "current_clip": 0,
            "total_clips": 0
        }
        self.current_full_audio_path: Optional[Path] = None
        self.current_cached_video_url: Optional[str] = None
        self.auto_render_916: bool = True
        self.min_render_score: float = 5.0
        from config_manager import load_config
        _cfg = load_config()
        self.burn_subtitles: bool = _cfg.get("burn_subtitles", True)
        self.auto_titles: bool = _cfg.get("auto_titles", True)
        self.clip_callbacks: List[Callable[[Dict[str, Any]], None]] = []

    def _run_cmd(self, cmd: List[str], cwd: Optional[Path] = None, timeout: Optional[float] = None) -> subprocess.CompletedProcess:
        """Ejecuta subprocesos ffmpeg/yt-dlp registrándolos para exterminio inmediato en caso de stop_event."""
        sub_flags = get_subprocess_flags(low_priority=True)
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd=str(cwd) if cwd else None,
            **sub_flags
        )
        with self.proc_lock:
            self.active_processes.add(proc)

        try:
            stdout, stderr = proc.communicate(timeout=timeout)
        except Exception:
            kill_process_tree(proc)
            try:
                proc.communicate(timeout=2)
            except Exception:
                pass
            raise
        finally:
            with self.proc_lock:
                self.active_processes.discard(proc)

        return subprocess.CompletedProcess(cmd, proc.returncode, stdout, stderr)

    @staticmethod
    def _get_h264_video_only_format(video_quality: str) -> str:
        """Selector de solo-video H.264 priorizando avc1 según calidad solicitada."""
        vq = (video_quality or "1080p").lower()
        if vq == "480p":
            return "bestvideo[height<=480][vcodec^=avc1]/bestvideo[height<=480]"
        if vq == "720p":
            return "bestvideo[height<=720][vcodec^=avc1]/bestvideo[height<=720]"
        if vq == "max":
            return "bestvideo[vcodec^=avc1]/bestvideo"
        return "bestvideo[height<=1080][vcodec^=avc1]/bestvideo[height<=1080]"

    def _resolve_cached_video_url(self, url: str, video_quality: str) -> Optional[str]:
        """Resuelve una sola vez la URL directa de video H.264 con yt-dlp -g para acelerar todos los cortes VOD."""
        h264_only_fmt = self._get_h264_video_only_format(video_quality)
        cmd = [
            *get_ytdlp_cmd(), "--no-update", "--no-playlist",
            *stream_resolver.build_ytdlp_js_runtime_args(url=url),
            "-g", "-f", h264_only_fmt,
            url
        ]
        try:
            res = self._run_cmd(cmd, timeout=30)
            if res.returncode == 0 and res.stdout:
                for line in res.stdout.splitlines():
                    cand = line.strip()
                    if cand.startswith("http"):
                        logger.info(f"⚡ [VOD Engine] URL directa H.264 cacheada para cortes rápidos ({video_quality}).")
                        return cand
        except Exception as e:
            logger.warning(f"Aviso resolviendo URL directa H.264 con yt-dlp -g: {e}")
        return None

    def register_clip_callback(self, cb: Callable[[Dict[str, Any]], None]):
        """Registra callback que se invoca cuando se genera un clip (manual o automático)."""
        self.clip_callbacks.append(cb)

    def _notify_clip_created(self, clip_meta: Dict[str, Any]):
        for cb in list(self.clip_callbacks):
            try:
                cb(clip_meta)
            except Exception as e:
                logger.error(f"Error en callback de clip VOD: {e}")

    @staticmethod
    def _strip_js_runtimes(extra_args: List[str]) -> List[str]:
        """Elimina --js-runtimes y su valor manteniendo el resto de argumentos (ej. --cookies)."""
        cleaned: List[str] = []
        skip_next = False
        for arg in extra_args:
            if skip_next:
                skip_next = False
                continue
            if arg == "--js-runtimes":
                skip_next = True
                continue
            cleaned.append(arg)
        return cleaned

    @staticmethod
    def _classify_ytdlp_error(stderr_text: str, exc: Optional[Exception] = None) -> str:
        """Traduce stderr real de yt-dlp a un mensaje diagnóstico accionable."""
        low = (stderr_text or "").lower()
        if "sign in to confirm" in low or "not a bot" in low or "use --cookies" in low:
            return "YouTube bloqueó la consulta (verificación anti-bot). Exporta cookies.txt o reintenta."
        if "private video" in low or "this video is private" in low:
            return "El video es privado o requiere acceso autorizado."
        if "members-only" in low or "join this channel" in low:
            return "Video exclusivo para miembros del canal."
        if "video unavailable" in low or "this video is no longer available" in low or "is not available" in low:
            return "Video no disponible, eliminado o bloqueado por región."
        if "timed out" in low or isinstance(exc, subprocess.TimeoutExpired):
            return "Tiempo de espera agotado al conectar con la plataforma (timeout)."
        if any(k in low for k in ("unable to resolve", "getaddrinfo", "connection", "ssl", "urlopen error", "network")):
            return "Error de conexión o red al consultar la URL."
        if "unsupported url" in low or "is not a valid url" in low:
            return "URL no válida o plataforma no soportada."
        err_lines = [ln.strip() for ln in (stderr_text or "").splitlines() if ln.strip()]
        if err_lines:
            last_err = err_lines[-1]
            for ln in reversed(err_lines):
                if "error:" in ln.lower():
                    last_err = ln
                    break
            return last_err[:220]
        return str(exc) if exc else "Error desconocido consultando la URL."

    @staticmethod
    def _build_ffmpeg_cut_cmd(src_input: str, start_sec: float, duration: float, out_mp4: Path) -> List[str]:
        """Construye comando FFmpeg rápido y con sync A/V estricto para cortes locales o HLS."""
        cut_threads = str(max(2, (os.cpu_count() or 4) // 2))
        return [
            get_ffmpeg_cmd(), "-y", "-hide_banner", "-loglevel", "warning",
            "-fflags", "+genpts",
            "-accurate_seek",
            "-ss", str(start_sec),
            "-i", src_input,
            "-t", str(duration),
            "-threads", cut_threads,
            "-fps_mode", "cfr",
            "-c:v", "libx264", "-preset", "ultrafast", "-crf", "22",
            "-af", "aresample=async=1:first_pts=0",
            "-c:a", "aac", "-b:a", "192k",
            "-avoid_negative_ts", "make_zero",
            "-movflags", "+faststart",
            str(out_mp4)
        ]

    @staticmethod
    def _compute_block_window_acoustics(chunk: np.ndarray, sr: int = 8000) -> Dict[str, float]:
        """Calcula métricas vocales (300-3400Hz), spectral flux y contraste de ráfagas en 1s."""
        if len(chunk) == 0:
            return {"peak": 0.0, "rms": 0.0, "dyn_var": 0.001, "vocal_ratio": 0.0, "flatness": 0.0, "spectral_flux": 0.0, "burst_contrast": 0.0}
        peak = float(np.max(np.abs(chunk)))
        rms = float(np.sqrt(np.mean(chunk ** 2)))
        dyn_var = float(np.var(chunk)) if len(chunk) > 1 else 0.001

        vocal_met = compute_vocal_metrics(chunk, sr=sr)
        vocal_ratio = float(vocal_met.get("vocal_ratio", 0.0))
        flatness = float(vocal_met.get("flatness", 0.0))
        spectral_flux = float(compute_spectral_flux(chunk, frame_size=512, hop_size=256))

        n_sec = len(chunk) // sr
        if n_sec >= 2:
            sec_frames = chunk[:n_sec * sr].reshape((n_sec, sr))
            sec_rms = np.sqrt(np.mean(sec_frames ** 2, axis=1))
            p95_rms = float(np.percentile(sec_rms, 95))
            med_rms = float(np.median(sec_rms))
            burst_contrast = float(np.clip((p95_rms - med_rms) / (med_rms + 0.01), 0.0, 2.0))
        else:
            burst_contrast = 0.0

        return {
            "peak": peak,
            "rms": rms,
            "dyn_var": dyn_var,
            "vocal_ratio": vocal_ratio,
            "flatness": flatness,
            "spectral_flux": spectral_flux,
            "burst_contrast": burst_contrast
        }

    def inspect_url(self, url: str) -> Dict[str, Any]:
        """
        Inspecciona metadatos del video con stream_resolver y yt-dlp sin descargar.
        Determina si es directo (is_live) o video VOD normal soportando YouTube, Twitch, Kick y TikTok.
        """
        clean_url = url.strip()

        # Regla 0: Archivo de video local (.mp4, .mkv, .mov, etc.)
        p_local = Path(clean_url)
        if p_local.is_file():
            dur = 0.0
            try:
                ffprobe = get_ffprobe_cmd()
                pr = subprocess.run([
                    ffprobe, "-v", "error", "-show_entries", "format=duration",
                    "-of", "default=noprint_wrappers=1:nokey=1", str(p_local.resolve())
                ], capture_output=True, text=True, timeout=10.0)
                dur = float(pr.stdout.strip() or 0.0)
            except Exception:
                pass
            logger.info(f"📁 [VOD Engine] Archivo local detectado: '{p_local.name}' ({dur:.1f}s)")
            return {
                "is_live": False,
                "was_live": False,
                "title": p_local.stem,
                "duration": dur,
                "heatmap": [],
                "id": p_local.stem,
                "channel": "Archivo Local",
                "platform": "local",
                "is_local_file": True
            }

        platform = stream_resolver.detect_platform(clean_url)
        chan_info = stream_resolver.parse_channel_info(clean_url)

        # Regla 1: TikTok Live siempre fuerza LIVE (nunca VOD)
        if platform == "tiktok":
            logger.info(f"🎵 [VOD Engine] TikTok Live detectado ({clean_url}). Forzando modo LIVE estricto.")
            return {
                "is_live": True,
                "was_live": False,
                "title": f"TikTok Live {chan_info.get('channel') or ''}".strip(),
                "duration": 0.0,
                "heatmap": [],
                "id": chan_info.get("channel") or "tiktok_live",
                "channel": chan_info.get("channel") or "TikTok",
                "platform": "tiktok"
            }

        # Regla 2: Kick (Live o VOD)
        if platform == "kick":
            if chan_info.get("is_vod") and chan_info.get("video_id"):
                v_uuid = chan_info.get("video_id")
                m3u8 = stream_resolver.resolve_kick_vod_m3u8(v_uuid)
                if m3u8:
                    logger.info(f"🟢 [VOD Engine] Kick VOD detectado para UUID '{v_uuid}'.")
                    dur = 3600.0
                    try:
                        ffprobe_bin = get_ffprobe_cmd()
                        p_res = subprocess.run([
                            ffprobe_bin, "-v", "error", "-show_entries", "format=duration",
                            "-of", "default=noprint_wrappers=1:nokey=1", m3u8
                        ], capture_output=True, text=True, timeout=8)
                        val = float(p_res.stdout.strip())
                        if val > 0:
                            dur = val
                    except Exception:
                        pass
                    return {
                        "is_live": False,
                        "was_live": True,
                        "title": f"Kick VOD - {v_uuid[:8]}",
                        "duration": dur,
                        "heatmap": [],
                        "id": v_uuid,
                        "channel": chan_info.get("channel") or "Kick",
                        "platform": "kick",
                        "m3u8_url": m3u8
                    }
            elif not chan_info.get("is_vod"):
                slug = chan_info.get("channel") or ""
                m3u8 = stream_resolver.resolve_kick_m3u8(slug)
                if m3u8:
                    logger.info(f"🟢 [VOD Engine] Kick Live detectado para '{slug}'. Modo LIVE activo.")
                    return {
                        "is_live": True,
                        "was_live": False,
                        "title": f"Kick Live - {slug}",
                        "duration": 0.0,
                        "heatmap": [],
                        "id": slug,
                        "channel": slug,
                        "platform": "kick",
                        "m3u8_url": m3u8
                    }

        # Regla 3: Twitch Live
        if platform == "twitch" and not chan_info.get("is_vod"):
            st_url = stream_resolver.resolve_twitch_stream_url(clean_url)
            if st_url:
                slug = chan_info.get("channel") or "Twitch"
                logger.info(f"🟣 [VOD Engine] Twitch Live detectado para '{slug}'. Modo LIVE activo.")
                return {
                    "is_live": True,
                    "was_live": False,
                    "title": f"Twitch Live - {slug}",
                    "duration": 0.0,
                    "heatmap": [],
                    "id": slug,
                    "channel": slug,
                    "platform": "twitch"
                }

        if "results?search_query" in clean_url or "/results" in clean_url:
            logger.warning(f"URL de búsqueda detectada '{clean_url}'. Rechazada para evitar bucle.")
            return {"is_live": False, "title": "Búsqueda no soportada", "duration": 0.0, "heatmap": [], "platform": platform, "error": "search_url_not_supported"}

        # Inspección estándar con yt-dlp (YouTube, Twitch VODs, Kick VODs) con reintentos inteligentes
        base_cmd = [*get_ytdlp_cmd(), "--no-update", "--no-playlist"]
        js_and_cookie_args = build_ytdlp_js_runtime_args(url=clean_url)
        no_js_args = self._strip_js_runtimes(js_and_cookie_args)

        attempts: List[tuple] = [("js_runtime", js_and_cookie_args)]
        if no_js_args != js_and_cookie_args:
            attempts.append(("no_js_runtime", no_js_args))
        if platform == "youtube":
            attempts.append(("youtube_android_web", [*no_js_args, "--extractor-args", "youtube:player_client=android,web"]))

        sub_flags = get_subprocess_flags(low_priority=True)
        last_stderr = ""
        last_exc: Optional[Exception] = None

        for label, extra_args in attempts:
            cmd = [
                *base_cmd,
                *extra_args,
                "--dump-json", "--skip-download",
                "--no-warnings",
                clean_url
            ]
            try:
                res = subprocess.run(cmd, capture_output=True, text=True, check=True, timeout=45.0, **sub_flags)
                data = json.loads(res.stdout)
                is_live = bool(data.get("is_live") or (data.get("live_status") in ("is_live", "live")))
                return {
                    "is_live": is_live,
                    "was_live": bool(data.get("was_live") or data.get("live_status") == "post_live"),
                    "title": data.get("title", "Video"),
                    "duration": float(data.get("duration") or 0.0),
                    "heatmap": data.get("heatmap") or [],
                    "id": data.get("id", ""),
                    "channel": data.get("channel", ""),
                    "platform": platform
                }
            except subprocess.CalledProcessError as e:
                last_exc = e
                last_stderr = (e.stderr or "").strip()
                logger.warning(f"⚠️ [inspect_url:{label}] Falló yt-dlp (RC={e.returncode}) para '{clean_url}'. stderr:\n{last_stderr}")
            except Exception as e:
                last_exc = e
                last_stderr = str(getattr(e, "stderr", "") or "").strip()
                logger.warning(f"⚠️ [inspect_url:{label}] Excepción inspeccionando '{clean_url}': {e}" + (f"\n{last_stderr}" if last_stderr else ""))

        err_msg = self._classify_ytdlp_error(last_stderr, last_exc)
        logger.error(f"Error definitivo inspeccionando URL '{clean_url}': {err_msg}")
        return {"is_live": False, "title": "Desconocido", "duration": 0.0, "heatmap": [], "platform": platform, "error": err_msg}

    def start_vod_harvest(
        self,
        url: str,
        max_clips: int = 5,
        clip_duration_sec: int = 60,
        progress_cb: Optional[Callable[[Dict[str, Any]], None]] = None,
        auto_render_916: bool = True,
        min_render_score: float = 5.5,
        video_quality: Optional[str] = None,
        burn_subtitles: Optional[bool] = None,
        auto_titles: Optional[bool] = None
    ):
        """Inicia el proceso de cosecha VOD en un hilo independiente."""
        self.stop()
        with self.proc_lock:
            self.session_id += 1
            self.stop_event = threading.Event()
            self.is_running = True
        self.auto_render_916 = auto_render_916
        self.min_render_score = min_render_score
        if burn_subtitles is not None:
            self.burn_subtitles = burn_subtitles
        if auto_titles is not None:
            self.auto_titles = auto_titles

        sess_id = self.session_id
        stop_evt = self.stop_event

        def _run():
            try:
                self._process_vod(url, max_clips, clip_duration_sec, progress_cb, video_quality=video_quality)
            except Exception as e:
                if not stop_evt.is_set():
                    logger.error(f"Error fatal procesando VOD: {e}", exc_info=True)
                    if progress_cb:
                        progress_cb({"text": f"Error: {e}", "percentage": 0.0})
            finally:
                with self.proc_lock:
                    if self.session_id == sess_id:
                        self.is_running = False

        self.worker_thread = threading.Thread(target=_run, daemon=True)
        self.worker_thread.start()

    def stop(self):
        """Detiene inmediatamente VOD, aborta Whisper y extermina todos los subprocesos en árbol (< 0.1s)."""
        self.is_running = False
        self.stop_event.set()
        with self.proc_lock:
            for proc in list(self.active_processes):
                try:
                    kill_process_tree(proc)
                except Exception as e:
                    logger.debug(f"Error matando subproceso VOD: {e}")
            self.active_processes.clear()

        try:
            if VOD_AUDIO_PATH.exists():
                VOD_AUDIO_PATH.unlink()
        except Exception:
            pass
        if self.worker_thread and self.worker_thread.is_alive():
            self.worker_thread.join(timeout=1.0)
        self.worker_thread = None
        logger.info("🛑 [VOD Engine] Detenido y todos los subprocesos exterminados limpiamente.")

    def extract_single_clip_vod(
        self,
        url: str,
        start_sec: float,
        duration: float = 60.0,
        custom_title: Optional[str] = None,
        video_quality: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Extrae un clip manual exacto de VOD (desde -10s del reproductor).
        Descarga solo ese rango en la calidad solicitada, transcribe con faster-whisper y deja metadatos Etapa 4 listos.
        """
        from config_manager import load_config
        vq = video_quality or load_config().get("video_quality", "1080p")
        start_sec = max(0.0, float(start_sec))
        duration = max(15.0, min(600.0, float(duration)))

        meta = self.inspect_url(url)
        video_title = meta.get("title", "Video VOD")
        total_dur = float(meta.get("duration", 0.0))
        if total_dur > 0 and (start_sec + duration) > total_dur:
            start_sec = max(0.0, total_dur - duration)
            duration = min(duration, total_dur - start_sec)

        end_sec = start_sec + duration

        ts_str = time.strftime("%Y%m%d_%H%M%S")
        clip_id = f"clip_manual_{ts_str}"
        out_mp4 = self.inbox_dir / f"{clip_id}.mp4"
        out_json = self.inbox_dir / f"{clip_id}.json"
        temp_audio = get_shm_path(f"temp_manual_{ts_str}.wav")

        try:
            logger.info(f"🔴 [VOD Manual] Descargando sección {format_time_hms(start_sec)} -> {format_time_hms(end_sec)} ({duration:.0f}s, Calidad: {vq})...")
            
            # 1. Descargar o recortar sección según calidad solicitada con sincronización A/V estricta
            p_local = Path(url)
            if p_local.is_file():
                dl_cmd = self._build_ffmpeg_cut_cmd(str(p_local.resolve()), start_sec, duration, out_mp4)
            else:
                m3u8_url = meta.get("m3u8_url")
                if m3u8_url:
                    dl_cmd = self._build_ffmpeg_cut_cmd(m3u8_url, start_sec, duration, out_mp4)
                else:
                    ytdlp_fmt = stream_resolver.get_ytdlp_format_filter(vq)
                    dl_cmd = [
                        *get_ytdlp_cmd(), "--no-update",
                        "--ffmpeg-location", get_ffmpeg_cmd(),
                        *stream_resolver.build_ytdlp_js_runtime_args(url=url),
                        "--force-keyframes-at-cuts",
                        "--download-sections", f"*{start_sec}-{end_sec}",
                        "-f", ytdlp_fmt,
                        "--downloader-args", "ffmpeg_o:-preset ultrafast -crf 22",
                        "--merge-output-format", "mp4",
                        "-o", str(out_mp4),
                        url
                    ]
            res = self._run_cmd(dl_cmd, timeout=90)
            
            real_out = out_mp4
            if not real_out.exists():
                for alt in self.inbox_dir.glob(f"{clip_id}*"):
                    if alt.is_file() and alt.stat().st_size > 5000 and alt.suffix in (".webm", ".mkv", ".mp4"):
                        real_out = alt
                        break

            if res.returncode != 0 or not real_out.exists():
                logger.error(f"Error descargando fragmento manual VOD: {res.stderr[:300]}")
                return None
            out_mp4 = real_out

            # 2. Extraer audio 16kHz mono para transcripción
            self._run_cmd([
                get_ffmpeg_cmd(), "-y", "-hide_banner", "-loglevel", "error",
                "-i", str(out_mp4),
                "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1",
                str(temp_audio)
            ], timeout=30)

            # 3. Transcribir con faster-whisper (con cancel_check)
            asr_res = self.asr.transcribe_wav(
                temp_audio,
                cancel_check=lambda: not self.is_running or self.stop_event.is_set()
            )
            transcription_text = asr_res.get("text", "").strip()

            # 4. Evaluar métricas y título gancho
            eval_res = evaluate_harvest_window(
                acoustic_metrics={"peak_level": 0.85, "rms_energy": 0.08, "dynamic_variance": 0.002},
                entries=[{"text": transcription_text}] if transcription_text else []
            )
            
            title = custom_title or eval_res.get("titulo_gancho") or f"¡MOMENTO CLAVE VOD! ({format_time_hms(start_sec)})"
            score = eval_res.get("score", 8.8)

            # 5. Generar metadatos incluyendo etapa4_ready
            clip_meta = {
                "id": clip_id,
                "clip_id": clip_id,
                "file_name": out_mp4.name,
                "video_file": out_mp4.name,
                "video_quality": vq,
                "youtube_url": url,
                "video_title": video_title,
                "titulo_gancho": title,
                "score": score,
                "duration": round(duration, 2),
                "duracion_segundos": round(duration, 2),
                "file_size_mb": round(out_mp4.stat().st_size / (1024 * 1024), 2),
                "start_sec": start_sec,
                "end_sec": end_sec,
                "transcription": asr_res,
                "transcripcion_base": transcription_text,
                "palabras": asr_res.get("words", 0),
                "is_manual": True,
                "is_vod": True,
                "created_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                "etapa4_ready": {
                    "source_url": url,
                    "source_type": "vod",
                    "source_offset_start": start_sec,
                    "source_offset_end": end_sec,
                    "duration": round(duration, 2),
                    "timeline_tracks": {
                        "video": [{"src": out_mp4.name, "start": 0.0, "end": round(duration, 2)}],
                        "subtitles": asr_res.get("segments", []),
                        "cuts": [],
                        "overlays": []
                    }
                }
            }

            with open(out_json, "w", encoding="utf-8") as jf:
                json.dump(clip_meta, jf, indent=2, ensure_ascii=False)

            self._notify_clip_created(clip_meta)
            logger.info(f"✨ [VOD Manual] Clip guardado: {out_mp4.name} (Score: {score})")
            return clip_meta
        finally:
            # Limpiar audio temporal garantizado en try/finally
            try:
                if temp_audio.exists():
                    temp_audio.unlink()
            except Exception:
                pass

    def _extract_and_package_candidate(
        self,
        m_start: float,
        m_end: float,
        candidate_idx: int,
        total_candidates: int,
        url: str,
        video_title: str,
        total_duration: float,
        vq: str,
        peak: float = 0.8,
        rms: float = 0.08,
        dyn_var: float = 0.001,
        heatmap_val: float = 0.0,
        m3u8_url: Optional[str] = None,
        local_audio_path: Optional[Path] = None,
        spectral_flux: float = 0.0,
        vocal_ratio: float = 0.0,
        flatness: float = 0.0,
        cached_video_url: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """Extrae, transcribe con Sentence Snapping, empaqueta y emite un clip VOD con subprocesos vigilados."""
        if not self.is_running or self.stop_event.is_set():
            return None

        p_local = Path(url)
        temp_cand_wav = get_shm_path(f"temp_cand_{self.session_id}_{candidate_idx}.wav")
        dur = max(0.1, round(m_end - m_start, 2))
        cand_audio_src = local_audio_path or getattr(self, "current_full_audio_path", None)

        try:
            # 1. Extraer fragmento de audio mono 16kHz
            if cand_audio_src and Path(cand_audio_src).is_file():
                audio_cmd = [
                    get_ffmpeg_cmd(), "-y", "-hide_banner", "-loglevel", "warning",
                    "-ss", str(m_start), "-t", str(dur),
                    "-i", str(Path(cand_audio_src).resolve()),
                    "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1",
                    str(temp_cand_wav)
                ]
                res_audio = self._run_cmd(audio_cmd, timeout=30)
            elif p_local.is_file():
                audio_cmd = [
                    get_ffmpeg_cmd(), "-y", "-hide_banner", "-loglevel", "warning",
                    "-ss", str(m_start), "-t", str(dur),
                    "-i", str(p_local.resolve()),
                    "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1",
                    str(temp_cand_wav)
                ]
                res_audio = self._run_cmd(audio_cmd, timeout=30)
            elif m3u8_url:
                audio_cmd = [
                    get_ffmpeg_cmd(), "-y", "-hide_banner", "-loglevel", "warning",
                    "-headers", f"User-Agent: {stream_resolver.DESKTOP_UA}\r\n",
                    "-ss", str(m_start), "-t", str(dur),
                    "-i", m3u8_url,
                    "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1",
                    str(temp_cand_wav)
                ]
                res_audio = self._run_cmd(audio_cmd, timeout=30)
            else:
                logger.warning(f"Audio local no disponible para candidato {candidate_idx}. Usando fallback remoto yt-dlp (timeout 120s)...")
                audio_cmd = [
                    *get_ytdlp_cmd(), "--no-update",
                    "--ffmpeg-location", get_ffmpeg_cmd(),
                    *stream_resolver.build_ytdlp_js_runtime_args(url=url),
                    "--download-sections", f"*{m_start}-{m_end}",
                    "-f", "ba/b",
                    "-x", "--audio-format", "wav",
                    "--postprocessor-args", "ffmpeg:-ac 1 -ar 16000",
                    "-o", str(temp_cand_wav),
                    url
                ]
                res_audio = self._run_cmd(audio_cmd, timeout=120)
            has_valid_audio = res_audio.returncode == 0 and temp_cand_wav.exists() and temp_cand_wav.stat().st_size >= 1000
            transcription_text = ""
            sub_segments = []
            asr_res = {"text": "", "segments": [], "words": 0}

            if not self.is_running or self.stop_event.is_set():
                return None

            if has_valid_audio:
                # 2. Transcripción ASR rápida con cancel_check
                asr_res = self.asr.transcribe_wav(
                    temp_cand_wav,
                    cancel_check=lambda: not self.is_running or self.stop_event.is_set()
                )
                transcription_text = asr_res.get("text", "").strip()
                sub_segments = asr_res.get("segments", [])
            else:
                logger.warning(f"Audio temporal no disponible para candidato {candidate_idx}, continuando con recorte directo.")

            if not self.is_running or self.stop_event.is_set():
                return None

            # Sentence Snapping: ajustar límites a bordes de frases
            if sub_segments:
                rel_s, rel_e = snap_to_sentence_boundaries(0.0, float(m_end - m_start), sub_segments, margin_sec=3.0)
                m_start = max(0.0, round(m_start + rel_s, 2))
                m_end = min(total_duration, round(m_start + (rel_e - rel_s), 2))

            # Evaluación acústica y gancho
            eval_res = evaluate_harvest_window(
                acoustic_metrics={
                    "peak_level": peak,
                    "rms_energy": rms,
                    "dynamic_variance": dyn_var,
                    "spectral_flux": spectral_flux,
                    "vocal_ratio": vocal_ratio,
                    "flatness": flatness,
                    "no_speech_prob": float(asr_res.get("avg_no_speech_prob", 0.0)),
                    "duration_sec": dur
                },
                entries=[{"text": transcription_text}] if transcription_text else []
            )
            curr_str = format_time_hms(m_start)
            sample_quote = transcription_text[:35].rstrip() + ("..." if len(transcription_text) > 35 else "")
            titulo_gancho = eval_res.get("titulo_gancho") or (f"¡MOMENTO CLAVE! \"{sample_quote}\"" if transcription_text else f"¡MOMENTO EN VOD! ({curr_str})")
            score_final = eval_res.get("score", 7.5)
            if heatmap_val > 0:
                score_final = min(9.9, round(score_final + (heatmap_val * 1.5), 1))

            # 3. Descargar y cortar sección de video
            clip_timestamp = time.strftime("%Y%m%d_%H%M%S")
            clip_id = f"clip_vod_{clip_timestamp}_{candidate_idx}"
            out_mp4 = self.inbox_dir / f"{clip_id}.mp4"
            out_json = self.inbox_dir / f"{clip_id}.json"
            cut_dur = max(0.5, round(m_end - m_start, 3))

            eff_video_url = cached_video_url or getattr(self, "current_cached_video_url", None)
            has_local_cand_audio = bool(cand_audio_src and Path(cand_audio_src).is_file())

            if p_local.is_file():
                dl_cmd = self._build_ffmpeg_cut_cmd(str(p_local.resolve()), m_start, cut_dur, out_mp4)
                dl_res = self._run_cmd(dl_cmd, timeout=90)
            elif m3u8_url:
                dl_cmd = self._build_ffmpeg_cut_cmd(m3u8_url, m_start, cut_dur, out_mp4)
                dl_res = self._run_cmd(dl_cmd, timeout=90)
            elif eff_video_url and has_local_cand_audio:
                fast_cmd = [
                    get_ffmpeg_cmd(), "-y", "-hide_banner", "-loglevel", "warning",
                    "-accurate_seek", "-ss", str(m_start), "-i", str(eff_video_url),
                    "-accurate_seek", "-ss", str(m_start), "-i", str(Path(cand_audio_src).resolve()),
                    "-t", str(cut_dur),
                    "-map", "0:v:0", "-map", "1:a:0",
                    "-c:v", "libx264", "-preset", "ultrafast", "-crf", "22", "-pix_fmt", "yuv420p",
                    "-c:a", "aac", "-b:a", "160k",
                    "-af", "aresample=async=1:first_pts=0",
                    "-fps_mode", "cfr",
                    "-shortest",
                    "-avoid_negative_ts", "make_zero",
                    "-movflags", "+faststart",
                    str(out_mp4)
                ]
                dl_res = self._run_cmd(fast_cmd, timeout=90)
                if dl_res.returncode != 0 or not out_mp4.exists() or out_mp4.stat().st_size <= 5000:
                    logger.warning(f"⚠️ [VOD] Corte directo con URL cacheada falló (RC={dl_res.returncode}). Reintentando fallback yt-dlp --download-sections...")
                    if out_mp4.exists():
                        try:
                            out_mp4.unlink()
                        except Exception:
                            pass
                    if "403" in str(getattr(dl_res, "stderr", "") or ""):
                        self.current_cached_video_url = None
                    ytdlp_fmt = stream_resolver.get_ytdlp_format_filter(vq)
                    fb_cmd = [
                        *get_ytdlp_cmd(), "--no-update",
                        "--ffmpeg-location", get_ffmpeg_cmd(),
                        *stream_resolver.build_ytdlp_js_runtime_args(url=url),
                        "--force-keyframes-at-cuts",
                        "--download-sections", f"*{int(m_start)}-{int(m_end)}",
                        "-f", ytdlp_fmt,
                        "--downloader-args", "ffmpeg_o:-preset ultrafast -crf 22",
                        "--merge-output-format", "mp4",
                        "-o", str(out_mp4),
                        url
                    ]
                    dl_res = self._run_cmd(fb_cmd, timeout=90)
            else:
                ytdlp_fmt = stream_resolver.get_ytdlp_format_filter(vq)
                dl_cmd = [
                    *get_ytdlp_cmd(), "--no-update",
                    "--ffmpeg-location", get_ffmpeg_cmd(),
                    *stream_resolver.build_ytdlp_js_runtime_args(url=url),
                    "--force-keyframes-at-cuts",
                    "--download-sections", f"*{int(m_start)}-{int(m_end)}",
                    "-f", ytdlp_fmt,
                    "--downloader-args", "ffmpeg_o:-preset ultrafast -crf 22",
                    "--merge-output-format", "mp4",
                    "-o", str(out_mp4),
                    url
                ]
                dl_res = self._run_cmd(dl_cmd, timeout=90)
            
            # Localizar el archivo real generado por yt-dlp (puede tener .webm o .mp4)
            real_out = out_mp4
            if not real_out.exists():
                for alt in self.inbox_dir.glob(f"{clip_id}*"):
                    if alt.is_file() and alt.stat().st_size > 5000 and alt.suffix in (".webm", ".mkv", ".mp4"):
                        real_out = alt
                        break

            if dl_res.returncode == 0 and real_out.exists() and real_out.stat().st_size > 5000:
                out_mp4 = real_out
                clip_dur = round(m_end - m_start, 2)
                file_mb = round(out_mp4.stat().st_size / (1024 * 1024), 2)
                clip_meta = {
                    "id": clip_id,
                    "clip_id": clip_id,
                    "file_name": out_mp4.name,
                    "video_file": out_mp4.name,
                    "video_quality": vq,
                    "youtube_url": url,
                    "video_title": video_title,
                    "titulo_gancho": titulo_gancho,
                    "score": score_final,
                    "duration": clip_dur,
                    "duracion_segundos": clip_dur,
                    "file_size_mb": file_mb,
                    "start_sec": m_start,
                    "end_sec": m_end,
                    "audio_peak": round(peak, 3),
                    "rms_energy": round(rms, 3),
                    "dynamic_variance": round(dyn_var, 6),
                    "transcription": asr_res,
                    "transcripcion_base": transcription_text,
                    "palabras": asr_res.get("words", 0),
                    "is_vod": True,
                    "created_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                    "etapa4_ready": {
                        "source_url": url,
                        "source_type": "vod",
                        "source_offset_start": m_start,
                        "source_offset_end": m_end,
                        "duration": clip_dur,
                        "timeline_tracks": {
                            "video": [{"src": out_mp4.name, "start": 0.0, "end": clip_dur}],
                            "subtitles": asr_res.get("segments", []),
                            "cuts": [],
                            "overlays": []
                        }
                    }
                }
                with open(out_json, "w", encoding="utf-8") as jf:
                    json.dump(clip_meta, jf, indent=2, ensure_ascii=False)

                self._notify_clip_created(clip_meta)
                logger.info(f"✨ [VOD] Clip {candidate_idx}/{total_candidates} guardado: '{titulo_gancho}' (Score: {score_final})")

                if self.auto_render_916:
                    logger.info(f"🚀 Auto-enviando {clip_id} a cola 9:16 (Score: {score_final:.1f}, Calidad: {vq}, Sesión #{self.session_id})...")
                    stage2_queue.enqueue(
                        clip_id,
                        framing_mode="AUTO",
                        video_quality=vq,
                        session_id=self.session_id,
                        is_manual=False,
                        burn_subtitles=getattr(self, "burn_subtitles", True),
                        auto_titles=getattr(self, "auto_titles", True)
                    )
                return clip_meta
            else:
                logger.error(f"Error descargando fragmento {m_start}-{m_end}: {dl_res.stderr[:200]}")
                return None
        finally:
            try:
                if temp_cand_wav.exists():
                    temp_cand_wav.unlink()
            except Exception:
                pass

    def _process_vod(
        self,
        url: str,
        max_clips: int = 5,
        clip_duration_sec: int = 60,
        progress_cb: Optional[Callable[[Dict[str, Any]], None]] = None,
        video_quality: Optional[str] = None
    ):
        from config_manager import load_config
        vq = video_quality or load_config().get("video_quality", "1080p")
        def update_status(text: str, percentage: float = 0.0, current_sec: float = 0.0, total_sec: float = 0.0, current_clip: int = 0, total_clips: int = 0):
            prog = {
                "text": text,
                "percentage": round(min(100.0, max(0.0, percentage)), 1),
                "current_sec": round(current_sec, 1),
                "total_sec": round(total_sec, 1),
                "current_clip": current_clip,
                "total_clips": total_clips
            }
            self.current_progress = prog
            logger.info(f"📹 [VOD Engine] {text} ({prog['percentage']}%)")
            if progress_cb:
                try:
                    progress_cb(prog)
                except Exception:
                    pass

        update_status("Inspeccionando metadatos del video...", percentage=2.0)
        meta = self.inspect_url(url)
        video_title = meta.get("title", "VOD")
        total_duration = meta.get("duration", 0.0)
        heatmap = meta.get("heatmap", [])

        if total_duration < clip_duration_sec:
            update_status(f"El video es demasiado corto para procesar ventanas de {clip_duration_sec}s.", percentage=0.0)
            return

        full_audio_path = get_shm_path(f"vod_audio_full_{self.session_id}.m4a")
        local_audio_source: Optional[Path] = None
        self.current_full_audio_path = None
        self.current_cached_video_url = None
        cached_video_url: Optional[str] = None
        p_local = Path(url)

        try:
            # PASO 1: Descarga única de audio para análisis y extracción de candidatos
            if p_local.is_file():
                local_audio_source = p_local.resolve()
                self.current_full_audio_path = local_audio_source
            elif meta.get("m3u8_url"):
                local_audio_source = None
            else:
                if stream_resolver.detect_platform(url) == "youtube" or meta.get("platform") == "youtube":
                    cached_video_url = self._resolve_cached_video_url(url, vq)
                    self.current_cached_video_url = cached_video_url

                update_status("Descargando pista de audio completa para análisis ultra-rápido...", percentage=3.0)
                timeout_audio = max(180, int(total_duration * 0.15))
                audio_dl_cmd = [
                    *get_ytdlp_cmd(), "--no-update",
                    "--ffmpeg-location", get_ffmpeg_cmd(),
                    *stream_resolver.build_ytdlp_js_runtime_args(url=url),
                    "-f", "bestaudio[ext=m4a]/bestaudio",
                    "-o", str(full_audio_path),
                    url
                ]
                logger.info(f"🎵 [VOD Engine] Descarga única de audio con yt-dlp (Timeout: {timeout_audio}s)... ")
                res_dl = self._run_cmd(audio_dl_cmd, timeout=timeout_audio)
                if res_dl.returncode == 0 and full_audio_path.exists() and full_audio_path.stat().st_size > 1000:
                    local_audio_source = full_audio_path
                    self.current_full_audio_path = local_audio_source
                    logger.info(f"✅ [VOD Engine] Audio completo descargado ({round(full_audio_path.stat().st_size / (1024*1024), 2)} MB). Iniciando troceado instantáneo.")
                else:
                    logger.warning(f"Aviso: Descarga directa de audio falló (RC={res_dl.returncode}), intentando con fallback...")

            # RUTA 1: Fast-Path por Heatmap de YouTube (Most Replayed)
            if heatmap and len(heatmap) > 0:
                logger.info(f"🔥 [VOD Fast-Path] Heatmap detectado con {len(heatmap)} marcas de retención. Generando primer clip de inmediato...")
                sorted_pts = sorted(heatmap, key=lambda x: x.get("value", 0.0), reverse=True)
                candidate_windows = []
                min_dist = max(15.0, clip_duration_sec * 0.75)
                
                for pt in sorted_pts:
                    t_mid = (pt.get("start_time", 0.0) + pt.get("end_time", 0.0)) / 2.0
                    cand_s = max(0.0, round(t_mid - (clip_duration_sec * 0.35), 1))
                    cand_e = min(total_duration, round(cand_s + clip_duration_sec, 1))
                    
                    if not any(abs(cand_s - prev_s) < min_dist for prev_s, _, _ in candidate_windows):
                        candidate_windows.append((cand_s, cand_e, pt.get("value", 0.5)))
                    if len(candidate_windows) >= max_clips:
                        break

                ready_clips = 0
                for i, (cs, ce, hval) in enumerate(candidate_windows, start=1):
                    if not self.is_running or self.stop_event.is_set():
                        update_status("Proceso cancelado por el usuario.", percentage=0.0)
                        return
                    pct = 5.0 + ((i / len(candidate_windows)) * 90.0)
                    update_status(
                        f"Fast-Path Heatmap: Extrayendo clip {i}/{len(candidate_windows)} ({format_time_hms(cs)})...",
                        percentage=pct,
                        current_sec=cs,
                        total_sec=total_duration,
                        current_clip=i,
                        total_clips=len(candidate_windows)
                    )
                    meta_clip = self._extract_and_package_candidate(
                        m_start=cs,
                        m_end=ce,
                        candidate_idx=i,
                        total_candidates=len(candidate_windows),
                        url=url,
                        video_title=video_title,
                        total_duration=total_duration,
                        vq=vq,
                        heatmap_val=hval,
                        m3u8_url=meta.get("m3u8_url"),
                        local_audio_path=local_audio_source,
                        cached_video_url=cached_video_url
                    )
                    if meta_clip:
                        ready_clips += 1

                update_status(f"✅ Fast-Path Heatmap completado ({ready_clips}/{len(candidate_windows)} clips generados)", percentage=100.0, current_clip=ready_clips, total_clips=len(candidate_windows))
                return
            # RUTA 2: Análisis Incremental y Multi-Clip Ultra-Rápido por Bloques Locales de 300s (5 min)
            if total_duration > 90.0:
                block_sec = 300.0  # Bloques de 5 minutos (300s)
                overlap_sec = 10.0
                step_sec = block_sec - overlap_sec  # 290.0s
                n_blocks = max(1, int(math.ceil(max(0.0, total_duration - overlap_sec) / step_sec)))
            else:
                block_sec = total_duration
                overlap_sec = 0.0
                step_sec = block_sec
                n_blocks = 1

            logger.info(f"🧱 [VOD Incremental] Procesando en {n_blocks} bloques de {int(block_sec)}s (Solape: {int(overlap_sec)}s, Coarse 8 kHz)...")
            ready_clips = 0
            accepted_intervals: List[tuple] = []

            for b_idx in range(n_blocks):
                if not self.is_running or self.stop_event.is_set():
                    update_status("Proceso cancelado por el usuario.", percentage=0.0)
                    return
                if ready_clips >= max_clips:
                    break

                b_start = round(b_idx * step_sec, 2)
                b_end = min(total_duration, round(b_start + block_sec, 2))
                dur_block = round(b_end - b_start, 2)
                if dur_block < min(clip_duration_sec, 15.0) and b_idx > 0:
                    break

                pct_block = 5.0 + ((b_idx / n_blocks) * 90.0)
                update_status(
                    f"Analizando bloque {b_idx + 1}/{n_blocks}... {ready_clips} clips generados ({format_time_hms(b_start)} - {format_time_hms(b_end)})",
                    percentage=pct_block,
                    current_sec=b_start,
                    total_sec=total_duration,
                    current_clip=ready_clips,
                    total_clips=max_clips
                )

                temp_block_wav = get_shm_path(f"temp_block_{self.session_id}_{b_idx}.wav")
                try:
                    # Troceado ultra-rápido en milisegundos con FFmpeg a 8 kHz mono desde archivo local
                    if local_audio_source and local_audio_source.is_file():
                        b_audio_cmd = [
                            get_ffmpeg_cmd(), "-y", "-hide_banner", "-loglevel", "warning",
                            "-ss", str(b_start), "-t", str(dur_block),
                            "-i", str(local_audio_source.resolve()),
                            "-vn", "-acodec", "pcm_s16le", "-ar", "8000", "-ac", "1",
                            str(temp_block_wav)
                        ]
                    elif meta.get("m3u8_url"):
                        b_audio_cmd = [
                            get_ffmpeg_cmd(), "-y", "-hide_banner", "-loglevel", "warning",
                            "-headers", f"User-Agent: {stream_resolver.DESKTOP_UA}\r\n",
                            "-ss", str(b_start), "-t", str(dur_block),
                            "-i", meta.get("m3u8_url"),
                            "-vn", "-acodec", "pcm_s16le", "-ar", "8000", "-ac", "1",
                            str(temp_block_wav)
                        ]
                    else:
                        b_audio_cmd = [
                            get_ffmpeg_cmd(), "-y", "-hide_banner", "-loglevel", "warning",
                            "-ss", str(b_start), "-t", str(dur_block),
                            "-i", url,
                            "-vn", "-acodec", "pcm_s16le", "-ar", "8000", "-ac", "1",
                            str(temp_block_wav)
                        ]

                    res_b = self._run_cmd(b_audio_cmd, timeout=40)
                    if res_b.returncode != 0 or not temp_block_wav.exists() or temp_block_wav.stat().st_size < 1000:
                        logger.warning(f"Aviso: Bloque {b_idx + 1}/{n_blocks} no produjo audio utilizable, continuando al siguiente bloque...")
                        continue

                    sr = 8000
                    w_samples = int(clip_duration_sec * sr)
                    s_samples = int(5 * sr)  # Resolución fina de 5 segundos

                    try:
                        with wave.open(str(temp_block_wav), "rb") as wf:
                            n_fr = wf.getnframes()
                            if n_fr == 0:
                                continue
                            raw_b = wf.readframes(n_fr)
                            samples = np.frombuffer(raw_b, dtype=np.int16).astype(np.float32) / 32768.0
                    except Exception as w_err:
                        logger.warning(f"Error abriendo audio WAV de bloque {b_idx + 1}: {w_err}")
                        continue

                    if len(samples) < sr * 3:
                        logger.debug(f"Bloque {b_idx + 1} tiene audio insuficiente ({len(samples)} samples), omitiendo...")
                        continue

                    block_candidates = []
                    total_steps = max(0, len(samples) - w_samples + 1)
                    if total_steps <= 0:
                        ac_feat = self._compute_block_window_acoustics(samples, sr=sr)
                        vocal_bonus = (ac_feat["vocal_ratio"] * 1.6) - (0.6 if ac_feat["flatness"] > 0.55 else 0.0)
                        flux_bonus = min(ac_feat["spectral_flux"] * 3.0, 0.8) + min(ac_feat["burst_contrast"] * 0.6, 0.9)
                        score = 4.8 + (ac_feat["peak"] * 2.4) + min(ac_feat["rms"] * 14.0, 1.4) + vocal_bonus + flux_bonus
                        block_candidates.append({
                            "start": round(b_start, 2),
                            "end": min(total_duration, round(b_start + (len(samples) / sr), 2)),
                            "score": score,
                            "peak": ac_feat["peak"],
                            "rms": ac_feat["rms"],
                            "dyn_var": ac_feat["dyn_var"],
                            "spectral_flux": ac_feat["spectral_flux"],
                            "vocal_ratio": ac_feat["vocal_ratio"],
                            "flatness": ac_feat["flatness"]
                        })
                    else:
                        for start_s in range(0, total_steps, s_samples):
                            chunk = samples[start_s : start_s + w_samples]
                            if len(chunk) == 0:
                                continue
                            ac_feat = self._compute_block_window_acoustics(chunk, sr=sr)
                            vocal_bonus = (ac_feat["vocal_ratio"] * 1.6) - (0.6 if ac_feat["flatness"] > 0.55 else 0.0)
                            flux_bonus = min(ac_feat["spectral_flux"] * 3.0, 0.8) + min(ac_feat["burst_contrast"] * 0.6, 0.9)
                            score = 4.8 + (ac_feat["peak"] * 2.4) + min(ac_feat["rms"] * 14.0, 1.4) + vocal_bonus + flux_bonus
                            rel_time = start_s / sr
                            block_candidates.append({
                                "start": round(b_start + rel_time, 2),
                                "end": min(total_duration, round(b_start + rel_time + clip_duration_sec, 2)),
                                "score": score,
                                "peak": ac_feat["peak"],
                                "rms": ac_feat["rms"],
                                "dyn_var": ac_feat["dyn_var"],
                                "spectral_flux": ac_feat["spectral_flux"],
                                "vocal_ratio": ac_feat["vocal_ratio"],
                                "flatness": ac_feat["flatness"]
                            })

                    # Deduplicar ventanas dentro del bloque con NMS (mínimo 15s de separación)
                    deduped_candidates = deduplicate_windows(block_candidates, iou_thresh=0.25, min_gap_sec=15.0)

                    # Multi-clip real: emitir los momentos cumbre del bloque sin colisionar con clips previos
                    max_from_this_block = max(1, min(3, max_clips - ready_clips))
                    emitted_in_block = 0

                    for cand in deduped_candidates:
                        if ready_clips >= max_clips or emitted_in_block >= max_from_this_block:
                            break
                        if not self.is_running or self.stop_event.is_set():
                            update_status("Proceso cancelado por el usuario.", percentage=0.0)
                            return

                        c_s, c_e = cand["start"], cand["end"]
                        
                        # Comprobar distancia mínima con clips ya aceptados a lo largo de todo el video
                        collides = False
                        for acc_s, acc_e in accepted_intervals:
                            overlap = max(0.0, min(c_e, acc_e) - max(c_s, acc_s))
                            gap = max(0.0, max(c_s, acc_s) - min(c_e, acc_e))
                            if overlap > 5.0 or gap < 15.0:
                                collides = True
                                break
                        if collides:
                            continue

                        # Emisión inmediata: corta y publica en inbox_brutos y notifica a la UI de inmediato
                        logger.info(f"✂️ [VOD Incremental] Extrayendo momento cumbre {c_s}s-{c_e}s (Bloque {b_idx + 1}/{n_blocks}, Score preliminar: {cand['score']:.1f})...")
                        meta_clip = self._extract_and_package_candidate(
                            m_start=c_s,
                            m_end=c_e,
                            candidate_idx=ready_clips + 1,
                            total_candidates=max_clips,
                            url=url,
                            video_title=video_title,
                            total_duration=total_duration,
                            vq=vq,
                            peak=cand["peak"],
                            rms=cand["rms"],
                            dyn_var=cand["dyn_var"],
                            m3u8_url=meta.get("m3u8_url"),
                            local_audio_path=local_audio_source,
                            spectral_flux=cand.get("spectral_flux", 0.0),
                            vocal_ratio=cand.get("vocal_ratio", 0.0),
                            flatness=cand.get("flatness", 0.0),
                            cached_video_url=cached_video_url
                        )
                        if meta_clip:
                            accepted_intervals.append((c_s, c_e))
                            ready_clips += 1
                            emitted_in_block += 1
                            logger.info(f"✨ [VOD Incremental] Clip #{ready_clips}/{max_clips} emitido y publicado de inmediato: '{meta_clip['file_name']}'")
                            update_status(
                                f"Analizando bloque {b_idx + 1}/{n_blocks}... {ready_clips} clips generados",
                                percentage=pct_block,
                                current_sec=c_s,
                                total_sec=total_duration,
                                current_clip=ready_clips,
                                total_clips=max_clips
                            )
                finally:
                    if temp_block_wav.exists():
                        try:
                            temp_block_wav.unlink(missing_ok=True)
                        except Exception:
                            pass

            update_status(f"✅ VOD por Bloques completado ({ready_clips}/{max_clips} clips generados)", percentage=100.0, current_clip=ready_clips, total_clips=max_clips)
        finally:
            self.is_running = False
            self.current_full_audio_path = None
            self.current_cached_video_url = None
            try:
                if full_audio_path and full_audio_path.exists():
                    full_audio_path.unlink()
            except Exception:
                pass
            try:
                if VOD_AUDIO_PATH.exists():
                    VOD_AUDIO_PATH.unlink()
            except Exception:
                pass
            try:
                clean_dir_patterns(get_shm_dir(), ["vod_audio.*", "temp_cand*.wav", "temp_block*.wav"])
            except Exception:
                pass


# Instancia singleton para uso en el servidor
vod_engine = VODEngine()
