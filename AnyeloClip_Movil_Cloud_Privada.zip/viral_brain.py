"""
viral_brain.py - Motor de Selección Viral Híbrido, Local y Auto-Aprendible.
Diseñado para acierto inmediato (Día 1) mediante Cerebro Universal y calibración
continua al estilo del usuario/canal sin etiquetado manual (Feedback Silencioso).

Características:
- Acústica: RMS Z-score (ventana móvil 3 min), contraste silencio-pico, flujo espectral (FFT).
- Lingüística: Aceleración de habla (WPM), densidad de exclamaciones/preguntas, jerga regional.
- Diccionarios regionales: España, México, RD/Caribe, Latam, Gaming/Streamers.
- Feature Hashing (Hashing Trick) en NumPy para aprendizaje léxico abierto sin vocabulario estático.
- Embeddings locales opcionales (model2vec o sentence-transformers con fallback transparente).
- Aprendizaje online (SGD regularizado a L2 hacia modelo universal).
- Blend progresivo: alpha = min(0.65, n_muestras / 30).
- Persistencia en user_viral_brain.json con reseteo a 1 clic.
"""

import os
import re
import json
import math
import time
import logging
import unicodedata
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
import numpy as np

from native_audio import RingEnergyBuffer, calculate_modified_zscore

logger = logging.getLogger("viral_brain")

BASE_DIR = Path(__file__).resolve().parent
BRAIN_STORAGE_PATH = BASE_DIR / "user_viral_brain.json"

# Diccionarios de jerga y expresiones virales de alta retención
UNIVERSAL_VIRAL_LEXICON = {
    # Exclamaciones y asombro universal + podcasts/debates
    "increible", "no puede ser", "dios mio", "locura", "brutal", "alerta", "urgente",
    "confieso", "mentira", "secreto", "epico", "wtf", "no te creo", "que locura",
    "lo sabia", "tengo miedo", "cuidado", "peligro", "historico", "inaudito", "impactante",
    "atencion", "miren esto", "escuchen", "por fin", "admito", "exclusiva", "descubierto",
    "ojo con esto", "grave", "fuerte", "polemica", "terrible", "demasiado", "par favar",
    "chisme", "tiradera", "escandalo", "rompio", "viral", "pelea", "factos", "basado",
    "humillo", "la rompi", "cancelado"
}

REGIONAL_LEXICON = {
    "es": {  # España
        "flipando", "que flipas", "madre mia", "en plan", "chaval", "ostia", "hostia",
        "barbaridad", "vaya tela", "brutal", "flipas", "rayada", "me renta", "tocho",
        "locurote", "vaya locura", "guapo", "chulada"
    },
    "mx": {  # México
        "no manches", "no mames", "que pedo", "neta", "al chile", "carnal", "wey",
        "guey", "chingon", "orale", "aguanta", "no mms", "que onda", "a la madre",
        "alv", "te pasas de lanza", "chale", "simon", "camara"
    },
    "rd": {  # República Dominicana & Caribe
        "que baina", "que vaina", "dime a ve", "klk", "de locos", "ta to", "dique",
        "heavy", "manin", "barbaro", "montro", "de pinga", "que lo que", "fuego",
        "loquera", "mira ve", "pana mio", "bobo", "coro", "se prendio"
    },
    "gaming": {  # Gaming, Esports & Twitch/Kick Culture
        "clutch", "mvp", "headshot", "pentakill", "f en el chat", "clip it", "clipea",
        "baneado", "nerfeado", "rushear", "troleo", "god", "carry", "humillacion",
        "remontada", "ragequit", "tilt", "hitkill", "gg", "ez", "smurf", "banger"
    }
}

ALL_REGIONAL_KEYWORDS = set().union(*REGIONAL_LEXICON.values())


def strip_accents_ascii(text: str) -> str:
    """Normaliza texto eliminando tildes y pasando a ASCII minúsculas."""
    if not text:
        return ""
    return unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii").lower()


def normalize_text_tokens(text: str) -> List[str]:
    """Limpia tildes, signos de puntuación y extrae tokens normalizados."""
    clean = strip_accents_ascii(text)
    if not clean:
        return []
    return re.findall(r"\b[a-z0-9_]{2,20}\b", clean)


def feature_hash(token: str, n_buckets: int = 512) -> int:
    """Función de hashing determinista para el truco de feature hashing."""
    h = 0
    for char in token:
        h = (h * 31 + ord(char)) & 0xFFFFFFFF
    return h % n_buckets


class ViralBrain:
    def __init__(self, storage_path: Path = BRAIN_STORAGE_PATH):
        self.storage_path = storage_path
        self.n_buckets = 256  # Buckets de feature hashing para vocabulario abierto
        
        # Pesos base universales (Día 1 calibrado)
        self.w0_dense = {
            "peak_level": 0.25,
            "rms_zscore": 0.20,
            "silence_contrast": 0.12,
            "spectral_flux": 0.15,
            "speech_acceleration": 0.10,
            "lexical_score": 0.20,
            "punctuation_density": 0.08,
            "delta_energy": 0.10,
            "delta_wpm": 0.08,
            "vocal_ratio": 0.12,
            "vocal_clarity": 0.10
        }
        
        # Pesos aprendidos del usuario
        self.user_dense_weights = dict(self.w0_dense)
        self.user_hash_weights = np.zeros(self.n_buckets, dtype=np.float32)
        self._last_rms = None
        self._last_wpm = None
        self.user_bias = 0.0
        self.n_samples = 0
        self.n_pos = 0
        self.n_neg = 0
        
        # Historial móvil de RMS en memoria plana (últimos 3 minutos = 180s de muestras)
        self.rms_buffer = RingEnergyBuffer(max_len=180)

        # Intentar cargar embeddings ligeros opcionales (model2vec o sentence-transformers)
        self.embed_model = None
        self._init_optional_embedder()

        # Cargar estado guardado si existe
        self.load()

    def _init_optional_embedder(self):
        """Carga modelo de embeddings local si está disponible; no crashea si falta."""
        try:
            from model2vec import StaticModel
            # Si el usuario tiene un modelo local en models/model2vec
            m_path = BASE_DIR / "models" / "model2vec"
            if m_path.exists():
                self.embed_model = StaticModel.from_pretrained(str(m_path))
                logger.info("✓ Model2Vec local cargado para similitud semántica viral.")
        except Exception:
            self.embed_model = None

    def update_rms_history(self, rms_val: float):
        """Actualiza el buffer circular de RMS con el último fragmento analizado."""
        if rms_val > 0.0001:
            self.rms_buffer.append(float(rms_val))

    def calculate_rms_zscore(self, current_rms: float) -> float:
        """
        Calcula Modified Z-Score de RMS sobre la mediana y MAD de los últimos 3 minutos (180s).
        Inmune a outliers de gritos aislados o picos masivos.
        """
        hist = self.rms_buffer.get_history()
        return calculate_modified_zscore(hist, current_rms)

    def extract_features(
        self,
        acoustic_metrics: Dict[str, Any],
        transcript_text: str = "",
        duration_sec: float = 60.0,
        no_speech_prob: float = 0.0,
        energy_prev: float = 0.0,
        wpm_prev: float = 0.0
    ) -> Tuple[Dict[str, float], List[int]]:
        """
        Extrae el vector denso de características y los índices hash de vocabulario,
        incorporando contexto temporal (t-1 vs t), métricas vocales y Wiener Flatness.
        """
        current_rms = float(acoustic_metrics.get("rms_energy", 0.0))
        peak_level = float(acoustic_metrics.get("peak_level", 0.0))
        spectral_flux = float(acoustic_metrics.get("spectral_flux", 0.0))
        
        # 1. Z-Score relativo de RMS (Modified Z-Score con MAD)
        rms_zscore = self.calculate_rms_zscore(current_rms)

        # 2. Contraste silencio -> pico
        silence_contrast = float(peak_level / (current_rms + 0.01))
        silence_contrast = float(np.clip(silence_contrast / 10.0, 0.0, 1.0))

        # 3. Flujo espectral normalizado [0.0 a 1.0]
        norm_flux = float(np.clip(spectral_flux * 5.0, 0.0, 1.0))

        # 4. Aceleración de habla (Palabras por minuto respecto al promedio 130 WPM)
        tokens = normalize_text_tokens(transcript_text)
        word_count = len(tokens)
        effective_dur = max(duration_sec, 5.0)
        wpm = (word_count / effective_dur) * 60.0
        speech_acc = float(np.clip((wpm - 100.0) / 100.0, -1.0, 2.0))

        # 5. Detección léxica de impacto (Universal + Regional, normalizada sin tildes)
        lexical_hits = 0
        clean_text_lower = strip_accents_ascii(transcript_text)
        for kw in UNIVERSAL_VIRAL_LEXICON:
            kw_norm = strip_accents_ascii(kw)
            if len(kw_norm) <= 3 and " " not in kw_norm:
                if re.search(rf"\b{re.escape(kw_norm)}\b", clean_text_lower):
                    lexical_hits += 2
            elif kw_norm in clean_text_lower:
                lexical_hits += 2
        for kw in ALL_REGIONAL_KEYWORDS:
            kw_norm = strip_accents_ascii(kw)
            if len(kw_norm) <= 3 and " " not in kw_norm:
                if re.search(rf"\b{re.escape(kw_norm)}\b", clean_text_lower):
                    lexical_hits += 2
            elif kw_norm in clean_text_lower:
                lexical_hits += 2

        lexical_score = float(np.clip(lexical_hits / 4.0, 0.0, 1.5))

        # 6. Densidad de signos exclamativos/interrogativos
        excl_count = transcript_text.count("!") + transcript_text.count("¡")
        quest_count = transcript_text.count("?") + transcript_text.count("¿")
        punctuation_density = float(np.clip((excl_count + quest_count) / max(1, (word_count / 10)), 0.0, 1.5))

        # 7. Contexto Temporal (Contraste t-1 vs t) y Métricas Vocales
        delta_energy = float(np.clip(current_rms - energy_prev, -5.0, 5.0))
        delta_wpm = float(np.clip((wpm - wpm_prev) / 50.0, -2.0, 2.0))
        vocal_ratio = float(np.clip(acoustic_metrics.get("vocal_ratio", 0.0), 0.0, 1.0))
        flatness = float(np.clip(acoustic_metrics.get("flatness", 0.0), 0.0, 1.0))
        vocal_clarity = float(np.clip(1.0 - flatness, 0.0, 1.0))

        # Penalización por ausencia de voz
        if no_speech_prob > 0.65:
            speech_acc = -1.0
            lexical_score *= 0.2
            vocal_clarity *= 0.2

        dense = {
            "peak_level": float(np.clip(peak_level, 0.0, 1.0)),
            "rms_zscore": float(np.clip(rms_zscore / 3.0, -1.0, 1.5)),
            "silence_contrast": silence_contrast,
            "spectral_flux": norm_flux,
            "speech_acceleration": speech_acc,
            "lexical_score": lexical_score,
            "punctuation_density": punctuation_density,
            "delta_energy": delta_energy,
            "delta_wpm": delta_wpm,
            "vocal_ratio": vocal_ratio,
            "vocal_clarity": vocal_clarity
        }

        # Índices hash para unigramas y bigramas
        hash_indices: List[int] = []
        for tok in tokens:
            hash_indices.append(feature_hash(tok, self.n_buckets))
        for i in range(len(tokens) - 1):
            bigram = f"{tokens[i]}_{tokens[i+1]}"
            hash_indices.append(feature_hash(bigram, self.n_buckets))

        return dense, hash_indices

    def predict(
        self,
        acoustic_metrics: Dict[str, Any],
        transcript_text: str = "",
        duration_sec: float = 60.0,
        no_speech_prob: float = 0.0
    ) -> Dict[str, Any]:
        """
        Calcula la puntuación viral híbrida (Universal + Usuario) en escala 1.0 - 10.0.
        """
        current_rms = float(acoustic_metrics.get("rms_energy", 0.0))
        tokens_now = normalize_text_tokens(transcript_text)
        current_wpm = (len(tokens_now) / max(duration_sec, 5.0)) * 60.0
        energy_prev = current_rms if self._last_rms is None else self._last_rms
        wpm_prev = current_wpm if self._last_wpm is None else self._last_wpm

        dense, hash_indices = self.extract_features(
            acoustic_metrics,
            transcript_text,
            duration_sec,
            no_speech_prob,
            energy_prev=energy_prev,
            wpm_prev=wpm_prev
        )
        self._last_rms = current_rms
        self._last_wpm = current_wpm

        # 1. Puntuación Universal (Día 1 garantizado)
        univ_raw = sum(dense[k] * self.w0_dense.get(k, 0.1) for k in dense)
        # Escalar raw a rango [5.0, 9.8]
        score_univ = 5.2 + (univ_raw * 4.6)
        score_univ = float(np.clip(score_univ, 5.0, 9.8))

        # 2. Puntuación del Modelo de Usuario
        user_raw = sum(dense[k] * self.user_dense_weights.get(k, 0.1) for k in dense) + self.user_bias
        if hash_indices:
            user_raw += float(np.mean([self.user_hash_weights[idx] for idx in hash_indices]))
        score_user = 5.2 + (user_raw * 4.6)
        score_user = float(np.clip(score_user, 5.0, 9.8))

        # 3. Blend progresivo: alpha = min(0.65, n_samples / 30)
        alpha = min(0.65, self.n_samples / 30.0)
        final_score = round(((1.0 - alpha) * score_univ) + (alpha * score_user), 1)

        is_calibrated = self.n_samples >= 30

        return {
            "score": final_score,
            "score_univ": round(score_univ, 1),
            "score_user": round(score_user, 1),
            "alpha": round(alpha, 2),
            "n_samples": self.n_samples,
            "is_calibrated": is_calibrated,
            "dense_features": dense,
            "vocab_tokens": len(hash_indices)
        }

    def learn(
        self,
        acoustic_metrics: Dict[str, Any],
        transcript_text: str = "",
        label: float = 1.0,  # 1.0 = aceptado / renderizado 9:16, 0.0 = borrado / descartado
        duration_sec: float = 60.0,
        energy_prev: float = 0.0,
        wpm_prev: float = 0.0
    ):
        """
        Entrenamiento online con SGD balanceado y decaimiento elástico hacia el modelo universal
        para prevenir sobreajuste y muerte cerebral ante desbalance de likes/dislikes.
        """
        try:
            # Compatibilidad: si acoustic_metrics ya contiene el vector denso de features
            if "peak_level" in acoustic_metrics and "lexical_score" in acoustic_metrics:
                dense = {k: float(acoustic_metrics.get(k, 0.0)) for k in self.w0_dense}
                tokens = normalize_text_tokens(transcript_text) if transcript_text else []
                hash_indices = [feature_hash(tok, self.n_buckets) for tok in tokens]
            else:
                dense, hash_indices = self.extract_features(
                    acoustic_metrics, transcript_text, duration_sec,
                    energy_prev=energy_prev, wpm_prev=wpm_prev
                )
            
            y = 1.0 if label >= 0.5 else 0.0
            if y >= 0.5:
                self.n_pos += 1
                sample_weight = float(np.clip((self.n_neg + 1.0) / (self.n_pos + 1.0), 1.0, 3.0))
            else:
                self.n_neg += 1
                sample_weight = 1.0

            # Predicción actual del usuario (sigmoide sobre user_raw)
            raw = sum(dense[k] * self.user_dense_weights.get(k, 0.1) for k in dense) + self.user_bias
            if hash_indices:
                raw += float(np.mean([self.user_hash_weights[idx] for idx in hash_indices]))
            
            pred = 1.0 / (1.0 + math.exp(-max(min(raw, 10.0), -10.0)))
            diff = pred - y  # Error de gradiente

            # Decaimiento elástico hacia pesos base antes de aplicar gradiente (Anti-Muerte Cerebral)
            for k in self.user_dense_weights:
                w_curr = self.user_dense_weights[k]
                w0 = self.w0_dense.get(k, 0.1)
                self.user_dense_weights[k] = 0.985 * w_curr + 0.015 * w0
            self.user_hash_weights *= 0.992
            self.user_bias *= 0.985

            # Actualización con grad = sample_weight * (pred - y) * x y lr = 0.08
            lr = 0.08
            for k in self.user_dense_weights:
                val = dense.get(k, 0.0)
                grad = sample_weight * diff * val
                self.user_dense_weights[k] = float(np.clip(self.user_dense_weights[k] - (lr * grad), 0.0, 1.0))

            if hash_indices:
                grad_h = sample_weight * diff * (1.0 / max(1, len(hash_indices)))
                for idx in hash_indices:
                    self.user_hash_weights[idx] = float(np.clip(self.user_hash_weights[idx] - (lr * grad_h), -1.0, 1.0))

            grad_b = sample_weight * diff
            self.user_bias = float(np.clip(self.user_bias - (lr * grad_b * 0.2), -1.0, 1.0))
            self.n_samples += 1

            self.save()
            logger.info(f"🧠 ViralBrain entrenó muestra #{self.n_samples} (label={label}, w={sample_weight:.2f}, pos={self.n_pos}, neg={self.n_neg}). Alpha={min(0.65, self.n_samples/30.0):.2f}")
        except Exception as e:
            logger.error(f"Error entrenando ViralBrain: {e}")

    def save(self):
        """Persiste los pesos aprendidos del usuario y contadores balanceados en JSON."""
        try:
            data = {
                "n_samples": self.n_samples,
                "n_pos": self.n_pos,
                "n_neg": self.n_neg,
                "user_bias": round(float(self.user_bias), 4),
                "user_dense_weights": {k: round(float(v), 4) for k, v in self.user_dense_weights.items()},
                "user_hash_weights": [round(float(v), 4) for v in self.user_hash_weights.tolist()],
                "saved_at": time.strftime("%Y-%m-%dT%H:%M:%S")
            }
            with open(self.storage_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Error guardando ViralBrain: {e}")

    def load(self):
        """Carga los pesos de usuario previamente persistidos."""
        if not self.storage_path.exists():
            return
        try:
            with open(self.storage_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.n_samples = int(data.get("n_samples", 0))
            self.n_pos = int(data.get("n_pos", 0))
            self.n_neg = int(data.get("n_neg", 0))
            self.user_bias = float(data.get("user_bias", 0.0))
            if "user_dense_weights" in data:
                self.user_dense_weights.update(data["user_dense_weights"])
            if "user_hash_weights" in data:
                hw = np.array(data["user_hash_weights"], dtype=np.float32)
                if len(hw) == self.n_buckets:
                    self.user_hash_weights = hw
            logger.info(f"🧠 ViralBrain cargó perfil de usuario ({self.n_samples} muestras, pos={self.n_pos}, neg={self.n_neg}).")
        except Exception as e:
            logger.warning(f"No se pudo cargar {self.storage_path}, iniciando fresco: {e}")

    def reset(self):
        """Restaura el cerebro al estado de fábrica (Día 1 puro)."""
        self.n_samples = 0
        self.n_pos = 0
        self.n_neg = 0
        self.user_bias = 0.0
        self.user_dense_weights = dict(self.w0_dense)
        self.user_hash_weights = np.zeros(self.n_buckets, dtype=np.float32)
        self._last_rms = None
        self._last_wpm = None
        if self.storage_path.exists():
            try:
                self.storage_path.unlink()
            except Exception:
                pass
        logger.info("🧠 ViralBrain ha sido reseteado al estado de fábrica.")

    def get_status(self) -> Dict[str, Any]:
        """Retorna el estado de calibración para el dashboard."""
        alpha = min(0.65, self.n_samples / 30.0)
        return {
            "n_samples": self.n_samples,
            "target_samples": 30,
            "alpha": round(alpha, 2),
            "is_calibrated": self.n_samples >= 30,
            "status_label": f"IA Calibrada a tu canal ({self.n_samples} clips)" if self.n_samples >= 30 else f"Aprendiendo ({self.n_samples}/30 clips)"
        }


# Singleton global de ViralBrain
_GLOBAL_VIRAL_BRAIN: Optional[ViralBrain] = None

def get_viral_brain() -> ViralBrain:
    global _GLOBAL_VIRAL_BRAIN
    if _GLOBAL_VIRAL_BRAIN is None:
        _GLOBAL_VIRAL_BRAIN = ViralBrain()
    return _GLOBAL_VIRAL_BRAIN
