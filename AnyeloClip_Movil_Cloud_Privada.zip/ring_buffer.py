"""
ring_buffer.py - Anillo de retención en RAM (/dev/shm/live_ring_buffer).
Mantiene en memoria volátil los últimos 4 minutos (48 fragmentos .ts de 5s en 1080p, ~110MB).
Copia directa sin recodificar (-c copy), cero desgaste de SSD, con reconexión automática.
"""

import os
import time
import signal
import shutil
import logging
import threading
import subprocess
import psutil
from pathlib import Path
from typing import List, Dict, Any, Optional

from os_compat import (
    get_ring_buffer_dir, get_shm_dir, get_shm_path,
    get_ffmpeg_cmd, get_ytdlp_cmd, build_ytdlp_js_runtime_args,
    kill_process_tree, kill_orphans_safety, get_subprocess_flags,
    clean_dir_patterns, IS_WIN
)
import stream_resolver

logger = logging.getLogger("ring_buffer")
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

BUFFER_DIR = get_ring_buffer_dir()
MAX_SEGMENTS = 48
SEGMENT_DURATION_SEC = 5


class RingBufferManager:
    def __init__(self, buffer_dir: Path = BUFFER_DIR):
        self.buffer_dir = buffer_dir
        self.current_url: Optional[str] = None
        self.clip_duration_sec: int = 60
        self.video_quality: str = "1080p"
        self.max_segments: int = MAX_SEGMENTS
        self.process: Optional[subprocess.Popen] = None
        self.producer_process: Optional[subprocess.Popen] = None
        self.supervisor_thread: Optional[threading.Thread] = None
        self.watchdog_thread: Optional[threading.Thread] = None
        self.is_running = False
        self.watchdog_enabled = False
        self.start_time: float = 0.0
        self.last_log_truncate: float = time.time()
        self.fatal_error_message: Optional[str] = None
        self.on_fatal_error: Optional[Any] = None
        self.on_stream_ended: Optional[Any] = None
        self.lock = threading.RLock()
        
    def _clean_buffer_dir(self):
        """Prepara el directorio en RAM borrando residuos viejos."""
        try:
            clean_dir_patterns(self.buffer_dir, ["seg_*.ts", "*.wav"])
            clean_dir_patterns(get_shm_dir(), ["temp_*.wav", "vod_*.wav", "seg_*.ts", "temp_*.ts", "temp_*.ass"])
        except Exception as e:
            logger.error(f"Error limpiando {self.buffer_dir}: {e}")

    def stop_and_reset_pipeline(self):
        """
        FIX CRÍTICO: Cambio limpio de enlace.
        1. Desactiva temporalmente el Watchdog para evitar resurrección de URL vieja.
        2. Mata todo el grupo de procesos con SIGKILL/taskkill y ejecuta barrido de seguridad.
        3. Borra todos los .ts y .wav en el buffer para no mezclar fragmentos.
        4. Resetea variables internas.
        """
        logger.info("🧹 Ejecutando stop_and_reset_pipeline(): Limpieza total de procesos y RAM...")
        self.watchdog_enabled = False
        self.is_running = False
        self.current_url = None

        # 1. Matar grupo de procesos del Popen activo y productor
        with self.lock:
            for proc in [self.producer_process, self.process]:
                if proc:
                    try:
                        kill_process_tree(proc.pid)
                    except Exception:
                        pass
                    try:
                        proc.kill()
                    except Exception:
                        pass
                    try:
                        proc.wait(timeout=1.0)
                    except Exception:
                        pass
            self.producer_process = None
            self.process = None

        # 2. Barrido de seguridad exhaustivo contra huérfanos de ffmpeg y yt-dlp
        kill_orphans_safety()

        # 3. Borrar todos los archivos de video/audio viejos en el buffer
        self._clean_buffer_dir()
        time.sleep(0.3)
        logger.info("✅ Pipeline reseteado limpiamente. Buffer despejado y libre de huérfanos.")

    def start(self, youtube_url: str, clip_duration_sec: int = 60, video_quality: Optional[str] = None):
        """Inicia el anillo de retención para la nueva URL con tamaño dinámico según duración y calidad."""
        with self.lock:
            # Forzar reseteo limpio si ya estaba corriendo
            self.stop_and_reset_pipeline()

            self.current_url = youtube_url.strip()
            self.clip_duration_sec = max(15, min(600, int(clip_duration_sec or 60)))
            self.video_quality = video_quality or "1080p"

            # Buffer dinámico: retén al menos max(120, clip_duration_sec + 60) segundos en disco
            needed_sec = max(120, self.clip_duration_sec + 60)
            self.max_segments = max(48, int(round(needed_sec / SEGMENT_DURATION_SEC)) + 6)

            self.is_running = True
            self.watchdog_enabled = True
            self.start_time = time.time()
            self.last_log_truncate = time.time()
            
            self.supervisor_thread = threading.Thread(target=self._supervise_loop, daemon=True)
            self.supervisor_thread.start()
            
            # Watchdog en segundo plano que vigila estancamiento cada 3s
            self.watchdog_thread = threading.Thread(target=self._watchdog_loop, daemon=True)
            self.watchdog_thread.start()
            
            logger.info(f"Anillo de retención iniciado: {self.current_url} | Buffer: {self.max_segments} frags ({self.max_segments*SEGMENT_DURATION_SEC}s) | Calidad: {self.video_quality}")

    def _supervise_loop(self):
        """Bucle supervisor con auto-reconexión y buffer protegido (multiplataforma, sin shell)."""
        while self.is_running and self.current_url:
            segment_pattern = (self.buffer_dir / "seg_%03d.ts").as_posix()
            pipeline_spec = stream_resolver.build_ring_buffer_cmd(
                self.current_url,
                segment_pattern,
                SEGMENT_DURATION_SEC,
                self.max_segments,
                self.video_quality
            )
            
            platform_name = stream_resolver.detect_platform(self.current_url)
            buffer_dir_display = str(self.buffer_dir)
            logger.info(f"Lanzando pipeline universal de captura [{platform_name.upper()}] en {buffer_dir_display}...")
            log_file_path = get_shm_path("ring_pipeline.log")
            producer_proc = None
            consumer_proc = None
            try:
                flags = get_subprocess_flags(new_session=True)
                log_f = open(log_file_path, "a")
                self.start_time = time.time()

                if pipeline_spec["type"] == "ffmpeg_direct":
                    # Un solo proceso ffmpeg (ej: Kick HLS directo, TikTok HLS directo)
                    consumer_proc = subprocess.Popen(
                        pipeline_spec["args"],
                        stdout=subprocess.DEVNULL,
                        stderr=log_f,
                        **flags
                    )
                    with self.lock:
                        self.producer_process = None
                        self.process = consumer_proc
                    exit_code = consumer_proc.wait()
                else:
                    # Pipeline de dos procesos: productor (streamlink/yt-dlp) | consumidor (ffmpeg)
                    producer_proc = subprocess.Popen(
                        pipeline_spec["producer_args"],
                        stdout=subprocess.PIPE,
                        stderr=log_f,
                        **flags
                    )
                    consumer_proc = subprocess.Popen(
                        pipeline_spec["consumer_args"],
                        stdin=producer_proc.stdout,
                        stdout=subprocess.DEVNULL,
                        stderr=log_f,
                        **flags
                    )
                    # Permitir que el productor reciba SIGPIPE/EOF si el consumidor muere
                    producer_proc.stdout.close()
                    with self.lock:
                        self.producer_process = producer_proc
                        self.process = consumer_proc

                    # Esperar al consumidor (ffmpeg) como proceso principal
                    exit_code = consumer_proc.wait()
                    # Asegurar que el productor también termine
                    try:
                        if producer_proc.poll() is None:
                            kill_process_tree(producer_proc.pid)
                            producer_proc.wait(timeout=3)
                    except Exception:
                        pass

                log_f.close()
                
                if not self.is_running:
                    break
                
                # Leer las últimas líneas del log para diagnóstico
                stderr_tail = ""
                try:
                    with open(log_file_path, "r", errors="replace") as lf:
                        lines = lf.readlines()
                        stderr_tail = "".join(lines[-10:]).strip()
                except Exception:
                    pass

                # Comprobar si el directo ha finalizado
                stream_ended_markers = [
                    "this live event has ended",
                    "the live event is no longer available",
                    "stream is offline",
                    "live event has ended"
                ]
                is_stream_ended = any(marker.lower() in stderr_tail.lower() for marker in stream_ended_markers)
                if is_stream_ended:
                    clean_msg = "El directo en vivo ha finalizado en YouTube"
                    logger.info(f"🏁 [RingBuffer] {clean_msg}. Deteniendo anillo y notificando fin de directo...")
                    self.is_running = False
                    self.watchdog_enabled = False
                    if callable(self.on_stream_ended):
                        try:
                            self.on_stream_ended(clean_msg)
                        except Exception as e:
                            logger.error(f"Error en on_stream_ended callback: {e}")
                    break

                # Comprobar si ocurrió un error fatal de stream no recuperable
                fatal_markers = [
                    "This video is not available",
                    "Private video",
                    "Sign in to confirm",
                    "Video unavailable",
                    "members-only content",
                    "Premieres in",
                    "403 Forbidden",
                    "HTTP Error 403"
                ]
                is_fatal = any(marker.lower() in stderr_tail.lower() for marker in fatal_markers)
                if is_fatal:
                    clean_msg = "Video no disponible, privado o requiere inicio de sesión en YouTube"
                    for m in fatal_markers:
                        if m.lower() in stderr_tail.lower():
                            clean_msg = f"YouTube: {m}"
                            break
                    logger.error(f"⛔ [Fatal Stream Error] {clean_msg}. Deteniendo reintentos infinitos.")
                    self.fatal_error_message = clean_msg
                    self.is_running = False
                    self.watchdog_enabled = False
                    if callable(self.on_fatal_error):
                        try:
                            self.on_fatal_error(clean_msg)
                        except Exception:
                            pass
                    break

                if exit_code != 0 and stderr_tail:
                    logger.warning(
                        f"Pipeline terminado con código {exit_code}. stderr:\n{stderr_tail}\n"
                        f"Reiniciando en 3s..."
                    )
                else:
                    logger.warning(f"Pipeline terminado con código {exit_code}. Reiniciando en 3s...")
                time.sleep(3)
            except FileNotFoundError as fnf:
                producer_cmd_str = " ".join(str(a) for a in pipeline_spec.get("producer_args", []))
                consumer_cmd_str = " ".join(str(a) for a in pipeline_spec.get("consumer_args", [])) or " ".join(str(a) for a in pipeline_spec.get("args", []))
                failed_cmd = producer_cmd_str if not consumer_proc else consumer_cmd_str
                logger.error(
                    f"❌ [FileNotFoundError] Binario no encontrado al lanzar pipeline:\n"
                    f"   Comando fallido: {failed_cmd}\n"
                    f"   Productor: {producer_cmd_str}\n"
                    f"   Consumidor: {consumer_cmd_str}\n"
                    f"   Detalle: {fnf}"
                )
                for p in [producer_proc, consumer_proc]:
                    if p is not None:
                        try:
                            kill_process_tree(p.pid)
                        except Exception:
                            pass
                try:
                    log_f.close()
                except Exception:
                    pass
                if not self.is_running:
                    break
                time.sleep(3)
            except Exception as e:
                logger.error(f"Error en supervisor de anillo: {e}", exc_info=True)
                # Limpiar procesos huérfanos
                for p in [producer_proc, consumer_proc]:
                    if p is not None:
                        try:
                            kill_process_tree(p.pid)
                        except Exception:
                            pass
                try:
                    log_f.close()
                except Exception:
                    pass
                if not self.is_running:
                    break
                time.sleep(3)

    def prune_excess_segments(self):
        """
        Garantiza la retención estricta eliminando fragmentos .ts que excedan max_segments
        para proteger la memoria en /dev/shm o el disco de runtime_buffer.
        """
        try:
            if not self.buffer_dir.exists():
                return
            segments = list(self.buffer_dir.glob("seg_*.ts"))
            if len(segments) > self.max_segments:
                # Ordenar por tiempo de modificación ascendente (los más viejos primero)
                segments.sort(key=lambda p: p.stat().st_mtime)
                excess = segments[:-self.max_segments]
                for old_f in excess:
                    try:
                        old_f.unlink(missing_ok=True)
                    except Exception:
                        pass
        except Exception as e:
            logger.debug(f"Error podando fragmentos excedentes: {e}")

    def check_watchdog(self, max_staleness_sec: float = 15.0) -> bool:
        """
        Watchdog: Si el archivo .ts más reciente en RAM tiene más de 15s de antigüedad,
        mata y reinicia automáticamente el pipeline al instante.
        Trunca el log cada 10 min o si supera 100KB para evitar fuga de memoria.
        Aplica poda de retención estricta para no saturar memoria.
        """
        if not self.is_running or not self.watchdog_enabled or not self.current_url:
            return False

        # Poda de retención activa
        self.prune_excess_segments()

        now = time.time()
        
        # Mantenimiento de RAM: truncar log de ffmpeg si excede 100KB o pasaron 10 min
        log_file = get_shm_path("ring_pipeline.log")
        if log_file.exists():
            try:
                if log_file.stat().st_size > 100 * 1024 or (now - self.last_log_truncate) > 600.0:
                    with open(log_file, "w") as f:
                        f.truncate(0)
                    self.last_log_truncate = now
            except Exception:
                pass

        # Dar al menos 15s iniciales antes de disparar el watchdog
        if (now - self.start_time) < 15.0:
            return False

        segments = self.get_ordered_segments()
        if segments:
            newest = segments[-1]
            try:
                mtime = newest.stat().st_mtime
                staleness = now - mtime
                if staleness > max_staleness_sec:
                    logger.warning(f"🚨 [Watchdog] Buffer estancado ({staleness:.1f}s sin nuevos .ts > {max_staleness_sec}s). Reiniciando pipeline...")
                    self.restart_pipeline()
                    return True
            except Exception as e:
                logger.error(f"Error verificando mtime en watchdog: {e}")
        else:
            # Si pasaron más de 45s desde el inicio y aún no hay ningún archivo .ts (gracia extendida para YouTube Live)
            if (now - self.start_time) > 45.0:
                logger.warning("🚨 [Watchdog] 0 fragmentos tras 45s de inicio. Reiniciando pipeline...")
                self.restart_pipeline()
                return True
        return False

    def restart_pipeline(self):
        """Mata los procesos activos para que el supervisor los relance al instante."""
        with self.lock:
            for proc in [self.producer_process, self.process]:
                if proc:
                    try:
                        kill_process_tree(proc.pid)
                    except Exception:
                        pass
                    try:
                        proc.kill()
                    except Exception:
                        pass
                    try:
                        proc.wait(timeout=1.0)
                    except Exception:
                        pass
            self.producer_process = None
            self.process = None
            self.start_time = time.time()

    def _watchdog_loop(self):
        """Hilo supervisor de estancamiento (chequea cada 4 segundos)."""
        while self.is_running and self.current_url:
            time.sleep(4)
            try:
                self.check_watchdog(max_staleness_sec=15.0)
            except Exception as e:
                logger.error(f"Error en watchdog loop: {e}")

    def stop(self):
        """Detiene la captura y limpia completamente los procesos y RAM."""
        with self.lock:
            self.stop_and_reset_pipeline()

    def _stop_internal(self):
        self.stop_and_reset_pipeline()

    def get_status(self) -> Dict[str, Any]:
        """Obtiene métricas en vivo del buffer en RAM."""
        if not self.buffer_dir.exists():
            return {
                "active": False,
                "fragment_count": 0,
                "max_segments": self.max_segments,
                "video_quality": self.video_quality,
                "ram_mb": 0.0,
                "seconds_buffered": 0
            }
            
        segments = list(self.buffer_dir.glob("seg_*.ts"))
        total_bytes = sum(f.stat().st_size for f in segments)
        count = len(segments)
        
        return {
            "active": self.is_running and (self.process is not None and self.process.poll() is None),
            "fragment_count": count,
            "max_segments": self.max_segments,
            "video_quality": self.video_quality,
            "ram_mb": round(total_bytes / (1024 * 1024), 2),
            "seconds_buffered": count * SEGMENT_DURATION_SEC,
            "url": self.current_url
        }

    def get_ordered_segments(self) -> List[Path]:
        """
        Retorna la lista de archivos .ts ordenados cronológicamente por su tiempo de modificación (mtime).
        """
        if not self.buffer_dir.exists():
            return []
            
        segments = list(self.buffer_dir.glob("seg_*.ts"))
        # Filtrar archivos vacíos o menores a 10KB (archivos recién creados incompletos)
        valid_segments = [f for f in segments if f.stat().st_size > 10240]
        valid_segments.sort(key=lambda p: p.stat().st_mtime)
        return valid_segments

    def get_segments_for_clip(self, duration_sec: Optional[int] = None, pre_roll_sec: int = 12) -> List[Path]:
        """
        Selecciona los segmentos necesarios para un clip continuo de duración objetivo
        aplicando la compensación de latencia hacia atrás.
        """
        target_dur = duration_sec or self.clip_duration_sec
        ordered = self.get_ordered_segments()
        if not ordered:
            return []

        # Descartar el segmento más reciente porque ffmpeg aún puede estar escribiendo en él
        if len(ordered) > 1:
            candidates = ordered[:-1]
        else:
            candidates = ordered

        needed_count = max(3, int(round(target_dur / SEGMENT_DURATION_SEC)))
        pre_roll_offset = max(1, int(round(pre_roll_sec / SEGMENT_DURATION_SEC)))

        # Si tenemos suficientes segmentos, aplicamos el pre-roll
        if len(candidates) >= needed_count + pre_roll_offset:
            # Fin del bloque: retrocedemos pre_roll_offset desde el final
            end_idx = len(candidates) - pre_roll_offset
            start_idx = max(0, end_idx - needed_count)
            selected = candidates[start_idx:end_idx]
        else:
            # Si el buffer acaba de arrancar y aún no tiene todos los segmentos necesarios,
            # tomamos todos los disponibles hasta needed_count
            selected = candidates[-needed_count:]

        return selected


if __name__ == "__main__":
    mgr = RingBufferManager()
    print("RingBufferManager inicializado. Estado:", mgr.get_status())
