"""
server.py - Servidor FastAPI y Dashboard Web para Radar en Vivo y Rewind en RAM (Etapa 1).
Levanta en http://127.0.0.1:8765 con WebSocket para eventos en tiempo real.
"""

import os
import sys

# Erradicar crash nativo 0xC0000005 (-1073741819) por conflicto OpenMP/MKL o falta de AVX2
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "2")
os.environ.setdefault("MKL_NUM_THREADS", "2")
os.environ.setdefault("CT2_USE_EXPERIMENTAL_PACKED_GEMM", "0")

import re
import json
import time
import hashlib
import shutil
import atexit
import asyncio
import threading
import subprocess
import urllib.parse
import logging
import uuid
from collections import deque
from pathlib import Path
from typing import Dict, Any, Optional, List

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Response, status, UploadFile, File, Form, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import uvicorn

from radar_engine import RadarEngine
from stage2_worker import stage2_queue, CLIPS_VERTICALES
from vod_engine import vod_engine
from config_manager import load_config, save_config, ASSETS_DIR
from os_compat import get_shm_dir, get_shm_path, get_ffmpeg_cmd, IS_WIN, clean_dir_patterns, get_subprocess_flags
from simple_lock import is_system_activated, activate_system, get_machine_id
import stream_resolver
import updater

logger = logging.getLogger("server")


class MemoryLogHandler(logging.Handler):
    """Mantiene en memoria volátil las últimas 200 líneas de log para el informe de diagnóstico en 1 clic."""
    def __init__(self, maxlen: int = 200):
        super().__init__()
        self.records = deque(maxlen=maxlen)

    def emit(self, record):
        try:
            msg = self.format(record)
            self.records.append(msg)
        except Exception:
            pass

    def get_lines(self) -> List[str]:
        return list(self.records)


BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
INBOX_DIR = BASE_DIR / "inbox_brutos"
CLIP_STUDIO_UPLOAD_DIR = BASE_DIR / "runtime_buffer" / "clip_studio_uploads"
THUMBNAIL_CACHE_DIR = BASE_DIR / "runtime_buffer" / "gallery_thumbnails"
_thumbnail_semaphore = threading.BoundedSemaphore(2)
LOGS_DIR = BASE_DIR / "logs"
LOGS_DIR.mkdir(parents=True, exist_ok=True)
FILE_LOG_PATH = LOGS_DIR / "anyelo_clip.log"

memory_log_handler = MemoryLogHandler(maxlen=200)
memory_log_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] [%(name)s] %(message)s"))

from logging.handlers import RotatingFileHandler
def _make_file_log_handler(path: Path):
    return RotatingFileHandler(
        str(path),
        maxBytes=2 * 1024 * 1024,
        backupCount=2,
        encoding="utf-8"
    )

try:
    file_log_handler = _make_file_log_handler(FILE_LOG_PATH)
except OSError as primary_log_error:
    # Una segunda instancia puede encontrar el log principal bloqueado en Windows.
    process_log_path = LOGS_DIR / f"anyelo_clip_{os.getpid()}.log"
    try:
        file_log_handler = _make_file_log_handler(process_log_path)
        FILE_LOG_PATH = process_log_path
    except OSError as fallback_log_error:
        file_log_handler = logging.NullHandler()
        logging.getLogger("server").warning(
            f"No se pudo abrir un archivo de log; se conserva el log en memoria: {fallback_log_error}"
        )
    else:
        logging.getLogger("server").warning(
            f"El log principal está ocupado; usando log por proceso: {primary_log_error}"
        )
file_log_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] [%(name)s] %(message)s"))

root_logger = logging.getLogger()
if not any(isinstance(h, MemoryLogHandler) for h in root_logger.handlers):
    root_logger.addHandler(memory_log_handler)
if not any(isinstance(h, RotatingFileHandler) for h in root_logger.handlers):
    root_logger.addHandler(file_log_handler)

app = FastAPI(title="Anyelo Clip")

# Habilitar CORS total para permitir peticiones fetch y WebSockets desde extensiones de Chrome
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

engine = RadarEngine()

# Clientes WebSocket conectados
connected_websockets = set()


class StartRadarRequest(BaseModel):
    url: str
    threshold: float = 7.0
    max_clips: int = 5
    clip_duration_sec: int = 60
    video_quality: Optional[str] = "1080p"
    burn_subtitles: Optional[bool] = True
    auto_titles: Optional[bool] = True


class ThresholdRequest(BaseModel):
    threshold: float


class ManualClipRequest(BaseModel):
    url: str
    start_time: float = 0.0
    duration: float = 60.0
    source_type: str = "vod"
    custom_title: Optional[str] = None
    video_quality: Optional[str] = None


class Stage2RenderRequest(BaseModel):
    clip_id: str
    framing_mode: str = "AUTO"
    custom_title: Optional[str] = None
    start_sec: float = 0.0
    end_sec: Optional[float] = None
    video_quality: Optional[str] = None
    crop_offset_x: float = 0.0
    crop_offset_y: float = 0.0
    zoom: float = 1.0
    subtitle_base_color: Optional[str] = None
    subtitle_highlight_color: Optional[str] = None
    subtitle_font_size: Optional[int] = None
    subtitle_margin_v: Optional[int] = None
    overlay_image: Optional[str] = None
    overlay_x: float = 0.85
    overlay_y: float = 0.10
    overlay_scale: float = 0.20
    overlay_opacity: float = 1.0
    overlays: Optional[List[Dict[str, Any]]] = None
    gaming_cam_offset_x: float = 0.0
    gaming_cam_offset_y: float = 0.0
    gaming_cam_zoom: float = 1.0
    kept_segments: Optional[List[Dict[str, float]]] = None
    fade_out: bool = False
    burn_subtitles: bool = True
    auto_titles: bool = True


class StudioRenderRequest(BaseModel):
    clip_id: str
    custom_title: Optional[str] = None
    show_banner: bool = True
    banner_color: Optional[str] = None
    trim_start: float = 0.0
    trim_end: Optional[float] = None
    framing_mode: str = "AUTO"
    crop_offset_x: float = 0.0
    crop_offset_y: float = 0.0
    zoom: float = 1.0
    segments: Optional[List[Dict[str, Any]]] = None
    watermark_text: Optional[str] = None
    watermark_position: Optional[str] = None
    show_progress_bar: Optional[bool] = None
    video_quality: Optional[str] = None
    subtitle_base_color: Optional[str] = None
    subtitle_highlight_color: Optional[str] = None
    subtitle_font_size: Optional[int] = None
    subtitle_margin_v: Optional[int] = None
    overlay_image: Optional[str] = None
    overlay_x: float = 0.85
    overlay_y: float = 0.10
    overlay_scale: float = 0.20
    overlay_opacity: float = 1.0
    overlays: Optional[List[Dict[str, Any]]] = None
    gaming_cam_offset_x: float = 0.0
    gaming_cam_offset_y: float = 0.0
    gaming_cam_zoom: float = 1.0
    kept_segments: Optional[List[Dict[str, float]]] = None
    fade_out: bool = False
    burn_subtitles: bool = True
    auto_titles: bool = True
    audio_noise_reduction: bool = False
    audio_leveling: bool = True


class AutoRenderSettingsRequest(BaseModel):
    auto_render_916: bool
    min_render_score: float = 7.0
    burn_subtitles: Optional[bool] = True
    auto_titles: Optional[bool] = True


class LicenseActivateRequest(BaseModel):
    license_key: str


def cleanup_shm_at_exit():
    """Limpia de forma segura los archivos temporales (.ts, .wav, .ass) en SHM al apagar."""
    try:
        shm_dir = get_shm_dir()
        clean_dir_patterns(shm_dir, ["*.ts", "*.wav", "*.ass", "vod_audio.*", "temp_*.*"])
        rb_dir = shm_dir / "live_ring_buffer"
        if rb_dir.exists():
            clean_dir_patterns(rb_dir, ["*.ts", "*.wav", "*.tmp"])
    except Exception:
        pass


atexit.register(cleanup_shm_at_exit)


@app.on_event("shutdown")
def on_app_shutdown():
    cleanup_shm_at_exit()


MAIN_EVENT_LOOP: Optional[asyncio.AbstractEventLoop] = None


async def _safe_ws_send(ws: WebSocket, text: str):
    """Envío protegido que descarta el socket sin ruidos ni excepciones si el cliente se desconectó."""
    try:
        await ws.send_text(text)
    except (ConnectionResetError, WebSocketDisconnect):
        connected_websockets.discard(ws)
    except Exception as e:
        winerror = getattr(e, "winerror", None)
        errno = getattr(e, "errno", None)
        if winerror in (10054, 10038) or errno in (10054, 10038):
            connected_websockets.discard(ws)
        else:
            connected_websockets.discard(ws)


def ws_event_broadcaster(event: Dict[str, Any]):
    """Despacha eventos del radar hacia los clientes WebSocket conectados de forma thread-safe."""
    if not connected_websockets:
        return
    message_str = json.dumps(event, ensure_ascii=False)
    
    global MAIN_EVENT_LOOP
    loop = MAIN_EVENT_LOOP
    if not loop or loop.is_closed():
        try:
            loop = asyncio.get_running_loop()
            MAIN_EVENT_LOOP = loop
        except RuntimeError:
            loop = None

    if loop and loop.is_running():
        for ws in list(connected_websockets):
            asyncio.run_coroutine_threadsafe(_safe_ws_send(ws, message_str), loop)


engine.add_listener(ws_event_broadcaster)


def _on_stage2_event(evt: str, data: Any):
    if evt == "short_created" and isinstance(data, dict):
        short_obj = dict(data.get("short", data))
        filename = data.get("filename", "") or short_obj.get("file_name", "")
        if filename:
            mp4_file = CLIPS_VERTICALES / filename
            if mp4_file.exists() and "file_size_mb" not in short_obj:
                short_obj["file_size_mb"] = round(mp4_file.stat().st_size / (1024 * 1024), 2)
            if "video_url" not in short_obj:
                short_obj["video_url"] = f"/shorts/{filename}"
        ws_event_broadcaster({
            "type": "short_created",
            "filename": filename,
            "short": short_obj,
            "data": data
        })
    elif evt == "job_completed" and isinstance(data, dict):
        ws_event_broadcaster({"type": evt, "data": data})
    else:
        ws_event_broadcaster({"type": evt, "data": data})


stage2_queue.register_callback(_on_stage2_event)
vod_engine.register_clip_callback(lambda meta: ws_event_broadcaster({
    "type": "clip_created",
    "filename": meta.get("video_file", ""),
    "clip": meta,
    "data": meta
}))


@app.get("/favicon.ico", status_code=status.HTTP_204_NO_CONTENT)
async def get_favicon():
    """Ruta limpia para silenciar el 404 del navegador con 204 No Content."""
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@app.get("/", response_class=HTMLResponse)
async def get_index():
    index_file = STATIC_DIR / "index.html"
    if not index_file.exists():
        raise HTTPException(status_code=404, detail="index.html no encontrado")
    return HTMLResponse(
        content=index_file.read_text(encoding="utf-8"),
        headers={"Cache-Control": "no-store, no-cache, must-revalidate"}
    )


@app.get("/service-worker.js")
async def get_mobile_service_worker():
    """Sirve el service worker en la raíz para que Safari permita instalar la PWA."""
    return FileResponse(
        STATIC_DIR / "service-worker.js",
        media_type="application/javascript",
        headers={"Cache-Control": "no-cache"},
    )


@app.get("/manifest.webmanifest")
async def get_mobile_manifest():
    return FileResponse(
        STATIC_DIR / "manifest.webmanifest",
        media_type="application/manifest+json",
        headers={"Cache-Control": "no-cache"},
    )


@app.get("/icon.svg")
async def get_mobile_icon():
    return FileResponse(STATIC_DIR / "icon.svg", media_type="image/svg+xml")


@app.get("/apple-touch-icon.png")
async def get_mobile_apple_icon():
    return FileResponse(STATIC_DIR / "apple-touch-icon.png", media_type="image/png")


@app.get("/api/status")
async def get_status(response: Response):
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate"
    st = await asyncio.to_thread(engine.get_status)
    st["vod_processing"] = bool(vod_engine.is_running)
    st["queue_status"] = stage2_queue.get_status()
    st["has_last_crash"] = (LOGS_DIR / "last_crash.txt").is_file()
    try:
        from viral_brain import get_viral_brain
        brain = get_viral_brain()
        st["viral_brain"] = await asyncio.to_thread(brain.get_status)
    except Exception:
        st["viral_brain"] = {"n_samples": 0, "is_calibrated": False, "alpha": 0.0, "status_label": "Iniciando"}
    return st


@app.get("/api/system/performance")
async def get_system_performance(response: Response):
    """Devuelve m?tricas breves del equipo completo y del disco de la app."""
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate"

    def _read_metrics():
        import psutil
        cpu = psutil.cpu_percent(interval=0.15)
        memory = psutil.virtual_memory()
        disk = shutil.disk_usage(BASE_DIR)
        return {
            "cpu_percent": round(float(cpu), 1),
            "memory_used_bytes": int(memory.used),
            "memory_total_bytes": int(memory.total),
            "memory_percent": round(float(memory.percent), 1),
            "disk_used_bytes": int(disk.used),
            "disk_total_bytes": int(disk.total),
            "disk_percent": round((disk.used / disk.total) * 100, 1) if disk.total else 0.0,
            "disk_label": str(BASE_DIR.anchor or BASE_DIR)
        }

    try:
        return await asyncio.to_thread(_read_metrics)
    except Exception as exc:
        logger.warning(f"No se pudieron leer las m?tricas del PC: {exc}")
        raise HTTPException(status_code=503, detail="Las m?tricas del PC no est?n disponibles.")


@app.post("/api/brain/reset")
async def reset_viral_brain():
    """Resetea el aprendizaje de ViralBrain al estado de fábrica Día 1."""
    try:
        from viral_brain import get_viral_brain
        get_viral_brain().reset()
        return {"status": "ok", "message": "Aprendizaje de IA reseteado a valores de fábrica"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reseteando ViralBrain: {e}")


@app.get("/api/support/last_crash")
async def get_last_crash_info():
    f = LOGS_DIR / "last_crash.txt"
    if f.is_file():
        return {"has_crash": True, "detail": f.read_text(encoding="utf-8", errors="replace").strip()}
    return {"has_crash": False, "detail": ""}


@app.delete("/api/support/last_crash")
async def dismiss_last_crash():
    f = LOGS_DIR / "last_crash.txt"
    if f.is_file():
        try:
            f.unlink()
        except Exception:
            pass
    return {"status": "ok"}


@app.post("/api/radar/start")
async def start_radar(req: StartRadarRequest):
    active, msg, _ = is_system_activated()
    if not active:
        raise HTTPException(status_code=403, detail="Licencia no activada. Ingresa la clave firmada para esta PC.")
    if vod_engine.is_running:
        raise HTTPException(status_code=409, detail="Deten el proceso VOD actual antes de iniciar otro enlace.")
    try:
        await asyncio.to_thread(
            engine.start,
            req.url,
            threshold=req.threshold,
            max_clips=req.max_clips,
            clip_duration_sec=req.clip_duration_sec,
            video_quality=req.video_quality,
            burn_subtitles=req.burn_subtitles,
            auto_titles=req.auto_titles
        )
        if not engine.is_active:
            err_detail = getattr(engine, "last_error", "") or "No se pudo conectar con la URL proporcionada."
            raise HTTPException(status_code=400, detail=err_detail)
        return {
            "status": "ok",
            "message": "Radar iniciado",
            "url": req.url,
            "threshold": req.threshold,
            "clip_duration_sec": engine.clip_duration_sec,
            "video_quality": engine.video_quality
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/manual_clip")
async def manual_clip(req: ManualClipRequest):
    """
    Botón de acción rápida: '🔴 CLIPEAR AHORA (DESDE -10s)'
    - En VOD: descarga el rango exacto (T-10s a T-10s+D), transcribe y guarda.
    - En Live: graba el desenlace hacia adelante emitiendo updates en vivo por WebSocket.
    """
    active, msg, _ = is_system_activated()
    if not active:
        raise HTTPException(status_code=403, detail="Licencia no activada. Ingresa la clave firmada para esta PC.")

    url = req.url.strip() or engine.current_url.strip()
    if not url:
        raise HTTPException(status_code=400, detail="URL requerida para clipear")

    duration = float(req.duration or engine.clip_duration_sec or 60.0)

    # Determinar si es LIVE o VOD
    is_live = False
    if req.source_type == "live" or (engine.is_active and engine.mode == "live"):
        is_live = True
    elif req.source_type == "vod":
        is_live = False
    else:
        meta = await asyncio.to_thread(vod_engine.inspect_url, url)
        is_live = meta.get("is_live", False)

    if is_live:
        if not engine.is_active:
            raise HTTPException(status_code=400, detail="El directo debe estar activo en el radar para clipear en vivo")
        engine.trigger_manual_live_clip(duration)
        return {
            "status": "recording_live",
            "source_type": "live",
            "duration": duration,
            "message": f"Grabando desenlace de {duration}s en vivo..."
        }
    else:
        # Modo VOD
        start_time = max(0.0, float(req.start_time))
        def _run_vod_manual():
            clip_res = vod_engine.extract_single_clip_vod(
                url=url,
                start_sec=start_time,
                duration=duration,
                custom_title=req.custom_title,
                video_quality=req.video_quality
            )
            if clip_res:
                ws_event_broadcaster({"type": "new_clip_extracted", "data": clip_res})
                if engine.auto_render_916:
                    stage2_queue.enqueue(
                        clip_res["clip_id"],
                        framing_mode="AUTO",
                        video_quality=req.video_quality,
                        is_manual=True,
                        burn_subtitles=getattr(engine, "burn_subtitles", True),
                        auto_titles=getattr(engine, "auto_titles", True)
                    )

        th = threading.Thread(target=_run_vod_manual, daemon=True)
        th.start()
        return {
            "status": "processing_vod",
            "source_type": "vod",
            "start_time": start_time,
            "duration": duration,
            "message": f"Descargando y procesando clip VOD ({duration}s)..."
        }


@app.delete("/api/clips/{clip_id}")
async def delete_clip(clip_id: str):
    """Elimina un clip bruto de inbox_brutos."""
    if clip_id.endswith(".mp4") or clip_id.endswith(".json"):
        clip_id = Path(clip_id).stem
    
    mp4_path = INBOX_DIR / f"{clip_id}.mp4"
    json_path = INBOX_DIR / f"{clip_id}.json"
    
    deleted = False
    try:
        # Feedback silencioso ViralBrain: rechazo implícito (label = 0.0)
        if json_path.exists():
            try:
                with open(json_path, "r", encoding="utf-8") as jf:
                    meta = json.load(jf)
                from viral_brain import get_viral_brain
                acoustics = {
                    "peak_level": meta.get("peak_level", 0.0),
                    "rms_energy": meta.get("rms_energy", 0.0),
                    "dynamic_variance": meta.get("dynamic_variance", 0.0),
                    "spectral_flux": meta.get("spectral_flux", 0.0)
                }
                text = meta.get("transcripcion_base", "")
                dur = float(meta.get("duracion_segundos", 60.0))
                get_viral_brain().learn(acoustics, text, label=0.0, duration_sec=dur)
            except Exception:
                pass

        if mp4_path.exists():
            mp4_path.unlink()
            deleted = True
        if json_path.exists():
            json_path.unlink()
            deleted = True
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error borrando clip: {e}")
        
    if not deleted:
        raise HTTPException(status_code=404, detail="Clip no encontrado")
        
    return {"status": "ok", "deleted_clip_id": clip_id}


@app.delete("/api/shorts/{short_id}")
async def delete_short(short_id: str):
    """Elimina un short vertical de clips_verticales."""
    if short_id.endswith(".mp4") or short_id.endswith(".json"):
        short_id = Path(short_id).stem
        
    mp4_path = CLIPS_VERTICALES / f"{short_id}.mp4"
    json_path = CLIPS_VERTICALES / f"{short_id}.json"
    
    deleted = False
    try:
        # Feedback silencioso ViralBrain: rechazo implícito (label = 0.0)
        if json_path.exists():
            try:
                with open(json_path, "r", encoding="utf-8") as jf:
                    meta = json.load(jf)
                from viral_brain import get_viral_brain
                acoustics = {
                    "peak_level": meta.get("peak_level", 0.0),
                    "rms_energy": meta.get("rms_energy", 0.0),
                    "dynamic_variance": meta.get("dynamic_variance", 0.0),
                    "spectral_flux": meta.get("spectral_flux", 0.0)
                }
                text = meta.get("transcripcion_base", "")
                dur = float(meta.get("duracion_segundos", 60.0))
                get_viral_brain().learn(acoustics, text, label=0.0, duration_sec=dur)
            except Exception:
                pass

        if mp4_path.exists():
            mp4_path.unlink()
            deleted = True
        if json_path.exists():
            json_path.unlink()
            deleted = True
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error borrando short: {e}")
        
    if not deleted:
        raise HTTPException(status_code=404, detail="Short no encontrado")
        
    return {"status": "ok", "deleted_short_id": short_id}


@app.get("/api/clips/{clip_id}")
async def get_clip_details(clip_id: str):
    """Obtiene metadatos completos y segmentos de un clip bruto."""
    if clip_id.endswith(".mp4") or clip_id.endswith(".json"):
        clip_id = Path(clip_id).stem
    json_path = INBOX_DIR / f"{clip_id}.json"
    mp4_path = INBOX_DIR / f"{clip_id}.mp4"
    if not json_path.exists() and not mp4_path.exists():
        raise HTTPException(status_code=404, detail="Clip no encontrado")
    meta = {}
    if json_path.exists():
        try:
            with open(json_path, "r", encoding="utf-8") as f:
                meta = json.load(f)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error leyendo metadatos: {e}")
    meta["clip_id"] = clip_id
    meta["video_url"] = f"/clips/{clip_id}.mp4"
    return meta


@app.get("/api/shorts/{short_id}")
async def get_short_details(short_id: str):
    """Obtiene metadatos y segmentos de un short 9:16."""
    if short_id.endswith(".mp4") or short_id.endswith(".json"):
        short_id = Path(short_id).stem
    json_path = CLIPS_VERTICALES / f"{short_id}.json"
    mp4_path = CLIPS_VERTICALES / f"{short_id}.mp4"
    if not json_path.exists() and not mp4_path.exists():
        raise HTTPException(status_code=404, detail="Short no encontrado")
    meta = {}
    if json_path.exists():
        try:
            with open(json_path, "r", encoding="utf-8") as f:
                meta = json.load(f)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error leyendo metadatos: {e}")
    meta["short_id"] = short_id
    meta["video_url"] = f"/shorts/{short_id}.mp4"
    raw_id = meta.get("raw_clip_id")
    if raw_id and (INBOX_DIR / f"{raw_id}.mp4").exists():
        meta["raw_video_url"] = f"/clips/{raw_id}.mp4"
    return meta


@app.post("/api/open_folder")
async def open_shorts_folder():
    """Abre la carpeta clips_verticales en el explorador de archivos del sistema."""
    target_dir = CLIPS_VERTICALES.resolve()
    target_dir.mkdir(parents=True, exist_ok=True)
    target_str = str(target_dir)

    try:
        if IS_WIN:
            os.startfile(target_str)
        else:
            cmd = "xdg-open" if shutil.which("xdg-open") else ("open" if shutil.which("open") else None)
            if cmd:
                subprocess.Popen([cmd, target_str])
            else:
                return {
                    "status": "warning",
                    "message": f"Explorador de archivos no detectado, carpeta en: {target_str}",
                    "path": target_str
                }
        return {"status": "ok", "path": target_str}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"No se pudo abrir la carpeta: {e}")


@app.get("/api/support/diagnostics")
async def get_support_diagnostics(request: Request):
    """
    Empaqueta un informe técnico completo para soporte y diagnóstico en 1 clic (.ZIP):
    - system_info.json: Entorno OS, CPU, RAM, presencia de ffmpeg, deno, vcruntime140_1.dll, perfil Whisper.
    - config_sanitized.json: Configuración de la app sin filtrar la clave de licencia ni firmas.
    - logs/anyelo_clip.log: Logs persistentes en disco.
    - logs/last_crash.txt: Registro de último crash nativo (si existe).
    """
    import io
    import zipfile
    import platform
    from os_compat import (
        get_ffmpeg_cmd, get_ffprobe_cmd, get_streamlink_cmd, get_ytdlp_cmd,
        get_deno_path, resolve_safe_whisper_profile
    )

    def probe_version(cmd_target):
        try:
            cmd = [*cmd_target, "--version"] if isinstance(cmd_target, list) else [cmd_target, "-version"]
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=4)
            out = (res.stdout or res.stderr or "").strip().splitlines()
            return out[0] if out else "OK"
        except Exception as e:
            return f"Error probando: {e}"

    sys_info = {
        "os_name": os.name,
        "platform": platform.platform(),
        "system": platform.system(),
        "release": platform.release(),
        "version": platform.version(),
        "architecture": platform.architecture(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "python_version": sys.version,
        "cpu_count": os.cpu_count(),
    }

    vcruntime_path = r"C:\Windows\System32\vcruntime140_1.dll" if IS_WIN else "/usr/lib64/libstdc++.so.6"
    sys_info["vcruntime140_1_present"] = os.path.exists(vcruntime_path)

    try:
        import psutil
        vmem = psutil.virtual_memory()
        sys_info["ram_total_mb"] = round(vmem.total / (1024 * 1024), 1)
        sys_info["ram_available_mb"] = round(vmem.available / (1024 * 1024), 1)
        sys_info["ram_percent"] = vmem.percent
    except Exception:
        sys_info["ram_info"] = "psutil no disponible"

    deno_path = get_deno_path()
    bin_info = {
        "ffmpeg": {
            "path": get_ffmpeg_cmd(),
            "version": await asyncio.to_thread(probe_version, get_ffmpeg_cmd())
        },
        "ffprobe": {
            "path": get_ffprobe_cmd(),
            "version": await asyncio.to_thread(probe_version, get_ffprobe_cmd())
        },
        "streamlink": {
            "path": get_streamlink_cmd(),
            "version": await asyncio.to_thread(probe_version, get_streamlink_cmd())
        },
        "yt_dlp": {
            "path": get_ytdlp_cmd(),
            "version": await asyncio.to_thread(probe_version, get_ytdlp_cmd())
        },
        "deno": {
            "path": deno_path,
            "present": bool(deno_path and os.path.exists(deno_path))
        }
    }

    try:
        whisper_prof = await asyncio.to_thread(resolve_safe_whisper_profile)
    except Exception as e:
        whisper_prof = f"Error: {e}"

    lic_active, lic_msg, lic_info = is_system_activated()
    masked_key = "NO_CONFIGURADA"
    raw_key = (lic_info or {}).get("license_key") or ""
    if raw_key:
        masked_key = f"XXXX-XXXX-XXXX-{raw_key[-4:]}" if len(raw_key) >= 4 else "XXXX"

    masked_lic = {
        "active": lic_active,
        "message": lic_msg,
        "machine_id": (lic_info or {}).get("machine_id"),
        "key_masked": masked_key
    }

    cfg = load_config()
    sanitized_cfg = {k: v for k, v in cfg.items() if k not in ("license_key", "license_signature")}
    if "license_key" in cfg:
        sanitized_cfg["license_key_masked"] = masked_key

    report = {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "system_info": sys_info,
        "binaries": bin_info,
        "whisper_verified_profile": whisper_prof,
        "license": masked_lic,
        "app_config": sanitized_cfg,
        "recent_logs": memory_log_handler.get_lines()
    }

    # Si se pide explícitamente formato json (?format=json) devolver payload directo
    if request.query_params.get("format") == "json":
        report_json = json.dumps(report, indent=2, ensure_ascii=False)
        return Response(
            content=report_json,
            media_type="application/json",
            headers={"Cache-Control": "no-cache, no-store, must-revalidate"}
        )

    # Generar archivo .zip en memoria
    zip_buf = io.BytesIO()
    with zipfile.ZipFile(zip_buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("system_info.json", json.dumps({
            "generated_at": report["generated_at"],
            "system_info": sys_info,
            "binaries": bin_info,
            "whisper_verified_profile": whisper_prof,
            "license": masked_lic
        }, indent=2, ensure_ascii=False))

        zf.writestr("config_sanitized.json", json.dumps(sanitized_cfg, indent=2, ensure_ascii=False))

        if FILE_LOG_PATH.is_file() and FILE_LOG_PATH.stat().st_size > 0:
            zf.writestr("logs/anyelo_clip.log", FILE_LOG_PATH.read_text(encoding="utf-8", errors="replace"))
        else:
            zf.writestr("logs/anyelo_clip.log", "\n".join(memory_log_handler.get_lines()))

        last_crash_file = LOGS_DIR / "last_crash.txt"
        if last_crash_file.is_file():
            zf.writestr("logs/last_crash.txt", last_crash_file.read_text(encoding="utf-8", errors="replace"))

    zip_buf.seek(0)
    zip_filename = f"AnyeloClip_Diagnostico_{time.strftime('%Y%m%d_%H%M%S')}.zip"
    return Response(
        content=zip_buf.getvalue(),
        media_type="application/zip",
        headers={
            "Content-Disposition": f"attachment; filename={zip_filename}",
            "Cache-Control": "no-cache, no-store, must-revalidate"
        }
    )


@app.get("/api/system/logs")
async def get_system_logs(limit: int = 50):
    """Retorna las últimas N líneas de log para inicializar y sincronizar la terminal web."""
    lines = memory_log_handler.get_lines()
    recent = lines[-limit:] if len(lines) > limit else lines
    return {
        "status": "ok",
        "logs": recent
    }


class ApplyUpdateRequest(BaseModel):
    download_url: str
    sha256: str


@app.get("/api/system/check-update")
async def check_system_update():
    """Consulta si existe una nueva versión o parche disponible en GitHub Releases."""
    data = await asyncio.to_thread(updater.check_for_updates)
    return data


@app.post("/api/system/apply-update")
async def apply_system_update(req: ApplyUpdateRequest):
    """Descarga y aplica un parche seguro (.py/.html/.js/.css) verificando SHA256."""
    res = await asyncio.to_thread(updater.apply_patch_update, req.download_url, req.sha256)
    if not res.get("ok"):
        raise HTTPException(status_code=400, detail=res.get("error", "Error aplicando actualización"))
    return res


class LocalFileVodRequest(BaseModel):
    file_path: str
    max_clips: int = 5
    clip_duration_sec: int = 60
    video_quality: str = "1080p"
    burn_subtitles: Optional[bool] = True
    auto_titles: Optional[bool] = True
    auto_render_916: Optional[bool] = None


@app.post("/api/vod/local_file")
async def process_local_file_vod(req: LocalFileVodRequest):
    """Procesa un archivo local ya presente en el equipo."""
    return await _process_local_file_vod(req)


async def _process_local_file_vod(req: LocalFileVodRequest, cleanup_uploaded_source: bool = False):
    active, msg, _ = is_system_activated()
    if not active:
        raise HTTPException(status_code=403, detail="Licencia no activada.")

    p = Path(req.file_path).expanduser().resolve()
    if not p.is_file():
        raise HTTPException(status_code=404, detail=f"Archivo no encontrado en el sistema: {req.file_path}")

    valid_exts = {".mp4", ".mkv", ".mov", ".avi", ".webm", ".ts"}
    if p.suffix.lower() not in valid_exts:
        raise HTTPException(status_code=400, detail=f"Extension no admitida ({p.suffix}). Validas: {', '.join(valid_exts)}")

    await asyncio.to_thread(engine.stop)
    engine.mode = "vod"
    engine.is_active = True
    engine.current_url = str(p)
    engine.clip_duration_sec = req.clip_duration_sec
    engine.video_quality = req.video_quality
    if req.burn_subtitles is not None:
        engine.burn_subtitles = req.burn_subtitles
        vod_engine.burn_subtitles = req.burn_subtitles
    if req.auto_titles is not None:
        engine.auto_titles = req.auto_titles
        vod_engine.auto_titles = req.auto_titles

    def _run():
        try:
            vod_engine.start_vod_harvest(
                url=str(p),
                max_clips=req.max_clips,
                clip_duration_sec=req.clip_duration_sec,
                progress_cb=engine._on_vod_progress,
                auto_render_916=(req.auto_render_916 if req.auto_render_916 is not None else engine.auto_render_916),
                min_render_score=engine.min_render_score,
                video_quality=req.video_quality,
                burn_subtitles=req.burn_subtitles,
                auto_titles=req.auto_titles
            )
            if cleanup_uploaded_source:
                worker = vod_engine.worker_thread
                if worker and worker is not threading.current_thread():
                    worker.join()
        finally:
            if cleanup_uploaded_source:
                try:
                    p.unlink(missing_ok=True)
                except OSError as exc:
                    logger.warning(f"No se pudo borrar el video temporal subido: {exc}")

    threading.Thread(target=_run, daemon=True).start()
    return {"status": "ok", "mode": "vod", "file_path": str(p), "file_name": p.name}


@app.post("/api/vod/upload")
async def upload_clip_studio_video(
    file: UploadFile = File(...),
    max_clips: int = Form(5),
    clip_duration_sec: int = Form(60),
    video_quality: str = Form("1080p"),
    burn_subtitles: bool = Form(False),
    auto_titles: bool = Form(False),
    auto_render_916: bool = Form(True)
):
    """Recibe un video local temporal y lo envia al analizador VOD existente."""
    active, _, _ = is_system_activated()
    if not active:
        raise HTTPException(status_code=403, detail="Activa la licencia para procesar videos.")
    if engine.is_active or vod_engine.is_running:
        raise HTTPException(status_code=409, detail="Deten el proceso actual antes de iniciar otro video.")

    allowed_exts = {".mp4", ".mkv", ".mov", ".avi", ".webm", ".ts"}
    original_name = Path(file.filename or "video").name
    suffix = Path(original_name).suffix.lower()
    if suffix not in allowed_exts:
        raise HTTPException(status_code=400, detail="Formato no admitido. Usa MP4, MKV, MOV, AVI, WEBM o TS.")
    if not 1 <= max_clips <= 9999:
        raise HTTPException(status_code=400, detail="La cantidad de clips debe estar entre 1 y 9999.")
    if not 15 <= clip_duration_sec <= 600:
        raise HTTPException(status_code=400, detail="La duracion debe estar entre 15 y 600 segundos.")
    if video_quality not in {"480p", "720p", "1080p", "max"}:
        raise HTTPException(status_code=400, detail="Calidad de video no valida.")

    CLIP_STUDIO_UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    uploaded_path = CLIP_STUDIO_UPLOAD_DIR / f"clip_studio_{uuid.uuid4().hex}{suffix}"
    total_bytes = 0
    max_bytes = 2 * 1024 * 1024 * 1024
    try:
        with uploaded_path.open("wb") as target:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                total_bytes += len(chunk)
                if total_bytes > max_bytes:
                    raise HTTPException(status_code=413, detail="El video supera el limite de 2 GB.")
                target.write(chunk)

        if total_bytes == 0:
            raise HTTPException(status_code=400, detail="El archivo de video esta vacio.")

        req = LocalFileVodRequest(
            file_path=str(uploaded_path),
            max_clips=max_clips,
            clip_duration_sec=clip_duration_sec,
            video_quality=video_quality,
            burn_subtitles=burn_subtitles,
            auto_titles=auto_titles,
            auto_render_916=auto_render_916
        )
        result = await _process_local_file_vod(req, cleanup_uploaded_source=True)
        result["source_name"] = original_name
        result["upload_bytes"] = total_bytes
        return result
    except HTTPException:
        try:
            uploaded_path.unlink(missing_ok=True)
        except OSError:
            pass
        raise
    except Exception as exc:
        try:
            uploaded_path.unlink(missing_ok=True)
        except OSError:
            pass
        logger.exception("Error subiendo video al Estudio de Clips")
        raise HTTPException(status_code=500, detail=f"No se pudo preparar el video: {exc}")
    finally:
        await file.close()


@app.get("/api/license/status")
async def get_license_status():
    """Devuelve el estado de activación de la licencia y metadatos anónimos de hardware."""
    active, msg, info = is_system_activated()
    return {"active": active, "message": msg, "info": info}


@app.post("/api/license/activate")
async def activate_license(req: LicenseActivateRequest):
    """Activa Anyelo Clip con una clave RSA firmada para esta PC."""
    success, msg = activate_system(req.license_key)
    if not success:
        raise HTTPException(status_code=400, detail=msg)
    active, _, info = is_system_activated()
    return {"status": "ok", "message": msg, "info": info}


@app.get("/api/proxy_hls")
async def proxy_hls(url: str):
    """
    Proxy CORS y Cloudflare bypass para reproducción HLS de Kick, TikTok y streams en vivo.
    Descarga listas de reproducción .m3u8 y reescribe URIs internas para pasar por este proxy.
    Sirve segmentos de video .ts / .mp4 con encabezados CORS permisivos para hls.js.
    """
    if not url:
        raise HTTPException(status_code=400, detail="URL no proporcionada")

    clean_target = url.strip()
    headers = {
        "User-Agent": stream_resolver.DESKTOP_UA,
    }
    target_lower = clean_target.lower()
    if "kick" in target_lower or "ivs" in target_lower:
        headers["Referer"] = "https://kick.com/"
        headers["Origin"] = "https://kick.com"
    elif "ttvnw" in target_lower or "twitch" in target_lower:
        headers["Referer"] = "https://www.twitch.tv/"
        headers["Origin"] = "https://www.twitch.tv"
    elif "tiktok" in target_lower:
        headers["Referer"] = "https://www.tiktok.com/"
        headers["Origin"] = "https://www.tiktok.com"

    content_bytes = None
    content_type = ""
    status_code = 200

    # 1. Petición con curl_cffi para bypass TLS/Cloudflare
    try:
        from curl_cffi import requests as cffi_requests
        r = await asyncio.to_thread(cffi_requests.get, clean_target, headers=headers, impersonate="chrome120", timeout=10)
        status_code = r.status_code
        content_bytes = r.content
        content_type = r.headers.get("Content-Type", "")
    except Exception as e:
        logger.warning(f"Aviso proxy curl_cffi ({clean_target[:60]}...): {e}")
        try:
            import requests
            r = await asyncio.to_thread(requests.get, clean_target, headers=headers, timeout=10)
            status_code = r.status_code
            content_bytes = r.content
            content_type = r.headers.get("Content-Type", "")
        except Exception as e2:
            raise HTTPException(status_code=502, detail=f"Error obteniendo stream remoto: {e2}")

    if status_code >= 400:
        raise HTTPException(status_code=status_code, detail="Error remoto al solicitar stream")

    # 2. Comprobar si es lista de reproducción M3U8
    is_m3u8 = (
        clean_target.split("?")[0].endswith(".m3u8")
        or "mpegurl" in content_type.lower()
        or (content_bytes and content_bytes.startswith(b"#EXTM3U"))
    )

    if is_m3u8:
        try:
            text = content_bytes.decode("utf-8", errors="replace")
            lines = text.splitlines()
            rewritten_lines = []
            for line in lines:
                sline = line.strip()
                if not sline:
                    rewritten_lines.append(line)
                    continue
                if sline.startswith("#"):
                    if 'URI="' in sline:
                        def _replace_uri(match):
                            raw_uri = match.group(1)
                            full_uri = urllib.parse.urljoin(clean_target, raw_uri)
                            proxy_uri = f"/api/proxy_hls?url={urllib.parse.quote(full_uri, safe='')}"
                            return f'URI="{proxy_uri}"'
                        rewritten_line = re.sub(r'URI="([^"]+)"', _replace_uri, line)
                        rewritten_lines.append(rewritten_line)
                    else:
                        rewritten_lines.append(line)
                else:
                    full_uri = urllib.parse.urljoin(clean_target, sline)
                    proxy_uri = f"/api/proxy_hls?url={urllib.parse.quote(full_uri, safe='')}"
                    rewritten_lines.append(proxy_uri)

            new_body = "\n".join(rewritten_lines).encode("utf-8")
            return Response(
                content=new_body,
                media_type="application/vnd.apple.mpegurl",
                headers={
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
                    "Access-Control-Allow-Headers": "*",
                    "Cache-Control": "no-cache, no-store, must-revalidate"
                }
            )
        except Exception as e:
            logger.warning(f"Error parseando M3U8: {e}")

    # 3. Entrega de fragmentos multimedia (.ts, .m4s, etc.)
    res_mime = content_type if content_type else "video/mp2t"
    return Response(
        content=content_bytes,
        media_type=res_mime,
        headers={
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
            "Access-Control-Allow-Headers": "*",
            "Cache-Control": "public, max-age=3600"
        }
    )


@app.get("/api/live/platform_info")
async def get_live_platform_info(url: str):
    """Devuelve la información de plataforma, canal, iframe y URL HLS proxy para el monitor universal."""
    clean_url = url.strip()
    norm_url = clean_url if clean_url.startswith(("http://", "https://")) else f"https://{clean_url}"
    platform = stream_resolver.detect_platform(norm_url)
    info = stream_resolver.parse_channel_info(norm_url)

    # Intentar resolver stream directo (.m3u8) para Kick, Twitch o TikTok
    hls_proxy_url = None
    direct_url, _ = await asyncio.to_thread(stream_resolver.resolve_direct_stream_url, norm_url)
    if direct_url and (direct_url.startswith("http://") or direct_url.startswith("https://")):
        hls_proxy_url = f"/api/proxy_hls?url={urllib.parse.quote(direct_url, safe='')}"

    player_type = "iframe"
    if hls_proxy_url and platform in ("kick", "twitch", "tiktok"):
        player_type = "hls"
    elif platform == "tiktok":
        player_type = "video"
    elif not info.get("embed_url"):
        player_type = "hls" if hls_proxy_url else "none"

    return {
        "platform": platform,
        "channel": info.get("channel"),
        "video_id": info.get("video_id"),
        "is_vod": info.get("is_vod"),
        "embed_url": info.get("embed_url"),
        "direct_url": direct_url,
        "hls_proxy_url": hls_proxy_url,
        "player_type": player_type
    }


@app.get("/api/live/preview_stream")
async def get_live_preview_stream():
    """
    Sirve el fragmento más reciente del buffer en RAM como video MP4 ligero
    para el monitor del Dashboard (ideal para Kick, TikTok Live o streams sin iframe embebible).
    Usa buffers rotativos en memoria para evitar bloqueos WinError 32 en Windows.
    """
    segments = await asyncio.to_thread(engine.ring_buffer.get_ordered_segments)
    if not segments:
        raise HTTPException(status_code=404, detail="Buffer en RAM vacío o radar inactivo")

    target_seg = segments[-2] if len(segments) > 1 else segments[-1]
    rot_id = int(time.time() * 2) % 6
    preview_mp4 = get_shm_path(f"preview_monitor_{rot_id}.mp4")

    try:
        ffmpeg_bin = get_ffmpeg_cmd()
        sub_flags = get_subprocess_flags(low_priority=True)
        await asyncio.to_thread(subprocess.run, [
            ffmpeg_bin, "-y", "-hide_banner", "-loglevel", "error",
            "-i", str(target_seg),
            "-c", "copy",
            "-movflags", "+faststart",
            str(preview_mp4)
        ], timeout=2.5, **sub_flags)

        if preview_mp4.exists():
            with open(preview_mp4, "rb") as pf:
                data = pf.read()
            return Response(
                content=data,
                media_type="video/mp4",
                headers={
                    "Cache-Control": "no-cache, no-store, must-revalidate",
                    "Access-Control-Allow-Origin": "*",
                    "Content-Type": "video/mp4"
                }
            )
    except Exception as e:
        logger.warning(f"Aviso remuxando preview MP4: {e}")

    try:
        with open(target_seg, "rb") as tf:
            tdata = tf.read()
        return Response(
            content=tdata,
            media_type="video/mp2t",
            headers={
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Access-Control-Allow-Origin": "*"
            }
        )
    except Exception:
        raise HTTPException(status_code=404, detail="No se pudo leer fragmento de preview")


@app.get("/api/editor/overlays")
async def list_editor_overlays():
    """Lista todos los overlays PNG/JPG disponibles en assets/overlays y assets/logo.png."""
    overlays_dir = ASSETS_DIR / "overlays"
    overlays_dir.mkdir(parents=True, exist_ok=True)
    res = []
    
    logo_file = ASSETS_DIR / "logo.png"
    if logo_file.exists():
        res.append({
            "name": "Logo Canal (logo.png)",
            "path": "assets/logo.png",
            "asset_path": "assets/logo.png",
            "url": "/assets/logo.png",
            "size_kb": round(logo_file.stat().st_size / 1024, 1)
        })
        
    for f in sorted(overlays_dir.glob("*"), key=lambda x: x.stat().st_mtime, reverse=True):
        if f.is_file() and f.suffix.lower() in [".png", ".jpg", ".jpeg", ".webp"]:
            rel_path = f"assets/overlays/{f.name}"
            res.append({
                "name": f.name,
                "path": rel_path,
                "asset_path": rel_path,
                "url": f"/assets/overlays/{f.name}",
                "size_kb": round(f.stat().st_size / 1024, 1)
            })
    return {"status": "ok", "overlays": res}


@app.post("/api/editor/upload_overlay")
@app.post("/api/assets/upload")
async def upload_asset(file: UploadFile = File(...)):
    """Sube un archivo de imagen/logo (.png, .jpg, .webp) para overlay en el editor visual."""
    ext = Path(file.filename or "overlay.png").suffix.lower()
    if ext not in [".png", ".jpg", ".jpeg", ".webp"]:
        raise HTTPException(status_code=400, detail="Formato de imagen no soportado (solo .png, .jpg, .jpeg, .webp)")
    
    overlays_dir = ASSETS_DIR / "overlays"
    overlays_dir.mkdir(parents=True, exist_ok=True)
    clean_stem = re.sub(r'[^a-zA-Z0-9_-]', '_', Path(file.filename or "overlay").stem)
    filename = f"overlay_{clean_stem}_{int(time.time())}{ext}"
    target_path = overlays_dir / filename
    
    content = await file.read()
    with open(target_path, "wb") as f:
        f.write(content)
        
    return {
        "status": "ok",
        "file_name": filename,
        "name": file.filename or filename,
        "path": f"assets/overlays/{filename}",
        "asset_path": f"assets/overlays/{filename}",
        "url": f"/assets/overlays/{filename}"
    }


@app.post("/api/studio_render")
async def post_studio_render(req: StudioRenderRequest):
    """Re-renderiza un clip o short desde el Estudio de Edición con cero re-transcripción."""
    active, msg, _ = is_system_activated()
    if not active:
        raise HTTPException(status_code=403, detail="Licencia no activada. Ingresa la clave firmada para esta PC.")
    try:
        res = await asyncio.to_thread(
            stage2_queue.render_studio_clip,
            clip_id=req.clip_id,
            custom_title=req.custom_title,
            show_banner=req.show_banner,
            banner_color=req.banner_color,
            trim_start=req.trim_start,
            trim_end=req.trim_end,
            framing_mode=req.framing_mode,
            crop_offset_x=req.crop_offset_x,
            crop_offset_y=req.crop_offset_y,
            zoom=req.zoom,
            segments=req.segments,
            watermark_text=req.watermark_text,
            watermark_position=req.watermark_position,
            show_progress_bar=req.show_progress_bar,
            video_quality=req.video_quality,
            subtitle_base_color=req.subtitle_base_color,
            subtitle_highlight_color=req.subtitle_highlight_color,
            subtitle_font_size=req.subtitle_font_size,
            subtitle_margin_v=req.subtitle_margin_v,
            overlay_image=req.overlay_image,
            overlay_x=req.overlay_x,
            overlay_y=req.overlay_y,
            overlay_scale=req.overlay_scale,
            overlay_opacity=req.overlay_opacity,
            overlays=req.overlays,
            gaming_cam_offset_x=req.gaming_cam_offset_x,
            gaming_cam_offset_y=req.gaming_cam_offset_y,
            gaming_cam_zoom=req.gaming_cam_zoom,
            kept_segments=req.kept_segments,
            fade_out=req.fade_out,
            burn_subtitles=req.burn_subtitles,
            auto_titles=req.auto_titles,
            audio_noise_reduction=req.audio_noise_reduction,
            audio_leveling=req.audio_leveling
        )
        return {"status": "ok", "result": res}
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Error en studio_render: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error al renderizar en Estudio: {e}")


@app.get("/api/settings/config")
async def get_config_endpoint():
    """Retorna la configuración persistente del canal (vocabulario, marca de agua, etc.)."""
    return load_config()


@app.post("/api/settings/config")
async def update_config_endpoint(payload: Dict[str, Any]):
    """Actualiza la configuración persistente en config.json."""
    old_cfg = load_config()
    old_quality = old_cfg.get("video_quality", "1080p")
    updated = save_config(payload)
    
    if "clip_duration_sec" in payload:
        new_dur = max(15, min(600, int(payload["clip_duration_sec"])))
        engine.clip_duration_sec = new_dur
        logger.info(f"🎯 [Server] Duración objetivo de clip configurada a {new_dur}s ({new_dur/60:.1f} min)")

    if "video_quality" in payload:
        new_q = str(payload["video_quality"])
        if engine.is_active and new_q != old_quality:
            logger.info(f"ℹ️ [Server] Calidad de video cambiada a {new_q} (activo). Aplicará al reiniciar stream y de inmediato en renders 9:16.")
            ws_event_broadcaster({
                "type": "notification",
                "data": {
                    "message": f"ℹ️ Calidad de video cambiada a {new_q}. Aplicará al reiniciar el directo y de inmediato para los nuevos renders 9:16."
                }
            })
        elif not engine.is_active:
            engine.video_quality = new_q
            logger.info(f"ℹ️ [Server] Calidad de video por defecto fijada a {new_q}")

    return {"status": "ok", "config": updated}


@app.post("/api/settings/logo")
async def upload_logo_endpoint(file: UploadFile = File(...)):
    """Sube el archivo logo.png a assets/logo.png para overlay de marca de agua."""
    ASSETS_DIR.mkdir(parents=True, exist_ok=True)
    logo_path = ASSETS_DIR / "logo.png"
    content = await file.read()
    with open(logo_path, "wb") as f:
        f.write(content)
    # Actualizar config
    save_config({"watermark_type": "logo"})
    return {"status": "ok", "logo_url": "/assets/logo.png", "size_bytes": len(content)}


@app.post("/api/stop")
@app.post("/api/radar/stop")
async def stop_process():
    await asyncio.to_thread(engine.stop)
    return {"status": "ok", "message": "Procesos detenidos y cola 9:16 vaciada"}


@app.post("/api/clear_clips")
async def clear_clips_endpoint():
    """Borra todos los clips brutos (.mp4 y .json) de inbox_brutos/."""
    count = 0
    try:
        for p in INBOX_DIR.glob("*"):
            if p.is_file() and p.suffix.lower() in [".mp4", ".json", ".wav", ".ts"]:
                p.unlink()
                count += 1
        return {"status": "ok", "deleted_files": count, "message": f"{count} archivos eliminados de inbox_brutos"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error vaciando inbox_brutos: {e}")


@app.post("/api/clear_all")
async def clear_all_endpoint():
    """Borra todos los clips brutos y todos los shorts 9:16 (.mp4, .json, .ass)."""
    count_clips = 0
    count_shorts = 0
    try:
        for p in INBOX_DIR.glob("*"):
            if p.is_file() and p.suffix.lower() in [".mp4", ".json", ".wav", ".ts"]:
                p.unlink()
                count_clips += 1
        for p in CLIPS_VERTICALES.glob("*"):
            if p.is_file() and p.suffix.lower() in [".mp4", ".json", ".ass"]:
                p.unlink()
                count_shorts += 1
        return {
            "status": "ok",
            "deleted_clips": count_clips,
            "deleted_shorts": count_shorts,
            "message": f"Biblioteca vaciada por completo ({count_clips} brutos, {count_shorts} shorts eliminados)"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error vaciando biblioteca: {e}")


@app.post("/api/settings/threshold")
async def set_threshold(req: ThresholdRequest):
    engine.set_threshold(req.threshold)
    return {"status": "ok", "threshold": engine.threshold}


@app.post("/api/telemetry")
async def post_telemetry(payload: Dict[str, Any]):
    """Recibe telemetría de subtítulos y audio desde la extensión de Chrome vía HTTP fetch."""
    # 1. Procesar subtítulos
    subs = payload.get("subtitles_recent") or payload.get("subtitles") or []
    if isinstance(subs, list):
        for s in subs:
            text = s.get("text") if isinstance(s, dict) else str(s)
            p_time = s.get("time") if isinstance(s, dict) else payload.get("playback_current_time", 0.0)
            peak = s.get("peak") if isinstance(s, dict) else payload.get("audio_metrics", {}).get("peak", 0.0)
            if text:
                engine._on_sensor_event({
                    "type": "caption",
                    "text": text,
                    "player_time": float(p_time or 0.0),
                    "peak": float(peak or 0.0)
                })
    elif "caption" in payload or "text" in payload:
        text = payload.get("caption") or payload.get("text")
        if text:
            engine._on_sensor_event({
                "type": "caption",
                "text": text,
                "player_time": float(payload.get("player_time") or payload.get("playback_current_time") or 0.0),
                "peak": float(payload.get("peak") or payload.get("audio_metrics", {}).get("peak") or 0.0)
            })

    # 2. Procesar audio peak y tiempo
    audio_metrics = payload.get("audio_metrics", {})
    peak = float(payload.get("peak") or audio_metrics.get("peak") or audio_metrics.get("peak_volume") or 0.0)
    p_time = float(payload.get("player_time") or payload.get("playback_current_time") or 0.0)
    engine._on_sensor_event({
        "type": "heartbeat",
        "player_time": p_time,
        "peak": peak
    })
    return {"status": "ok", "delivered": True}


@app.websocket("/ws/telemetry")
async def ws_telemetry(websocket: WebSocket):
    """Canal WebSocket bidireccional dedicado para la extensión de Chrome."""
    await websocket.accept()
    try:
        while True:
            raw = await websocket.receive_text()
            try:
                data = json.loads(raw)
                await post_telemetry(data)
            except Exception:
                pass
    except (WebSocketDisconnect, ConnectionResetError):
        pass
    except Exception as e:
        winerror = getattr(e, "winerror", None)
        errno = getattr(e, "errno", None)
        if winerror in (10054, 10038) or errno in (10054, 10038):
            pass


@app.get("/api/clips")
async def get_clips(response: Response):
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate"
    clips = await asyncio.to_thread(engine.list_clips)
    return {"clips": clips}


def _make_gallery_thumbnail(video_path: Path, output_path: Path) -> bool:
    """Create one small, cached gallery poster without decoding the full video in the browser."""
    temp_path = output_path.with_name(f".{output_path.stem}.{uuid.uuid4().hex}.tmp.jpg")
    try:
        result = subprocess.run(
            [
                get_ffmpeg_cmd(), "-nostdin", "-hide_banner", "-loglevel", "error",
                "-threads", "1", "-ss", "0.5", "-i", str(video_path),
                "-map", "0:v:0", "-frames:v", "1", "-vf", "scale=640:-2",
                "-q:v", "5", "-y", str(temp_path),
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=15,
            check=False,
            **get_subprocess_flags(low_priority=True),
        )
        if result.returncode != 0 or not temp_path.is_file() or temp_path.stat().st_size == 0:
            return False
        os.replace(temp_path, output_path)
        return True
    except (OSError, subprocess.SubprocessError) as exc:
        logger.debug("No se pudo crear miniatura de %s: %s", video_path.name, exc)
        return False
    finally:
        try:
            temp_path.unlink(missing_ok=True)
        except OSError:
            pass


def _ensure_gallery_thumbnail(video_path: Path, output_path: Path, source_mtime_ns: int) -> bool:
    with _thumbnail_semaphore:
        try:
            if output_path.is_file() and output_path.stat().st_mtime_ns >= source_mtime_ns:
                return True
        except OSError:
            pass
        return _make_gallery_thumbnail(video_path, output_path)


async def _serve_gallery_thumbnail(source_dir: Path, filename: str):
    # Only allow a single filename within the expected gallery folder.
    safe_name = Path(filename).name
    if safe_name != filename or Path(safe_name).suffix.lower() not in {".mp4", ".mkv", ".mov", ".webm"}:
        raise HTTPException(status_code=404, detail="Video no encontrado")

    root = source_dir.resolve()
    video_path = (root / safe_name).resolve()
    if video_path.parent != root or not video_path.is_file():
        raise HTTPException(status_code=404, detail="Video no encontrado")

    try:
        source_stat = video_path.stat()
        cache_key = hashlib.sha256(f"{root.name}/{safe_name}".encode("utf-8")).hexdigest()[:20]
        thumbnail_path = THUMBNAIL_CACHE_DIR / f"{cache_key}.jpg"
        stale = not thumbnail_path.is_file() or thumbnail_path.stat().st_mtime_ns < source_stat.st_mtime_ns
        if stale:
            THUMBNAIL_CACHE_DIR.mkdir(parents=True, exist_ok=True)
            if not await asyncio.to_thread(_ensure_gallery_thumbnail, video_path, thumbnail_path, source_stat.st_mtime_ns):
                raise HTTPException(status_code=422, detail="No se pudo crear la vista previa")
    except HTTPException:
        raise
    except OSError as exc:
        logger.warning("Error preparando miniatura de %s: %s", safe_name, exc)
        raise HTTPException(status_code=500, detail="Error preparando la vista previa")

    return FileResponse(
        thumbnail_path,
        media_type="image/jpeg",
        headers={"Cache-Control": "public, max-age=300"},
    )


@app.get("/api/thumbnails/clips/{filename}")
async def get_clip_thumbnail(filename: str):
    return await _serve_gallery_thumbnail(INBOX_DIR, filename)


@app.get("/api/thumbnails/shorts/{filename}")
async def get_short_thumbnail(filename: str):
    return await _serve_gallery_thumbnail(CLIPS_VERTICALES, filename)


@app.api_route("/clips/{filename}", methods=["GET", "HEAD"])
async def serve_clip(filename: str):
    file_path = INBOX_DIR / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Archivo no encontrado")
    return FileResponse(file_path)


@app.post("/api/test/trigger_clip")
async def test_trigger():
    """Botón de prueba para disparar un empaquetado de clip inmediatamente."""
    if not engine.is_active:
        raise HTTPException(status_code=400, detail="El radar no está activo. Inicia el radar primero.")
    
    dummy_eval = {
        "score": 9.5,
        "status": "harvest",
        "peak_level": 0.99,
        "rms_energy": 0.085,
        "dynamic_variance": 0.0015,
        "has_subtitles": True,
        "reason": "Prueba manual de empaquetado inmediato (Test Trigger)",
        "protagonistas": ["PruebaManual"],
        "titulo_gancho": "¡PRUEBA DE REWIND INMEDIATO! Extracción 1080p exitosa",
        "texto_completo": "Esta es una extracción manual provocada por el operador para verificar el anillo de retención en RAM y la velocidad de empaquetado con ffmpeg.",
        "palabras": 22,
        "max_peak": 0.99
    }
    clip_res = engine.extractor.extract_clip(dummy_eval, engine.ring_buffer, engine.current_url)
    if not clip_res:
        raise HTTPException(status_code=500, detail="No se pudo extraer clip. ¿Hay fragmentos en el buffer de memoria?")
    
    ws_event_broadcaster({"type": "new_clip_extracted", "data": clip_res})
    return {"status": "ok", "clip": clip_res}


@app.get("/api/settings/auto_render")
async def get_auto_render_settings():
    return {
        "auto_render_916": engine.auto_render_916,
        "min_render_score": engine.min_render_score,
        "burn_subtitles": getattr(engine, "burn_subtitles", True),
        "auto_titles": getattr(engine, "auto_titles", True),
        "queue_status": stage2_queue.get_status()
    }


@app.post("/api/settings/auto_render")
async def set_auto_render_settings(req: AutoRenderSettingsRequest):
    engine.auto_render_916 = req.auto_render_916
    engine.min_render_score = req.min_render_score
    vod_engine.auto_render_916 = req.auto_render_916
    vod_engine.min_render_score = req.min_render_score
    if req.burn_subtitles is not None:
        engine.burn_subtitles = req.burn_subtitles
        vod_engine.burn_subtitles = req.burn_subtitles
    if req.auto_titles is not None:
        engine.auto_titles = req.auto_titles
        vod_engine.auto_titles = req.auto_titles
    save_config({
        "burn_subtitles": getattr(engine, "burn_subtitles", True),
        "auto_titles": getattr(engine, "auto_titles", True)
    })
    ws_event_broadcaster({
        "type": "settings_updated",
        "data": {
            "auto_render_916": engine.auto_render_916,
            "min_render_score": engine.min_render_score,
            "burn_subtitles": getattr(engine, "burn_subtitles", True),
            "auto_titles": getattr(engine, "auto_titles", True)
        }
    })
    return {
        "status": "ok",
        "auto_render_916": engine.auto_render_916,
        "min_render_score": engine.min_render_score,
        "burn_subtitles": getattr(engine, "burn_subtitles", True),
        "auto_titles": getattr(engine, "auto_titles", True)
    }


@app.post("/api/stage2/render")
async def render_short_916(req: Stage2RenderRequest):
    """Encola manualmente un clip para su encuadre y subtitulado 9:16."""
    active, msg, _ = is_system_activated()
    if not active:
        raise HTTPException(status_code=403, detail="Licencia no activada. Ingresa la clave firmada para esta PC.")
    try:
        # Feedback silencioso ViralBrain: aceptación implícita (label = 1.0)
        try:
            raw_id = Path(req.clip_id).stem
            json_path = INBOX_DIR / f"{raw_id}.json"
            if json_path.exists():
                with open(json_path, "r", encoding="utf-8") as jf:
                    meta = json.load(jf)
                from viral_brain import get_viral_brain
                acoustics = {
                    "peak_level": meta.get("peak_level", 0.0),
                    "rms_energy": meta.get("rms_energy", 0.0),
                    "dynamic_variance": meta.get("dynamic_variance", 0.0),
                    "spectral_flux": meta.get("spectral_flux", 0.0)
                }
                text = meta.get("transcripcion_base", "")
                dur = float(meta.get("duracion_segundos", 60.0))
                get_viral_brain().learn(acoustics, text, label=1.0, duration_sec=dur)
        except Exception:
            pass

        job = stage2_queue.enqueue(
            clip_id=req.clip_id,
            framing_mode=req.framing_mode,
            custom_title=req.custom_title,
            start_sec=req.start_sec,
            end_sec=req.end_sec,
            video_quality=req.video_quality,
            crop_offset_x=req.crop_offset_x,
            crop_offset_y=req.crop_offset_y,
            zoom=req.zoom,
            subtitle_base_color=req.subtitle_base_color,
            subtitle_highlight_color=req.subtitle_highlight_color,
            subtitle_font_size=req.subtitle_font_size,
            subtitle_margin_v=req.subtitle_margin_v,
            overlay_image=req.overlay_image,
            overlay_x=req.overlay_x,
            overlay_y=req.overlay_y,
            overlay_scale=req.overlay_scale,
            overlay_opacity=req.overlay_opacity,
            overlays=req.overlays,
            gaming_cam_offset_x=req.gaming_cam_offset_x,
            gaming_cam_offset_y=req.gaming_cam_offset_y,
            gaming_cam_zoom=req.gaming_cam_zoom,
            kept_segments=req.kept_segments,
            fade_out=req.fade_out,
            burn_subtitles=req.burn_subtitles,
            auto_titles=req.auto_titles
        )
        return {"status": "ok", "job": job}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/api/shorts")
async def get_shorts(response: Response):
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate"
    """Retorna lista de shorts 9:16 generados con metadatos."""
    def _list_shorts():
        shorts = []
        if CLIPS_VERTICALES.exists():
            for jf in CLIPS_VERTICALES.glob("short_*.json"):
                try:
                    with open(jf, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        mp4_file = jf.with_suffix(".mp4")
                        if mp4_file.exists():
                            data["file_size_mb"] = round(mp4_file.stat().st_size / (1024 * 1024), 2)
                            data["video_url"] = f"/shorts/{mp4_file.name}"
                            shorts.append(data)
                except Exception:
                    pass
        shorts.sort(key=lambda x: x.get("rendered_at", ""), reverse=True)
        return shorts

    shorts = await asyncio.to_thread(_list_shorts)
    return {"shorts": shorts, "queue_status": stage2_queue.get_status()}

@app.api_route("/shorts/{filename}", methods=["GET", "HEAD"])
async def serve_short(filename: str):
    file_path = CLIPS_VERTICALES / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Short vertical no encontrado")
    return FileResponse(file_path)


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    connected_websockets.add(websocket)
    try:
        # Enviar estado actual al conectarse
        init_st = await asyncio.to_thread(engine.get_status)
        init_st["queue_status"] = stage2_queue.get_status()
        try:
            from viral_brain import get_viral_brain
            brain = get_viral_brain()
            init_st["viral_brain"] = await asyncio.to_thread(brain.get_status)
        except Exception:
            pass
        await websocket.send_text(json.dumps({"type": "init_state", "data": init_st}, ensure_ascii=False))
        while True:
            # Mantener conexión viva y procesar pings
            await websocket.receive_text()
    except (WebSocketDisconnect, ConnectionResetError):
        pass
    except Exception as e:
        winerror = getattr(e, "winerror", None)
        errno = getattr(e, "errno", None)
        if winerror in (10054, 10038) or errno in (10054, 10038):
            pass
    finally:
        connected_websockets.discard(websocket)


# Montar archivos estáticos adicionales y assets de marca
app.mount("/assets", StaticFiles(directory=str(ASSETS_DIR)), name="assets")
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


def cleanup_temp_resources():
    try:
        clean_dir_patterns(get_shm_dir(), ["vod_audio.wav", "sub_*.ass", "preview_monitor.*", "temp_manual_*.wav", "temp_cand.wav"])
    except Exception:
        pass

atexit.register(cleanup_temp_resources)


# Silenciar ConnectionResetError [WinError 10054] en Windows asyncio ProactorEventLoop
# (ocurre cuando el navegador cancela peticiones 206 Partial Content al hacer seek en video)
if IS_WIN:
    _original_exception_handler = None

    def _win_exception_handler(loop, context):
        exc = context.get("exception")
        if isinstance(exc, ConnectionResetError):
            # WinError 10054: "Se ha forzado la interrupción de una conexión existente por el host remoto"
            # Esto es inofensivo: el navegador cerró la conexión durante el streaming de un archivo de video.
            return
        if isinstance(exc, OSError) and getattr(exc, "winerror", None) == 10054:
            return
        # Para cualquier otra excepción, usar el handler original o el default
        if _original_exception_handler:
            _original_exception_handler(loop, context)
        else:
            loop.default_exception_handler(context)

    @app.on_event("startup")
    async def _install_win_error_handler():
        global _original_exception_handler, MAIN_EVENT_LOOP
        loop = asyncio.get_running_loop()
        MAIN_EVENT_LOOP = loop
        _original_exception_handler = getattr(loop, '_exception_handler', None)
        loop.set_exception_handler(_win_exception_handler)
else:
    @app.on_event("startup")
    async def _init_main_loop():
        global MAIN_EVENT_LOOP
        MAIN_EVENT_LOOP = asyncio.get_running_loop()


if __name__ == "__main__":
    bind_host = "0.0.0.0" if os.environ.get("ANYELO_CLIP_LAN") == "1" else "127.0.0.1"
    uvicorn.run("server:app", host=bind_host, port=8765, log_level="info")
