"""
sensor_cdp.py - Sensor de navegador vía CDP / Playwright (Ojos y Oídos).
Monitorea YouTube Live en calidad 144p con Subtítulos Automáticos (CC) activados,
extrayendo en tiempo real el texto del diálogo, segundo actual del reproductor y picos de audio.
CPU < 2%.
"""

import asyncio
import logging
import threading
import time
from typing import Callable, Optional, Dict, Any
from playwright.async_api import async_playwright, Browser, BrowserContext, Page

logger = logging.getLogger("sensor_cdp")

INJECTED_JS = """
(() => {
    if (window._liveRadarActive) return;
    window._liveRadarActive = true;

    let lastSentText = "";
    let audioPeakCurrent = 0.0;

    // 1. Configurar AudioContext para medir picos de volumen en tiempo real
    const setupAudio = () => {
        try {
            const video = document.querySelector('video');
            if (video) {
                if (video.paused) video.play().catch(() => {});
                video.muted = false;
                video.volume = 1.0;
                
                if (!window._audioMeterInitialized) {
                    const AudioCtx = window.AudioContext || window.webkitAudioContext;
                    const ctx = new AudioCtx();
                    if (ctx.state === 'suspended') ctx.resume();
                    const src = ctx.createMediaElementSource(video);
                    const analyser = ctx.createAnalyser();
                    analyser.fftSize = 128;
                    src.connect(analyser);
                    analyser.connect(ctx.destination);
                    
                    const data = new Uint8Array(analyser.frequencyBinCount);
                    setInterval(() => {
                        analyser.getByteFrequencyData(data);
                        let maxVal = 0;
                        for (let i = 0; i < data.length; i++) {
                            if (data[i] > maxVal) maxVal = data[i];
                        }
                        audioPeakCurrent = maxVal / 255.0;
                    }, 100);
                    window._audioMeterInitialized = true;
                }
            }
        } catch (e) {
            // Si cross-origin bloquea el analyzer, usar estimación por volumen del elemento
            console.log('AudioContext fallback:', e);
        }
    };

    // 2. Configurar Reproductor: 144p ('tiny') y Subtítulos CC activados
    const configurePlayer = () => {
        const player = document.getElementById('movie_player');
        if (player) {
            // Forzar 144p para consumo nulo de GPU
            if (typeof player.setPlaybackQualityRange === 'function') {
                player.setPlaybackQualityRange('tiny', 'tiny');
            }
            if (typeof player.setPlaybackQuality === 'function') {
                player.setPlaybackQuality('tiny');
            }
            
            // Forzar activación de Subtítulos Automáticos (CC)
            const ccBtn = document.querySelector('.ytp-subtitles-button');
            if (ccBtn && ccBtn.getAttribute('aria-pressed') !== 'true') {
                ccBtn.click();
            }
            if (typeof player.toggleSubtitlesOn === 'function' && typeof player.isSubtitlesOn === 'function') {
                if (!player.isSubtitlesOn()) {
                    player.toggleSubtitlesOn();
                }
            }
        }
    };

    // 3. Extractor de subtítulos en vivo
    const checkCaptions = () => {
        const segments = document.querySelectorAll('.ytp-caption-segment');
        if (segments && segments.length > 0) {
            const currentText = Array.from(segments).map(s => s.innerText.trim()).join(' ').trim();
            if (currentText && currentText !== lastSentText) {
                lastSentText = currentText;
                const player = document.getElementById('movie_player');
                const pTime = player && typeof player.getCurrentTime === 'function' ? player.getCurrentTime() : (document.querySelector('video')?.currentTime || 0);
                
                if (window.onLiveSensorEvent) {
                    window.onLiveSensorEvent({
                        type: 'caption',
                        text: currentText,
                        player_time: pTime,
                        peak: audioPeakCurrent,
                        wall_time: Date.now()
                    });
                }
            }
        }
    };

    // 4. Heartbeat periódico para estado y barra de audio en vivo
    setInterval(() => {
        setupAudio();
        configurePlayer();
        checkCaptions();
        
        const player = document.getElementById('movie_player');
        const pTime = player && typeof player.getCurrentTime === 'function' ? player.getCurrentTime() : (document.querySelector('video')?.currentTime || 0);
        
        if (window.onLiveSensorEvent) {
            window.onLiveSensorEvent({
                type: 'heartbeat',
                player_time: pTime,
                peak: audioPeakCurrent,
                wall_time: Date.now()
            });
        }
    }, 500);

    // MutationObserver para atrapar cambios de subtítulos al instante
    const observer = new MutationObserver(() => {
        checkCaptions();
    });
    const container = document.querySelector('.ytp-caption-window-container') || document.body;
    observer.observe(container, { childList: true, subtree: true, characterData: true });
})();
"""


class BrowserSensor:
    def __init__(self, cdp_url: str = "http://127.0.0.1:9222"):
        self.cdp_url = cdp_url
        self.loop: Optional[asyncio.AbstractEventLoop] = None
        self.thread: Optional[threading.Thread] = None
        self.is_running = False
        self.current_url: Optional[str] = None
        self.browser: Optional[Browser] = None
        self.context: Optional[BrowserContext] = None
        self.page: Optional[Page] = None
        self.callback: Optional[Callable[[Dict[str, Any]], None]] = None

    @staticmethod
    def _get_available_ram_mb_win() -> float:
        """
        Consulta la RAM fisica disponible en Windows usando ctypes (GlobalMemoryStatusEx).
        PARCHE RAM v2.2: Cero librerias nuevas, solo ctypes del stdlib.
        Retorna MB libres, o -1.0 si no es Windows o falla.
        """
        import os
        if os.name != "nt":
            return -1.0
        try:
            import ctypes
            import ctypes.wintypes

            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.wintypes.DWORD),
                    ("dwMemoryLoad", ctypes.wintypes.DWORD),
                    ("ullTotalPhys", ctypes.c_uint64),
                    ("ullAvailPhys", ctypes.c_uint64),
                    ("ullTotalPageFile", ctypes.c_uint64),
                    ("ullAvailPageFile", ctypes.c_uint64),
                    ("ullTotalVirtual", ctypes.c_uint64),
                    ("ullAvailVirtual", ctypes.c_uint64),
                    ("ullAvailExtendedVirtual", ctypes.c_uint64),
                ]

            stat = MEMORYSTATUSEX()
            stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat)):
                return stat.ullAvailPhys / (1024 * 1024)
        except Exception as e:
            logger.debug(f"Error consultando RAM disponible en Windows: {e}")
        return -1.0

    def start(self, youtube_url: str, callback: Callable[[Dict[str, Any]], None]):
        """Inicia el sensor de navegador en un hilo asyncio dedicado."""
        self.stop()

        # PARCHE RAM v2.2: En Windows, omitir Sensor CDP si RAM libre < 1800 MB
        import os
        if os.name == "nt":
            ram_mb = self._get_available_ram_mb_win()
            if 0 < ram_mb < 1800:
                logger.info(
                    f"[INFO] Sensor CDP omitido por ahorro de RAM ({ram_mb:.0f} MB libres < 1800 MB); "
                    f"captura de video y audio activa al 100%."
                )
                return

        self.current_url = youtube_url
        self.callback = callback
        self.is_running = True
        
        self.thread = threading.Thread(target=self._run_loop, daemon=True)
        self.thread.start()
        logger.info(f"Sensor CDP iniciado para {youtube_url}")

    def _run_loop(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        try:
            self.loop.run_until_complete(self._browser_task())
        except Exception as e:
            logger.error(f"Error en bucle del sensor: {e}")
        finally:
            try:
                # Cancelar tareas pendientes antes de cerrar el loop
                pending = [t for t in asyncio.all_tasks(self.loop) if not t.done()]
                for task in pending:
                    task.cancel()
                if pending and not self.loop.is_closed():
                    self.loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
            except Exception:
                pass
            try:
                if not self.loop.is_closed():
                    self.loop.close()
            except Exception:
                pass

    @staticmethod
    def _detect_platform_name(url: str) -> str:
        u = url.lower()
        if "kick.com" in u:
            return "Kick"
        if "twitch.tv" in u:
            return "Twitch"
        if "tiktok.com" in u:
            return "TikTok"
        if "youtube.com" in u or "youtu.be" in u:
            return "YouTube"
        return "Web"

    async def _browser_task(self):
        async with async_playwright() as p:
            # 1. Intentar conectar a Chrome existente vía CDP en 9222
            connected_cdp = False
            try:
                logger.info(f"Probando conexión a CDP en {self.cdp_url}...")
                self.browser = await p.chromium.connect_over_cdp(self.cdp_url, timeout=3000)
                connected_cdp = True
                logger.info("✅ Conectado exitosamente al Chrome del sistema vía CDP.")
                # Usar el contexto predeterminado o crear una página
                contexts = self.browser.contexts
                self.context = contexts[0] if contexts else await self.browser.new_context()
                self.page = await self.context.new_page()
            except Exception as e:
                logger.info(f"CDP local en {self.cdp_url} no disponible ({e}). Intentando iniciar navegador ligero...")
                # 2. Si no hay CDP abierto, intentar Chrome -> Edge -> Chromium genérico
                launch_args = [
                    "--autoplay-policy=no-user-gesture-required",
                    "--disable-gpu",
                    "--window-size=800,600",
                    "--mute-audio=false",
                    "--no-sandbox"
                ]
                launched = False
                for ch in ["chrome", "msedge", None]:
                    try:
                        kwargs = {"headless": True, "args": launch_args}
                        if ch:
                            kwargs["channel"] = ch
                        self.browser = await p.chromium.launch(**kwargs)
                        launched = True
                        logger.info(f"✅ Navegador ligero iniciado exitosamente ({ch or 'chromium genérico'}).")
                        break
                    except Exception as e_ch:
                        logger.debug(f"Canal '{ch}' no disponible: {e_ch}")

                if not launched or not self.browser:
                    logger.info("ℹ️ [Sensor CDP] No hay navegadores compatibles instalados (Chrome/Edge/Chromium). Fallback silencioso activo: el radar continuará 100% con ASR nativo sin interrupción.")
                    return

                try:
                    self.context = await self.browser.new_context(
                        viewport={"width": 800, "height": 600},
                        user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
                    )
                    self.page = await self.context.new_page()
                except Exception as e_ctx:
                    logger.warning(f"Error creando contexto de navegador: {e_ctx}")
                    return

            # Exponer callback bidireccional desde JavaScript a Python
            async def js_event_handler(source, data):
                if self.callback and self.is_running:
                    self.callback(data)

            await self.page.expose_binding("onLiveSensorEvent", js_event_handler)

            platform_name = self._detect_platform_name(self.current_url)
            target_url = self.current_url.strip()
            if not target_url.startswith(("http://", "https://")):
                target_url = "https://" + target_url

            # Navegar a la URL del directo
            logger.info(f"Cargando directo de {platform_name}: {target_url}")
            try:
                await self.page.goto(target_url, timeout=35000, wait_until="commit")
                await self.page.wait_for_selector("video", timeout=15000)
            except Exception as e:
                err_msg = str(e)
                if "Protocol error" in err_msg or "Cannot navigate" in err_msg:
                    logger.debug(f"Aviso de navegación ({platform_name}): {err_msg[:80]}")
                else:
                    logger.warning(f"Goto terminó con advertencia ({platform_name}): {e}")

            # Esperar a que el reproductor esté disponible e inyectar el monitor
            await asyncio.sleep(3)
            try:
                await self.page.evaluate(INJECTED_JS)
                logger.info(f"Radar de subtítulos y audio inyectado en el reproductor de {platform_name}.")
            except Exception as e:
                err_msg = str(e)
                if "Protocol error" in err_msg or "Execution context was destroyed" in err_msg:
                    logger.debug(f"Aviso inyectando monitor ({platform_name}): {err_msg[:80]}")
                else:
                    logger.warning(f"Aviso inyectando monitor ({platform_name}): {e}")

            # Mantener la página viva mientras is_running sea True
            while self.is_running:
                # Comprobar periódicamente que el inyector siga activo
                try:
                    await self.page.evaluate("if (!window._liveRadarActive) { " + INJECTED_JS + " }")
                except Exception:
                    pass
                await asyncio.sleep(5)

            if self.browser:
                try:
                    await self.page.close()
                    if not connected_cdp:
                        await self.browser.close()
                except Exception:
                    pass

    def stop(self):
        """Detiene el sensor y libera el navegador."""
        self.is_running = False
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=3)
        self.thread = None
        logger.info("Sensor CDP detenido.")


if __name__ == "__main__":
    def print_event(e):
        if e.get("type") == "caption":
            print(f"[SUB] {e.get('text')} (peak: {e.get('peak'):.2f}, time: {e.get('player_time')})")

    sensor = BrowserSensor()
    # Test con directo activo
    sensor.start("https://www.youtube.com/watch?v=Tw6B39CbaEc", print_event)
    try:
        time.sleep(15)
    finally:
        sensor.stop()
