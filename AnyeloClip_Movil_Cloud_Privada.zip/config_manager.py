"""
config_manager.py - Gestor de configuración persistente para Anyelo Clip.
Almacena vocabulario personalizado de jerga, marcas de agua, logo y preferencias visuales en config.json.
"""

import json
import logging
import os
import threading
from pathlib import Path
from typing import Dict, Any

logger = logging.getLogger("config_manager")

BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "config.json"
_CONFIG_LOCK = threading.RLock()
ASSETS_DIR = BASE_DIR / "assets"
ASSETS_DIR.mkdir(parents=True, exist_ok=True)

DEFAULT_CONFIG: Dict[str, Any] = {
    "vocabulary": "Santiago Matías, Alofoke, Capricornio TV, Dotol Nastra, Vitaly, El Pachá",
    "video_quality": "1080p",
    "clip_duration_sec": 60,
    "watermark_type": "text",
    "watermark_text": "@TuCanal",
    "watermark_position": "top_right",
    "watermark_opacity": 0.7,
    "show_progress_bar": True,
    "progress_bar_color": "#00D7FF",
    "banner_color": "#FFFFFF",
    "burn_subtitles": True,
    "auto_titles": True
}


def load_config() -> Dict[str, Any]:
    """Carga config.json combinándolo con los valores por defecto."""
    if not CONFIG_PATH.exists():
        save_config(DEFAULT_CONFIG)
        return DEFAULT_CONFIG.copy()

    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
            merged = DEFAULT_CONFIG.copy()
            merged.update(data)
            return merged
    except Exception as e:
        logger.warning(f"Error leyendo config.json ({e}), usando defaults.")
        return DEFAULT_CONFIG.copy()


def save_config(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Actualiza la configuración con bloqueo y reemplazo atómico del archivo."""
    with _CONFIG_LOCK:
        current = load_config() if CONFIG_PATH.exists() else DEFAULT_CONFIG.copy()
        current.update(cfg)
        temp_path = CONFIG_PATH.with_name(
            f"{CONFIG_PATH.name}.{os.getpid()}.{threading.get_ident()}.tmp"
        )
        try:
            with open(temp_path, "w", encoding="utf-8") as f:
                json.dump(current, f, indent=2, ensure_ascii=False)
                f.flush()
                os.fsync(f.fileno())
            os.replace(temp_path, CONFIG_PATH)
        except Exception as e:
            logger.error(f"Error guardando config.json de forma atómica: {e}")
            try:
                temp_path.unlink(missing_ok=True)
            except Exception:
                pass
        return current