"""
stage2_worker.py - Cola secuencial en segundo plano para renderizado 9:16 (Etapa 2).
Ejecuta con baja prioridad CPU (os.nice(10)) procesando 1 video a la vez para no
interferir con el radar en vivo. Usa exclusivamente FFmpeg + .ass (Cero MoviePy).
"""

import os
import json
import time
import queue
import logging
import threading
import subprocess
from collections import OrderedDict
from datetime import datetime
from functools import wraps
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple

from ass_generator import generate_ass_subtitles
from reframer import get_video_info, detect_faces_in_video, build_reframe_filtergraph
from config_manager import load_config, ASSETS_DIR
from os_compat import (
    get_shm_dir, get_shm_path, get_ffmpeg_cmd, get_ffprobe_cmd,
    set_low_priority, get_subprocess_flags, escape_ass_path,
    kill_process_tree, detect_best_h264_encoder
)

logger = logging.getLogger("stage2_worker")
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

BASE_DIR = Path(__file__).resolve().parent
INBOX_BRUTOS = BASE_DIR / "inbox_brutos"
CLIPS_VERTICALES = BASE_DIR / "clips_verticales"

# Cadena de Audio Estudio sin loudnorm (evita resampleo 192kHz/deriva) con sincronización estricta A/V
STUDIO_AUDIO_FILTER = "aresample=async=1:min_hard_comp=0.100000:first_pts=0,highpass=f=80,equalizer=f=3000:width_type=h:width=1500:g=2.5"


def is_valid_image_file(img_path: Optional[Path]) -> bool:
    """Verifica que un archivo de imagen exista, pese > 64 bytes y tenga cabecera PNG/JPEG/WEBP válida."""
    if not img_path:
        return False
    try:
        p = Path(img_path)
        if not p.is_file() or p.stat().st_size <= 64:
            return False
        with open(p, "rb") as f:
            head = f.read(16)
        if head.startswith(b"\x89PNG\r\n\x1a\n"):
            return True
        if head.startswith(b"\xff\xd8\xff"):
            return True
        if len(head) >= 12 and head[:4] == b"RIFF" and head[8:12] == b"WEBP":
            return True
        return False
    except Exception:
        return False


def probe_stream_sync(video_path: Path) -> Dict[str, Any]:
    """
    Mide start_time de video y audio y avg_frame_rate con ffprobe para sincronizar por origen común.
    """
    default_res = {
        "has_audio": False,
        "v_start": 0.0,
        "a_start": 0.0,
        "fps": 30.0,
        "lead_trim": 0.0,
    }
    try:
        ffprobe_bin = get_ffprobe_cmd()
        sub_flags = get_subprocess_flags(no_window=True)
        res = subprocess.run(
            [
                ffprobe_bin, "-v", "error",
                "-show_entries", "stream=codec_type,start_time,avg_frame_rate",
                "-of", "json",
                str(Path(video_path).resolve())
            ],
            capture_output=True, text=True, timeout=10.0, **sub_flags
        )
        if res.returncode != 0 or not res.stdout:
            return default_res

        data = json.loads(res.stdout)
        streams = data.get("streams", [])
        v_stream = next((s for s in streams if s.get("codec_type") == "video"), None)
        a_stream = next((s for s in streams if s.get("codec_type") == "audio"), None)

        def _parse_float(val: Any, fallback: float = 0.0) -> float:
            try:
                if val is None or str(val).strip().upper() in ("", "N/A", "NAN"):
                    return fallback
                return float(val)
            except Exception:
                return fallback

        has_audio = a_stream is not None
        v_start = _parse_float(v_stream.get("start_time") if v_stream else None, 0.0)
        a_start = _parse_float(a_stream.get("start_time") if a_stream else None, 0.0)

        fps = 30.0
        if v_stream:
            afr = str(v_stream.get("avg_frame_rate") or "").strip()
            if "/" in afr:
                num_s, den_s = afr.split("/", 1)
                num_v, den_v = _parse_float(num_s, 0.0), _parse_float(den_s, 0.0)
                if num_v > 0.0 and den_v > 0.0:
                    fps = min(60.0, max(24.0, round(num_v / den_v, 2)))
            elif afr:
                raw_fps = _parse_float(afr, 0.0)
                if raw_fps > 0.0:
                    fps = min(60.0, max(24.0, round(raw_fps, 2)))

        lead_trim = 0.0
        if has_audio:
            diff = abs(v_start - a_start)
            if 0.02 < diff < 4.0:
                lead_trim = round(diff + 0.04, 3)

        return {
            "has_audio": has_audio,
            "v_start": v_start,
            "a_start": a_start,
            "fps": fps,
            "lead_trim": lead_trim,
        }
    except Exception as e:
        logger.warning(f"Aviso en probe_stream_sync ({video_path}): {e}")
        return default_res


def _build_video_encoder_args(encoder: str, preset_val: str, crf_val: str) -> List[str]:
    """Construye los argumentos de codificación H.264 según el encoder hardware/CPU activo."""
    if encoder == "h264_nvenc":
        return ["-c:v", "h264_nvenc", "-preset", "p4", "-rc", "vbr", "-cq", crf_val, "-b:v", "0", "-pix_fmt", "yuv420p"]
    if encoder == "h264_amf":
        return ["-c:v", "h264_amf", "-usage", "transcoding", "-rc", "cqp", "-qp_i", crf_val, "-qp_p", crf_val, "-pix_fmt", "yuv420p"]
    if encoder == "h264_qsv":
        return ["-c:v", "h264_qsv", "-preset", "faster", "-global_quality", crf_val, "-pix_fmt", "nv12"]
    return ["-c:v", "libx264", "-preset", preset_val, "-crf", crf_val, "-pix_fmt", "yuv420p"]


def get_render_profile(video_quality: str) -> Tuple[int, int, str, str]:
    """
    Retorna (out_w, out_h, crf, preset) según video_quality:
    - '480p': 540x960, crf 24, veryfast
    - '720p': 720x1280, crf 22, veryfast
    - '1080p': 1080x1920, crf 20, fast
    - 'max': 1080x1920, crf 17, medium
    """
    vq = (video_quality or "1080p").lower()
    if vq == "480p":
        return (540, 960, "24", "veryfast")
    elif vq == "720p":
        return (720, 1280, "22", "veryfast")
    elif vq == "max":
        return (1080, 1920, "17", "medium")
    else:  # 1080p default
        return (1080, 1920, "20", "fast")


def _serialize_stage2_render(method):
    """Limita a un render 9:16 a la vez, incluso si Estudio y auto-render coinciden."""
    @wraps(method)
    def _wrapped(self, *args, **kwargs):
        with self.render_lock:
            return method(self, *args, **kwargs)
    return _wrapped


class Stage2Worker:
    def __init__(self, inbox_dir: Path = INBOX_BRUTOS, out_dir: Path = CLIPS_VERTICALES):
        self.inbox_dir = inbox_dir
        self.out_dir = out_dir
        self.out_dir.mkdir(parents=True, exist_ok=True)
        self.task_queue: queue.Queue = queue.Queue()
        self.is_running = True
        self.cancel_requested = False
        self.cancelled_job_ids = set()
        self.current_job: Optional[Dict[str, Any]] = None
        self.current_process: Optional[subprocess.Popen] = None
        self.proc_lock: threading.RLock = threading.RLock()
        self.render_lock: threading.RLock = threading.RLock()
        self.completed_jobs = OrderedDict()
        self.completed_jobs_limit = 100
        self.completed_job_count = 0
        self.completed_jobs_lock: threading.RLock = threading.RLock()
        self.callbacks = []

        self.worker_thread = threading.Thread(target=self._worker_loop, daemon=True)
        self.worker_thread.start()
        threading.Thread(target=detect_best_h264_encoder, daemon=True).start()
        logger.info("🎬 Stage2Worker (Cola Secuencial 9:16) iniciado.")

    def _remember_job(self, job: Dict[str, Any]):
        """Guarda solo los últimos 100 estados terminales para limitar memoria."""
        clip_id = job.get("clip_id")
        if not clip_id:
            return
        with self.completed_jobs_lock:
            self.completed_jobs[clip_id] = job
            self.completed_jobs.move_to_end(clip_id)
            if job.get("status") == "completed":
                self.completed_job_count += 1
            while len(self.completed_jobs) > self.completed_jobs_limit:
                self.completed_jobs.popitem(last=False)

    def register_callback(self, cb):
        """Registra callbacks para notificación de estado."""
        self.callbacks.append(cb)

    def _notify(self, event_type: str, data: Dict[str, Any]):
        for cb in self.callbacks:
            try:
                cb(event_type, data)
            except Exception as e:
                logger.error(f"Error en callback de stage2: {e}")

    def _broadcast(self, event_type_or_dict: Any, data: Optional[Dict[str, Any]] = None):
        """Notifica eventos a los callbacks registrados (soporta dict o tipo+data)."""
        if isinstance(event_type_or_dict, dict):
            evt_type = event_type_or_dict.get("type", "stage2_event")
            self._notify(evt_type, event_type_or_dict)
        else:
            self._notify(str(event_type_or_dict), data or {})

    def enqueue(
        self,
        clip_id: str,
        framing_mode: str = "AUTO",
        custom_title: Optional[str] = None,
        start_sec: float = 0.0,
        end_sec: Optional[float] = None,
        video_quality: Optional[str] = None,
        crop_offset_x: float = 0.0,
        crop_offset_y: float = 0.0,
        zoom: float = 1.0,
        subtitle_base_color: Optional[str] = None,
        subtitle_highlight_color: Optional[str] = None,
        subtitle_font_size: Optional[int] = None,
        subtitle_margin_v: Optional[int] = None,
        overlay_image: Optional[str] = None,
        overlay_x: float = 0.85,
        overlay_y: float = 0.10,
        overlay_scale: float = 0.20,
        overlay_opacity: float = 1.0,
        overlays: Optional[List[Dict[str, Any]]] = None,
        gaming_cam_offset_x: float = 0.0,
        gaming_cam_offset_y: float = 0.0,
        gaming_cam_zoom: float = 1.0,
        kept_segments: Optional[List[Dict[str, float]]] = None,
        fade_out: bool = False,
        session_id: Optional[int] = None,
        is_manual: bool = False,
        burn_subtitles: bool = True,
        auto_titles: bool = True,
        **kwargs
    ) -> Dict[str, Any]:
        """Encola un clip para su conversión vertical 9:16 con soporte de estilos y encuadre fino."""
        self.cancel_requested = False
        if clip_id in self.cancelled_job_ids:
            self.cancelled_job_ids.remove(clip_id)

        job = {
            "clip_id": clip_id,
            "framing_mode": framing_mode,
            "custom_title": custom_title,
            "start_sec": max(0.0, float(start_sec)),
            "end_sec": float(end_sec) if end_sec is not None else None,
            "video_quality": video_quality,
            "crop_offset_x": float(crop_offset_x),
            "crop_offset_y": float(crop_offset_y),
            "zoom": float(zoom),
            "subtitle_base_color": subtitle_base_color,
            "subtitle_highlight_color": subtitle_highlight_color,
            "subtitle_font_size": subtitle_font_size,
            "subtitle_margin_v": subtitle_margin_v,
            "overlay_image": overlay_image,
            "overlay_x": float(overlay_x),
            "overlay_y": float(overlay_y),
            "overlay_scale": float(overlay_scale),
            "overlay_opacity": float(overlay_opacity),
            "overlays": overlays,
            "gaming_cam_offset_x": float(gaming_cam_offset_x),
            "gaming_cam_offset_y": float(gaming_cam_offset_y),
            "gaming_cam_zoom": float(gaming_cam_zoom),
            "kept_segments": kept_segments,
            "fade_out": bool(fade_out),
            "session_id": session_id,
            "is_manual": bool(is_manual),
            "burn_subtitles": bool(burn_subtitles),
            "auto_titles": bool(auto_titles),
            "enqueued_at": time.time(),
            "status": "queued"
        }
        job.update(kwargs)
        self.task_queue.put(job)
        logger.info(f"📥 Clip '{clip_id}' encolado para Etapa 2 (Modo: {framing_mode}, Calidad: {video_quality or 'default'}). Cola actual: {self.task_queue.qsize()}")
        self._notify("job_enqueued", job)
        return job

    def clear_queue(self) -> int:
        """Vacía inmediatamente todos los trabajos pendientes y cancela el trabajo en curso."""
        self.cancel_requested = True
        if self.current_job:
            self.cancelled_job_ids.add(self.current_job.get("clip_id"))
        cleared = 0
        try:
            while not self.task_queue.empty():
                try:
                    j = self.task_queue.get_nowait()
                    self.task_queue.task_done()
                    cleared += 1
                except queue.Empty:
                    break
        except Exception as e:
            logger.warning(f"Error vaciando cola de Stage2: {e}")
        logger.info(f"🛑 Cola de Stage2 vaciada ({cleared} trabajos eliminados).")
        self._notify("queue_cleared", {"cleared_count": cleared, "queue_size": 0})
        return cleared

    def cancel_stale_session_jobs(self, current_session_id: int) -> int:
        """
        Descarta renders automáticos pendientes de sesiones anteriores y detiene
        el proceso ffmpeg de Stage 2 si pertenece a una sesión vieja.
        Respeta siempre los renders manuales (is_manual=True) y NO toca inbox_brutos/.
        """
        cancelled_count = 0
        retained_jobs = []

        try:
            while not self.task_queue.empty():
                try:
                    j = self.task_queue.get_nowait()
                    if isinstance(j, dict):
                        j_sess = j.get("session_id")
                        is_man = j.get("is_manual", False)
                        if not is_man and j_sess is not None and j_sess != current_session_id:

                            cancelled_count += 1
                        else:
                            retained_jobs.append(j)
                    self.task_queue.task_done()
                except queue.Empty:
                    break
            for rj in retained_jobs:
                self.task_queue.put(rj)
        except Exception as e:
            logger.warning(f"Error depurando cola de sesión vieja en Stage2: {e}")

        # Cancelar proceso en curso si es de sesión vieja
        with self.proc_lock:
            if self.current_job:
                curr_sess = self.current_job.get("session_id")
                curr_man = self.current_job.get("is_manual", False)
                if not curr_man and curr_sess is not None and curr_sess != current_session_id:
                    curr_id = self.current_job.get("clip_id")
                    self.cancelled_job_ids.add(curr_id)
                    cancelled_count += 1
                    logger.info(f"🛑 [Stage2] Descartando render en curso de sesión #{curr_sess} ('{curr_id}')...")
                    if self.current_process and self.current_process.poll() is None:
                        try:
                            from os_compat import kill_process_tree
                            kill_process_tree(self.current_process)
                        except Exception as e_kill:
                            logger.warning(f"Error matando ffmpeg de Stage2: {e_kill}")

        if cancelled_count > 0:
            logger.info(f"🧹 [Stage2] {cancelled_count} renders pendientes de sesiones viejas descartados.")
            self._notify("queue_cleared", {"cleared_count": cancelled_count, "queue_size": self.task_queue.qsize()})
        return cancelled_count

    def get_status(self) -> Dict[str, Any]:
        return {
            "queue_size": self.task_queue.qsize() + (1 if self.current_job else 0),
            "current_job": self.current_job,
            "completed_count": self.completed_job_count,
            "completed_history_size": len(self.completed_jobs)
        }

    def _worker_loop(self):
        """Bucle secuencial con baja prioridad CPU para no sobrecargar el sistema."""
        set_low_priority()

        while self.is_running:
            try:
                job = self.task_queue.get(timeout=1.0)
            except queue.Empty:
                continue

            with self.render_lock:
                self.current_job = job
                job["status"] = "processing"
                job["started_at"] = time.time()
                job["queue_size"] = self.task_queue.qsize() + 1
                self._notify("job_started", job)
    
                try:
                    result = self._process_job(job)
                    if result.get("status") == "cancelled":
                        job["status"] = "cancelled"
                        job["finished_at"] = time.time()
                        job["queue_size"] = self.task_queue.qsize()
                        self._notify("job_cancelled", job)
                    else:
                        job["status"] = "completed"
                        job["result"] = result
                        job["finished_at"] = time.time()
                        job["queue_size"] = self.task_queue.qsize()
                        self._remember_job(job)
                        logger.info(f"✅ Render 9:16 completado para '{job['clip_id']}' en {job['finished_at'] - job['started_at']:.1f}s")
                        self._notify("job_completed", job)
                        self._notify("short_created", {
                            "filename": result.get("file_name", f"short_{job['clip_id']}.mp4"),
                            "short": result,
                            "queue_size": self.task_queue.qsize()
                        })
                except Exception as e:
                    clip_id = job.get("clip_id", "")
                    if self.cancel_requested or clip_id in self.cancelled_job_ids:
                        logger.info(f"ℹ️ [Stage2] Render cancelado por detención del usuario para '{clip_id}'.")
                        job["status"] = "cancelled"
                        job["finished_at"] = time.time()
                        job["queue_size"] = self.task_queue.qsize()
                        self._notify("job_cancelled", job)
                    else:
                        logger.error(f"❌ Error renderizando clip 9:16 '{clip_id}': {e}", exc_info=True)
                        job["status"] = "failed"
                        job["error"] = str(e)
                        job["queue_size"] = self.task_queue.qsize()
                        self._notify("job_failed", job)
                finally:
                    self.cancelled_job_ids.discard(job.get("clip_id"))
                    self.current_job = None
                    self.task_queue.task_done()

    def _probe_has_audio(self, media_path: Path) -> bool:
        """Verifica mediante ffprobe si el archivo contiene al menos una pista de audio."""
        try:
            ffprobe_bin = get_ffprobe_cmd()
            chk = subprocess.run(
                [ffprobe_bin, "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=codec_type", "-of", "csv=p=0", str(media_path.resolve())],
                capture_output=True, text=True, timeout=8.0
            )
            return "audio" in chk.stdout
        except Exception:
            return True

    def _resolve_raw_clip(self, clip_id: str) -> Tuple[str, Path, Path, Dict[str, Any]]:
        """Resuelve el archivo de video bruto y su JSON asociado en inbox_brutos."""
        norm_id = clip_id
        for _ in range(2):
            if norm_id.endswith((".mp4", ".json", ".mkv", ".webm")):
                norm_id = Path(norm_id).stem
            else:
                break

        raw_json = self.inbox_dir / f"{norm_id}.json"
        meta: Dict[str, Any] = {}
        if raw_json.exists():
            try:
                with open(raw_json, "r", encoding="utf-8") as f:
                    meta = json.load(f)
            except Exception as e:
                logger.warning(f"No se pudo leer JSON de clip {norm_id}: {e}")

        raw_mp4: Optional[Path] = None
        meta_video_name = meta.get("video_file") or meta.get("file_name")
        if meta_video_name:
            cand_meta = self.inbox_dir / Path(str(meta_video_name)).name
            if cand_meta.exists() and cand_meta.is_file():
                raw_mp4 = cand_meta

        if raw_mp4 is None:
            for ext in (".mp4", ".mkv", ".webm", ".mp4.webm"):
                cand = self.inbox_dir / f"{norm_id}{ext}"
                if cand.exists() and cand.is_file():
                    raw_mp4 = cand
                    break

        if raw_mp4 is None:
            raw_mp4 = self.inbox_dir / f"{norm_id}.mp4"

        return norm_id, raw_mp4, raw_json, meta

    def _run_ffmpeg_with_watchdog(
        self,
        cmd: List[str],
        stage2_temp_dir: Path,
        clip_id: str,
        out_mp4: Path,
        effective_mode: str,
        effective_dur: float,
        ffmpeg_log: Path,
        t0: float,
        watchdog_timeout_sec: Optional[float] = None
    ):
        """Ejecuta FFmpeg con cancelación, watchdog y progreso real por su canal -progress."""
        sub_flags = get_subprocess_flags(low_priority=True)
        if os.name == "nt":
            sub_flags.setdefault("creationflags", 0)
            sub_flags["creationflags"] |= getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0x00004000)

        timeout_limit = float(watchdog_timeout_sec) if watchdog_timeout_sec is not None else max(180.0, float(effective_dur or 30.0) * 8.0)
        ffmpeg_cmd = list(cmd)
        if ffmpeg_cmd:
            # FFmpeg exige estas opciones antes del archivo de salida.
            ffmpeg_cmd[-1:-1] = ["-progress", "pipe:1", "-nostats"]

        progress_packets: queue.Queue = queue.Queue()
        log_fh = open(ffmpeg_log, "wb")
        proc = None
        reader_thread = None
        try:
            proc = subprocess.Popen(
                ffmpeg_cmd,
                cwd=str(stage2_temp_dir.resolve()),
                stdout=subprocess.PIPE,
                stderr=log_fh,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                **sub_flags
            )
            with self.proc_lock:
                self.current_process = proc

            def _read_progress():
                fields = {}
                try:
                    for raw_line in proc.stdout:
                        line = raw_line.strip()
                        if "=" not in line:
                            continue
                        key, value = line.split("=", 1)
                        fields[key] = value
                        if key == "progress":
                            progress_packets.put(fields)
                            fields = {}
                except Exception as e:
                    logger.debug(f"No se pudo leer progreso FFmpeg de '{clip_id}': {e}")

            reader_thread = threading.Thread(target=_read_progress, name=f"ffmpeg-progress-{clip_id}", daemon=True)
            reader_thread.start()
            last_progress_pct = -1.0
            last_progress_emit = 0.0

            while proc.poll() is None:
                time.sleep(0.1)
                now = time.time()
                if self.cancel_requested or clip_id in self.cancelled_job_ids:
                    kill_process_tree(proc)
                    try:
                        proc.wait(timeout=2.0)
                    except Exception:
                        pass
                    raise subprocess.CalledProcessError(proc.returncode or -1, ffmpeg_cmd, output=None, stderr="cancelled_by_user")

                if (now - t0) > timeout_limit:
                    logger.error(f"⏱️ [Stage2Worker] Watchdog timeout ({timeout_limit:.1f}s) alcanzado para '{clip_id}'. Terminando árbol FFmpeg...")
                    kill_process_tree(proc)
                    try:
                        proc.wait(timeout=2.0)
                    except Exception:
                        pass
                    raise TimeoutError(f"FFmpeg watchdog timeout tras {round(now - t0, 1)}s (límite {timeout_limit:.1f}s)")

                while True:
                    try:
                        packet = progress_packets.get_nowait()
                    except queue.Empty:
                        break
                    try:
                        stamp = packet.get("out_time", "")
                        hh, mm, ss = stamp.split(":")
                        rendered_sec = int(hh) * 3600 + int(mm) * 60 + float(ss)
                    except (ValueError, TypeError):
                        rendered_sec = None
                    progress_pct = None
                    if rendered_sec is not None and effective_dur > 0:
                        progress_pct = min(99.0, max(0.0, rendered_sec / effective_dur * 100.0))
                    if now - last_progress_emit >= 0.75 or (progress_pct is not None and progress_pct - last_progress_pct >= 1.0):
                        last_progress_emit = now
                        if progress_pct is not None:
                            last_progress_pct = progress_pct
                        self._notify("job_progress", {
                            "clip_id": clip_id,
                            "short_id": f"short_{clip_id}",
                            "elapsed_sec": round(now - t0, 1),
                            "rendered_sec": round(rendered_sec, 2) if rendered_sec is not None else None,
                            "duration_sec": round(float(effective_dur), 2) if effective_dur else None,
                            "progress_pct": round(progress_pct, 1) if progress_pct is not None else None,
                            "speed": packet.get("speed", ""),
                            "status": "processing",
                            "framing_mode": effective_mode,
                            "out_filename": out_mp4.name,
                            "queue_size": self.task_queue.qsize() + 1
                        })

            proc.wait()
        except Exception:
            if proc and proc.poll() is None:
                try:
                    kill_process_tree(proc)
                    proc.wait(timeout=2.0)
                except Exception:
                    pass
            raise
        finally:
            with self.proc_lock:
                self.current_process = None
            if reader_thread:
                reader_thread.join(timeout=1.0)
            if proc and proc.stdout:
                try:
                    proc.stdout.close()
                except Exception:
                    pass
            try:
                log_fh.close()
            except Exception:
                pass

        if proc.returncode != 0:
            stderr_tail = ""
            try:
                if ffmpeg_log.exists():
                    stderr_tail = ffmpeg_log.read_text(encoding="utf-8", errors="replace")[-2000:]
            except Exception:
                pass
            raise subprocess.CalledProcessError(proc.returncode, ffmpeg_cmd, output=None, stderr=stderr_tail)
    def _build_stage2_ffmpeg_cmd(
        self,
        raw_mp4: Path,
        out_mp4: Path,
        filtergraph: str,
        has_audio: bool,
        is_multi_segment: bool,
        actual_seek: float,
        actual_dur: float,
        fade_out: bool,
        clean_overlays: List[Dict[str, Any]],
        use_img: bool,
        img_path: Optional[Path],
        encoder: str,
        preset_val: str,
        crf_val: str,
        render_threads: int,
        audio_noise_reduction: bool = False,
        audio_leveling: bool = True
    ) -> List[str]:
        ffmpeg_bin = get_ffmpeg_cmd()
        cmd = [
            ffmpeg_bin, "-y", "-hide_banner", "-loglevel", "warning",
            "-fflags", "+genpts",
            "-threads", str(render_threads)
        ]

        if not is_multi_segment and actual_seek > 0.01:
            cmd.extend(["-accurate_seek", "-ss", str(actual_seek)])

        cmd.extend(["-i", str(raw_mp4.resolve())])
        if clean_overlays:
            for ov in clean_overlays:
                cmd.extend(["-i", str(ov["path"])])
        elif use_img and img_path:
            cmd.extend(["-i", str(img_path.resolve())])

        effective_filtergraph = filtergraph
        if has_audio:
            audio_filters = [STUDIO_AUDIO_FILTER]
            if audio_noise_reduction:
                audio_filters.append("afftdn=nr=10:nf=-30")
            if audio_leveling:
                audio_filters.append("dynaudnorm=f=150:g=15")
            audio_filters.append("alimiter=limit=0.95")
            audio_filter = ",".join(audio_filters)
            if fade_out and actual_dur > 0.4:
                fade_st = max(0.0, actual_dur - 0.35)
                audio_filter = f"{audio_filter},afade=t=out:st={fade_st:.2f}:d=0.35"
            effective_filtergraph = f"{filtergraph};[0:a]asetpts=PTS-STARTPTS,{audio_filter}[outa]"

        cmd.extend(["-filter_complex", effective_filtergraph])
        if not is_multi_segment and actual_dur > 0:
            cmd.extend(["-t", str(round(actual_dur, 3))])

        cmd.extend(["-map", "[outv]"])
        if has_audio:
            cmd.extend(["-map", "[outa]", "-c:a", "aac", "-b:a", "192k"])

        cmd.extend(["-fps_mode", "cfr"])
        cmd.extend(_build_video_encoder_args(encoder, preset_val, crf_val))
        cmd.extend([
            "-shortest",
            "-avoid_negative_ts", "make_zero",
            "-movflags", "+faststart",
            str(out_mp4.resolve())
        ])
        return cmd

    @_serialize_stage2_render
    def _process_job(self, job: Dict[str, Any]) -> Dict[str, Any]:
        clip_id, raw_mp4, raw_json, meta = self._resolve_raw_clip(job["clip_id"])

        if not raw_mp4.exists():
            raise FileNotFoundError(f"Video bruto no encontrado: {raw_mp4}")

        stage2_temp_dir = Path(get_shm_dir()) / "stage2_temp"
        try:
            stage2_temp_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

        kept_segments = job.get("kept_segments")
        fade_out = bool(job.get("fade_out", False))
        is_multi_segment = isinstance(kept_segments, list) and len(kept_segments) > 1
        clean_kept = None
        concat_source = None
        ffmpeg_log = stage2_temp_dir / f"ffmpeg_{clip_id}.log"

        if is_multi_segment:
            clean_kept = sorted(kept_segments, key=lambda s: float(s["start"]))
            effective_dur = round(sum(max(0.0, float(s["end"]) - float(s["start"])) for s in clean_kept), 2)

            has_audio = self._probe_has_audio(raw_mp4)

            v_parts, a_parts, cat_in = [], [], []
            for i, s in enumerate(clean_kept):
                st, en = float(s["start"]), float(s["end"])
                v_parts.append(f"[0:v]trim=start={st:.3f}:end={en:.3f},setpts=PTS-STARTPTS[v{i}];")
                if has_audio:
                    a_parts.append(f"[0:a]atrim=start={st:.3f}:end={en:.3f},asetpts=PTS-STARTPTS[a{i}];")
                    cat_in.append(f"[v{i}][a{i}]")
                else:
                    cat_in.append(f"[v{i}]")
            a_flag = 1 if has_audio else 0
            cat_filter = "".join(v_parts) + "".join(a_parts) + f"{''.join(cat_in)}concat=n={len(clean_kept)}:v=1:a={a_flag}[vcat]" + ("[acat_raw];[acat_raw]aresample=async=1:first_pts=0[acat]" if has_audio else "")

            concat_source = stage2_temp_dir / f"concat_{clip_id}.mp4"
            render_threads = max(2, (os.cpu_count() or 4) // 2)
            concat_cmd = [
                get_ffmpeg_cmd(), "-y", "-hide_banner", "-loglevel", "warning",
                "-fflags", "+genpts",
                "-threads", str(render_threads),
                "-i", str(raw_mp4.resolve()),
                "-filter_complex", cat_filter,
                "-map", "[vcat]"
            ]
            if has_audio:
                concat_cmd.extend(["-map", "[acat]", "-c:a", "aac"])
            concat_cmd.extend([
                "-fps_mode", "cfr",
                "-c:v", "libx264", "-preset", "ultrafast", "-crf", "16",
                "-avoid_negative_ts", "make_zero",
                "-movflags", "+faststart",
                str(concat_source.resolve())
            ])
            sub_flags = get_subprocess_flags(low_priority=True)
            if os.name == "nt":
                sub_flags.setdefault("creationflags", 0)
                sub_flags["creationflags"] |= getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0x00004000)
            subprocess.run(concat_cmd, check=True, timeout=max(180.0, min(1800.0, effective_dur * 8.0)), **sub_flags)

            raw_mp4 = concat_source
            start_sec = 0.0
            end_sec = effective_dur
            video_info = get_video_info(raw_mp4)
            orig_dur = effective_dur
        else:
            # 1. Obtener información de video
            video_info = get_video_info(raw_mp4)
            orig_dur = video_info.get("duration", 30.0)

            start_sec = float(job.get("start_sec", 0.0) or 0.0)
            end_sec = job.get("end_sec") or orig_dur
            if isinstance(kept_segments, list) and len(kept_segments) == 1:
                start_sec = max(0.0, float(kept_segments[0].get("start", start_sec)))
                if kept_segments[0].get("end") is not None:
                    end_sec = float(kept_segments[0]["end"])
            if end_sec <= start_sec:
                end_sec = orig_dur

            effective_dur = round(end_sec - start_sec, 2)

        # Sondeo de sincronización A/V por origen común
        sync_info = probe_stream_sync(raw_mp4)
        has_audio = bool(sync_info.get("has_audio", False))
        target_fps = float(sync_info.get("fps", 30.0))
        lead_trim = float(sync_info.get("lead_trim", 0.0)) if not is_multi_segment else 0.0
        if not is_multi_segment:
            actual_seek = round(start_sec + lead_trim, 3)
            actual_dur = max(0.5, round(effective_dur - (lead_trim if start_sec == 0 else 0.0), 3))
        else:
            actual_seek = 0.0
            actual_dur = max(0.5, float(effective_dur))
        effective_start_trim = actual_seek if not is_multi_segment else start_sec

        vid_w = video_info.get("width", 1920)
        vid_h = video_info.get("height", 1080)
        is_already_vertical = (vid_h > vid_w)

        # 2. Análisis de encuadre (Salto inteligente si el clip original ya es 9:16 vertical)
        framing_mode = job.get("framing_mode", "AUTO").upper()
        detection_data = None
        if is_already_vertical:
            logger.info(f"📱 [Stage2Worker] Clip ya es vertical ({vid_w}x{vid_h}). Omitiendo escaneo facial YuNet; acelerando renderizado 3x.")
            effective_mode = "ALREADY_VERTICAL"
            detection_data = {"mode": "ALREADY_VERTICAL", "shots": [], "center_x_norm": 0.5}
        elif framing_mode == "AUTO":
            try:
                detection_data = detect_faces_in_video(raw_mp4)
                effective_mode = (detection_data or {}).get("mode", "SINGLE_SPEAKER")
            except Exception as e:
                logger.warning(f"⚠️ [Stage2Worker] Error detectando caras en modo AUTO ({e}). Cayendo a SINGLE_SPEAKER.")
                effective_mode = "SINGLE_SPEAKER"
                detection_data = {"mode": "SINGLE_SPEAKER", "shots": [], "center_x_norm": 0.5}
        else:
            if framing_mode in ["GAMING_SPLIT", "SINGLE_SPEAKER", "SINGLE_SPEAKER_TIGHT", "SPLIT_SCREEN"]:
                try:
                    detection_data = detect_faces_in_video(raw_mp4)
                except Exception as e:
                    logger.warning(f"Aviso detectando caras para modo {framing_mode}: {e}")
            effective_mode = framing_mode

        # 3. Cargar preferencias visuales y marca de agua
        from config_manager import load_config, ASSETS_DIR
        cfg = load_config()

        # Resolver perfil de renderizado según calidad
        vq = job.get("video_quality") or meta.get("video_quality") or cfg.get("video_quality", "1080p")
        out_w, out_h, crf_val, preset_val = get_render_profile(vq)

        burn_subtitles = bool(job.get("burn_subtitles", True))
        auto_titles = bool(job.get("auto_titles", True))

        custom_title = (job.get("custom_title") or meta.get("titulo_gancho")) if auto_titles else None
        show_banner = bool(job.get("show_banner", True)) and auto_titles
        banner_color = job.get("banner_color") or cfg.get("banner_color", "#FFFFFF")
        show_progress_bar = job.get("show_progress_bar") if "show_progress_bar" in job else cfg.get("show_progress_bar", True)
        progress_bar_color = job.get("progress_bar_color") or cfg.get("progress_bar_color", "#00D7FF")
        wm_type = job.get("watermark_type") or cfg.get("watermark_type", "text")
        wm_pos = job.get("watermark_position") or cfg.get("watermark_position", "top_right")
        wm_text = job.get("watermark_text") if "watermark_text" in job else cfg.get("watermark_text", "@TuCanal")
        wm_opacity = float(job.get("watermark_opacity") or cfg.get("watermark_opacity", 0.7))

        logo_path = ASSETS_DIR / "logo.png"
        use_logo = False
        if wm_type == "logo" and logo_path.exists():
            if is_valid_image_file(logo_path):
                use_logo = True
            else:
                logger.warning(f"⚠️ [Stage2Worker] logo.png inválido o corrupto ignorado: {logo_path}")

        # Manejo de múltiples overlays interactivos o logo/overlay flotante único legacy (con validación estricta)
        clean_overlays = []
        raw_ovs = job.get("overlays")
        if isinstance(raw_ovs, list) and len(raw_ovs) > 0:
            for ov in raw_ovs:
                if not isinstance(ov, dict):
                    continue
                raw_rel = ov.get("asset_path") or ov.get("path") or ov.get("image_path") or ov.get("image") or ""
                p_cand = None
                if raw_rel:
                    p_raw = Path(raw_rel)
                    p1 = p_raw.resolve() if p_raw.is_absolute() else (BASE_DIR / raw_rel).resolve()
                    p2 = (ASSETS_DIR / "overlays" / p_raw.name).resolve()
                    if p1.exists() and p1.is_file():
                        p_cand = p1
                    elif p2.exists() and p2.is_file():
                        p_cand = p2
                if p_cand and p_cand.exists():
                    if not is_valid_image_file(p_cand):
                        logger.warning(f"⚠️ [Stage2Worker] Overlay inválido o corrupto ignorado: {p_cand}")
                        continue
                    clean_overlays.append({
                        "path": p_cand,
                        "x": float(ov.get("x", 0.5)),
                        "y": float(ov.get("y", 0.5)),
                        "width": max(0.02, min(1.0, float(ov.get("width", ov.get("scale", 0.20))))),
                        "rotation": float(ov.get("rotation", 0.0)),
                        "opacity": max(0.0, min(1.0, float(ov.get("opacity", 1.0)))),
                        "start": float(ov.get("start", 0.0)),
                        "end": float(ov.get("end", 999999.0)),
                        "z_index": int(ov.get("z_index", 0))
                    })
            clean_overlays.sort(key=lambda x: x["z_index"])

        if is_multi_segment and clean_overlays:
            from ass_generator import remap_interval_through_segments
            remapped_ovs = []
            for ov in clean_overlays:
                m_ranges = remap_interval_through_segments(ov["start"], ov["end"], clean_kept)
                for (m_s, m_e) in m_ranges:
                    c_ov = dict(ov)
                    c_ov["start"] = m_s
                    c_ov["end"] = m_e
                    remapped_ovs.append(c_ov)
            clean_overlays = remapped_ovs

        overlay_img_path = None
        req_ov = job.get("overlay_image")
        if not clean_overlays and req_ov:
            p_ov = Path(req_ov)
            if not p_ov.is_absolute():
                p_ov = BASE_DIR / req_ov
            if not p_ov.exists():
                p_ov = ASSETS_DIR / "overlays" / Path(req_ov).name
            if p_ov.exists():
                if is_valid_image_file(p_ov):
                    overlay_img_path = p_ov.resolve()
                else:
                    logger.warning(f"⚠️ [Stage2Worker] overlay_image inválido o corrupto ignorado: {p_ov}")

        use_img = (overlay_img_path is not None) or use_logo or (len(clean_overlays) > 0)
        img_path = overlay_img_path if overlay_img_path else (logo_path.resolve() if use_logo else None)

        sub_base_col = job.get("subtitle_base_color") or cfg.get("subtitle_base_color", "#FFFFFF")
        sub_high_col = job.get("subtitle_highlight_color") or cfg.get("subtitle_highlight_color", "#FFE600")
        sub_fsize = int(job.get("subtitle_font_size") or cfg.get("subtitle_font_size", 54))
        sub_margv = int(job.get("subtitle_margin_v") or cfg.get("subtitle_margin_v", 300))

        crop_offset_x = float(job.get("crop_offset_x", 0.0))
        crop_offset_y = float(job.get("crop_offset_y", 0.0))
        zoom = float(job.get("zoom", 1.0))
        gaming_cam_offset_x = float(job.get("gaming_cam_offset_x", 0.0))
        gaming_cam_offset_y = float(job.get("gaming_cam_offset_y", 0.0))
        gaming_cam_zoom = float(job.get("gaming_cam_zoom", 1.0))
        overlay_x = float(job.get("overlay_x", 0.85))
        overlay_y = float(job.get("overlay_y", 0.10))
        overlay_scale = float(job.get("overlay_scale", 0.20))
        overlay_opacity = float(job.get("overlay_opacity", 1.0))

        # 4. Generación de subtítulos .ASS en memoria volátil (incluye progreso viral y marca de agua fija)
        ass_filename = f"sub_{clip_id}.ass"
        ass_path = stage2_temp_dir / ass_filename
        try:
            generate_ass_subtitles(
                clip_metadata=meta,
                output_ass_path=ass_path,
                custom_title=custom_title if auto_titles else None,
                start_trim=effective_start_trim,
                end_trim=end_sec,
                show_banner=(show_banner and auto_titles),
                banner_color=banner_color,
                show_progress_bar=show_progress_bar,
                progress_bar_color=progress_bar_color,
                watermark_text=wm_text if (not use_img and wm_text) else None,
                watermark_position=wm_pos,
                subtitle_base_color=sub_base_col,
                subtitle_highlight_color=sub_high_col,
                subtitle_font_size=sub_fsize,
                subtitle_margin_v=sub_margv,
                kept_segments=clean_kept if is_multi_segment else kept_segments
            )

            # Si burn_subtitles es False, se pasa ass_path=None para omitir totalmente el filtro ass=... en FFmpeg
            effective_ass_path = Path(ass_filename) if burn_subtitles else None

            # 5. Construcción del filtergraph con soporte opcional de logo/overlay PNG
            # Pasamos ruta relativa y ejecutamos en cwd=stage2_temp_dir para evitar problemas de parsing en Windows
            filtergraph = build_reframe_filtergraph(
                framing_mode=effective_mode,
                ass_path=effective_ass_path,
                video_info=video_info,
                detection_data=detection_data,
                crop_offset_x=crop_offset_x,
                crop_offset_y=crop_offset_y,
                zoom=zoom,
                gaming_cam_offset_x=gaming_cam_offset_x,
                gaming_cam_offset_y=gaming_cam_offset_y,
                gaming_cam_zoom=gaming_cam_zoom,
                start_trim=effective_start_trim,
                logo_path=logo_path.resolve() if use_logo else None,
                logo_position=wm_pos,
                logo_opacity=wm_opacity,
                overlay_path=overlay_img_path,
                overlay_x=overlay_x,
                overlay_y=overlay_y,
                overlay_scale=overlay_scale,
                overlay_opacity=overlay_opacity,
                overlays=clean_overlays if clean_overlays else None,
                out_w=out_w,
                out_h=out_h,
                fade_out=fade_out,
                effective_duration=actual_dur,
                target_fps=target_fps
            )

            # 6. Salida de renderizado
            out_mp4 = self.out_dir / f"short_{clip_id}.mp4"
            out_json = self.out_dir / f"short_{clip_id}.json"

            render_threads = max(2, (os.cpu_count() or 4) // 2)
            selected_encoder = detect_best_h264_encoder()

            cmd = self._build_stage2_ffmpeg_cmd(
                raw_mp4=raw_mp4,
                out_mp4=out_mp4,
                filtergraph=filtergraph,
                has_audio=has_audio,
                is_multi_segment=is_multi_segment,
                actual_seek=actual_seek,
                actual_dur=actual_dur,
                fade_out=fade_out,
                audio_noise_reduction=bool(job.get("audio_noise_reduction", False)),
                audio_leveling=bool(job.get("audio_leveling", True)),
                clean_overlays=clean_overlays,
                use_img=use_img,
                img_path=img_path,
                encoder=selected_encoder,
                preset_val=preset_val,
                crf_val=crf_val,
                render_threads=render_threads
            )

            if self.cancel_requested or clip_id in self.cancelled_job_ids:
                logger.info(f"ℹ️ [Stage2Worker] Render cancelado por detención del usuario para clip '{clip_id}'.")
                return {
                    "status": "cancelled",
                    "short_id": f"short_{clip_id}",
                    "raw_clip_id": clip_id,
                    "reason": "user_cancelled"
                }

            t0 = time.time()
            logger.info(f"🚀 Renderizando 9:16 ({effective_mode}, encoder={selected_encoder}, fps={target_fps}, lead_trim={lead_trim}s) -> {out_mp4.name}...")
            watchdog_override = job.get("_watchdog_timeout_sec")
            try:
                self._run_ffmpeg_with_watchdog(
                    cmd=cmd,
                    stage2_temp_dir=stage2_temp_dir,
                    clip_id=clip_id,
                    out_mp4=out_mp4,
                    effective_mode=effective_mode,
                    effective_dur=actual_dur,
                    ffmpeg_log=ffmpeg_log,
                    t0=t0,
                    watchdog_timeout_sec=watchdog_override
                )
            except Exception as primary_err:
                if self.cancel_requested or clip_id in self.cancelled_job_ids:
                    logger.info(f"ℹ️ [Stage2Worker] Render cancelado por detención del usuario ({out_mp4.name}).")
                    if out_mp4.exists():
                        try:
                            out_mp4.unlink()
                        except Exception:
                            pass
                    return {
                        "status": "cancelled",
                        "short_id": f"short_{clip_id}",
                        "raw_clip_id": clip_id,
                        "reason": "user_cancelled"
                    }

                err_msg = str(getattr(primary_err, "stderr", "") or primary_err)
                logger.warning(f"⚠️ [Stage2Worker] Falló render principal para '{clip_id}' ({selected_encoder}): {err_msg[-500:]}")

                if out_mp4.exists():
                    try:
                        out_mp4.unlink()
                    except Exception:
                        pass

                # Si usaba GPU, intentar primero con libx264 conservando filtros; luego 1 fallback limpio sin subtítulos/overlays
                recovered = False
                if selected_encoder != "libx264":
                    logger.warning(f"🔄 [Stage2Worker] Fallback GPU->CPU (libx264) para '{clip_id}'...")
                    cpu_cmd = self._build_stage2_ffmpeg_cmd(
                        raw_mp4=raw_mp4,
                        out_mp4=out_mp4,
                        filtergraph=filtergraph,
                        has_audio=has_audio,
                        is_multi_segment=is_multi_segment,
                        actual_seek=actual_seek,
                        actual_dur=actual_dur,
                        fade_out=fade_out,
                        clean_overlays=clean_overlays,
                        use_img=use_img,
                        img_path=img_path,
                        encoder="libx264",
                        preset_val=preset_val,
                        crf_val=crf_val,
                        render_threads=render_threads,
                        audio_noise_reduction=bool(job.get("audio_noise_reduction", False)),
                        audio_leveling=bool(job.get("audio_leveling", True))
                    )
                    try:
                        self._run_ffmpeg_with_watchdog(
                            cmd=cpu_cmd,
                            stage2_temp_dir=stage2_temp_dir,
                            clip_id=clip_id,
                            out_mp4=out_mp4,
                            effective_mode=effective_mode,
                            effective_dur=actual_dur,
                            ffmpeg_log=ffmpeg_log,
                            t0=time.time(),
                            watchdog_timeout_sec=watchdog_override
                        )
                        recovered = True
                    except Exception as cpu_err:
                        logger.warning(f"⚠️ [Stage2Worker] Fallback CPU con filtros también falló para '{clip_id}': {str(getattr(cpu_err, 'stderr', '') or cpu_err)[-400:]}")
                        if out_mp4.exists():
                            try:
                                out_mp4.unlink()
                            except Exception:
                                pass

                if not recovered:
                    if self.cancel_requested or clip_id in self.cancelled_job_ids:
                        return {
                            "status": "cancelled",
                            "short_id": f"short_{clip_id}",
                            "raw_clip_id": clip_id,
                            "reason": "user_cancelled"
                        }
                    safe_mode = "ALREADY_VERTICAL" if is_already_vertical else "SINGLE_SPEAKER"
                    logger.warning(f"🛡️ [Stage2Worker] Reintentando 1 vez con comando limpio seguro ({safe_mode}, libx264, sin subtítulos/overlays) para '{clip_id}'...")
                    safe_fg = build_reframe_filtergraph(
                        framing_mode=safe_mode,
                        ass_path=None,
                        video_info=video_info,
                        detection_data={"mode": safe_mode, "shots": [], "center_x_norm": 0.5},
                        start_trim=effective_start_trim,
                        out_w=out_w,
                        out_h=out_h,
                        fade_out=fade_out,
                        effective_duration=actual_dur,
                        target_fps=target_fps
                    )
                    safe_cmd = self._build_stage2_ffmpeg_cmd(
                        raw_mp4=raw_mp4,
                        out_mp4=out_mp4,
                        filtergraph=safe_fg,
                        has_audio=has_audio,
                        is_multi_segment=is_multi_segment,
                        actual_seek=actual_seek,
                        actual_dur=actual_dur,
                        fade_out=fade_out,
                        clean_overlays=[],
                        use_img=False,
                        img_path=None,
                        encoder="libx264",
                        preset_val=preset_val,
                        crf_val=crf_val,
                        render_threads=render_threads,
                        audio_noise_reduction=bool(job.get("audio_noise_reduction", False)),
                        audio_leveling=bool(job.get("audio_leveling", True))
                    )
                    self._run_ffmpeg_with_watchdog(
                        cmd=safe_cmd,
                        stage2_temp_dir=stage2_temp_dir,
                        clip_id=clip_id,
                        out_mp4=out_mp4,
                        effective_mode=safe_mode,
                        effective_dur=actual_dur,
                        ffmpeg_log=ffmpeg_log,
                        t0=time.time(),
                        watchdog_timeout_sec=watchdog_override
                    )
                    effective_mode = safe_mode
            t_render = round(time.time() - t0, 2)

            # 6. Guardar metadatos finales
            file_size_mb = round(out_mp4.stat().st_size / (1024 * 1024), 2) if out_mp4.exists() else 0.0
            final_meta = {
                "short_id": f"short_{clip_id}",
                "raw_clip_id": clip_id,
                "titulo_gancho": (custom_title or meta.get("titulo_gancho", "¡MOMENTO DESTACADO!")) if auto_titles else "",
                "framing_mode": effective_mode,
                "original_framing_request": framing_mode,
                "detection_data": detection_data,
                "score": meta.get("score", 0.75),
                "duration": actual_dur,
                "rendered_at": datetime.now().isoformat(),
                "render_time_sec": t_render,
                "file_name": out_mp4.name,
                "file_size_mb": file_size_mb,
                "video_quality": vq,
                "resolution": f"{out_w}x{out_h}",
                "video_url": f"/shorts/{out_mp4.name}",
                "burn_subtitles": burn_subtitles,
                "auto_titles": auto_titles,
                "transcription": meta.get("transcription"),
                "transcripcion_base": meta.get("transcripcion_base", "")
            }

            with open(out_json, "w", encoding="utf-8") as f:
                json.dump(final_meta, f, indent=2, ensure_ascii=False)

        finally:
            try:
                if ass_path.exists():
                    ass_path.unlink()
                if concat_source and concat_source.exists():
                    concat_source.unlink()
                if ffmpeg_log.exists():
                    ffmpeg_log.unlink()
            except Exception:
                pass

        return final_meta

    @_serialize_stage2_render
    def render_studio_clip(
        self,
        clip_id: str,
        custom_title: Optional[str] = None,
        show_banner: bool = True,
        banner_color: Optional[str] = None,
        trim_start: float = 0.0,
        trim_end: Optional[float] = None,
        framing_mode: str = "AUTO",
        crop_offset_x: float = 0.0,
        crop_offset_y: float = 0.0,
        zoom: float = 1.0,
        segments: Optional[List[Dict[str, Any]]] = None,
        watermark_text: Optional[str] = None,
        watermark_position: Optional[str] = None,
        show_progress_bar: Optional[bool] = None,
        video_quality: Optional[str] = None,
        subtitle_base_color: Optional[str] = None,
        subtitle_highlight_color: Optional[str] = None,
        subtitle_font_size: Optional[int] = None,
        subtitle_margin_v: Optional[int] = None,
        overlay_image: Optional[str] = None,
        overlay_x: float = 0.85,
        overlay_y: float = 0.10,
        overlay_scale: float = 0.20,
        overlay_opacity: float = 1.0,
        overlays: Optional[List[Dict[str, Any]]] = None,
        gaming_cam_offset_x: float = 0.0,
        gaming_cam_offset_y: float = 0.0,
        gaming_cam_zoom: float = 1.0,
        kept_segments: Optional[List[Dict[str, float]]] = None,
        fade_out: bool = False,
        burn_subtitles: bool = True,
        auto_titles: bool = True,
        audio_noise_reduction: bool = False,
        audio_leveling: bool = True
    ) -> Dict[str, Any]:
        """
        Re-renderizado ultrarrápido desde el Estudio (Etapa 4):
        - CERO Whisper (reutiliza o actualiza transcripcion_segmentos editados por el usuario).
        - Regenera el .ass quemando el nuevo banner y subtítulos sincronizados.
        - Aplica trim_start/trim_end, crop_offset_x/y, zoom, overlay y estilos en FFmpeg.
        - Sobrescribe o genera el short final en clips_verticales/.
        """
        self.cancel_requested = False
        raw_id, raw_mp4, raw_json, meta = self._resolve_raw_clip(
            clip_id[6:] if clip_id.startswith("short_") else clip_id
        )

        if not raw_mp4.exists():
            short_json_path = self.out_dir / f"short_{raw_id}.json"
            if short_json_path.exists():
                try:
                    with open(short_json_path, "r", encoding="utf-8") as f:
                        s_meta = json.load(f)
                    alt_raw_id = s_meta.get("raw_clip_id", raw_id)
                    alt_id, alt_mp4, alt_json, alt_meta = self._resolve_raw_clip(alt_raw_id)
                    if alt_mp4.exists():
                        raw_id, raw_mp4, raw_json, meta = alt_id, alt_mp4, alt_json, alt_meta
                except Exception:
                    pass

        if not raw_mp4.exists():
            raise FileNotFoundError(f"Clip original no encontrado para '{clip_id}' ({raw_mp4})")

        # Actualizar segmentos y título gancho en la metadata sin llamar a Whisper
        if segments is not None:
            clean_segments = []
            for s in segments:
                clean_segments.append({
                    "start": round(float(s.get("start", 0.0)), 2),
                    "end": round(float(s.get("end", 0.0)), 2),
                    "text": str(s.get("text", "")).strip()
                })
            meta["segments"] = clean_segments
            meta["transcripcion_segmentos"] = clean_segments
            if "transcription" not in meta or not isinstance(meta["transcription"], dict):
                meta["transcription"] = {}
            meta["transcription"]["segments"] = clean_segments
            meta["transcripcion_base"] = " ".join([s["text"] for s in clean_segments if s["text"]])
            if "etapa4_ready" in meta and isinstance(meta["etapa4_ready"], dict):
                if "timeline_tracks" in meta["etapa4_ready"]:
                    meta["etapa4_ready"]["timeline_tracks"]["subtitles"] = clean_segments

        if custom_title is not None:
            meta["titulo_gancho"] = custom_title.strip()

        if overlays is not None:
            meta["overlays"] = overlays

        # Guardar cambios en el JSON del clip original
        if raw_json.exists():
            try:
                with open(raw_json, "w", encoding="utf-8") as f:
                    json.dump(meta, f, indent=2, ensure_ascii=False)
            except Exception as e:
                logger.warning(f"Error persistiendo JSON editado en {raw_json}: {e}")

        job = {
            "clip_id": raw_id,
            "framing_mode": framing_mode,
            "custom_title": custom_title or meta.get("titulo_gancho"),
            "show_banner": show_banner,
            "banner_color": banner_color,
            "start_sec": max(0.0, float(trim_start)),
            "end_sec": float(trim_end) if trim_end is not None and float(trim_end) > float(trim_start) else None,
            "crop_offset_x": float(crop_offset_x),
            "crop_offset_y": float(crop_offset_y),
            "zoom": float(zoom),
            "video_quality": video_quality,
            "watermark_text": watermark_text,
            "watermark_position": watermark_position,
            "show_progress_bar": show_progress_bar,
            "subtitle_base_color": subtitle_base_color,
            "subtitle_highlight_color": subtitle_highlight_color,
            "subtitle_font_size": subtitle_font_size,
            "subtitle_margin_v": subtitle_margin_v,
            "overlay_image": overlay_image,
            "overlay_x": float(overlay_x),
            "overlay_y": float(overlay_y),
            "overlay_scale": float(overlay_scale),
            "overlay_opacity": float(overlay_opacity),
            "overlays": overlays,
            "gaming_cam_offset_x": float(gaming_cam_offset_x),
            "gaming_cam_offset_y": float(gaming_cam_offset_y),
            "gaming_cam_zoom": float(gaming_cam_zoom),
            "kept_segments": kept_segments,
            "fade_out": bool(fade_out),
            "audio_noise_reduction": bool(audio_noise_reduction),
            "audio_leveling": bool(audio_leveling),
            "burn_subtitles": bool(burn_subtitles),
            "auto_titles": bool(auto_titles),
            "enqueued_at": time.time(),
            "status": "processing"
        }

        job["started_at"] = time.time()
        job["queue_size"] = self.task_queue.qsize() + 1
        self._notify("job_started", job)
        logger.info(f"⚡ [Estudio 9:16] Renderizando '{raw_id}' (Trim: {trim_start}s - {trim_end}s, Mode: {framing_mode}, Offset: {crop_offset_x})...")
        try:
            result = self._process_job(job)
        except Exception as e:
            job["status"] = "failed"
            job["error"] = str(e)
            job["finished_at"] = time.time()
            job["queue_size"] = self.task_queue.qsize()
            self._remember_job(job)
            self._notify("job_failed", job)
            raise
        if result.get("status") == "cancelled":
            job["status"] = "cancelled"
            job["finished_at"] = time.time()
            job["queue_size"] = self.task_queue.qsize()
            self._remember_job(job)
            self._notify("job_cancelled", job)
            return result

        job["status"] = "completed"
        job["result"] = result
        job["finished_at"] = time.time()
        job["queue_size"] = self.task_queue.qsize()
        self._remember_job(job)
        self._notify("job_completed", job)
        self._broadcast({
            "type": "short_created",
            "filename": result.get("file_name", f"short_{raw_id}.mp4"),
            "short": result
        })
        return result


# Instancia singleton para uso en servidor y radar
stage2_queue = Stage2Worker()
