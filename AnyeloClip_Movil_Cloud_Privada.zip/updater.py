"""
updater.py — Sistema de Auto-Actualización In-App Seguro para Anyelo Clip.
Permite verificar y aplicar parches semánticos sin tocar configuraciones, licencias ni clips.
"""
import os
import sys
import ssl
import json
import shutil
import hashlib
import zipfile
import urllib.request
import urllib.error
import logging
import re
from urllib.parse import urlparse
from pathlib import Path
from typing import Dict, Any, Tuple

from version import VERSION

logger = logging.getLogger("live_clipper.updater")
if not logger.handlers:
    logging.basicConfig(level=logging.INFO)

UPDATE_RELEASE_API_URL = "https://api.github.com/repos/Anyelomartinez12/anyelo-clip-descargas/releases/latest"
UPDATE_RELEASE_PAGE = "https://github.com/Anyelomartinez12/anyelo-clip-descargas/releases/latest"
TRUSTED_DOWNLOAD_PREFIX = "/Anyelomartinez12/anyelo-clip-descargas/releases/download/"
MAX_PATCH_BYTES = 50 * 1024 * 1024
APP_DIR = Path(__file__).resolve().parent

# Lista blanca estricta de extensiones permitidas en parches
ALLOWED_EXTENSIONS = {".py", ".html", ".js", ".css"}

# Archivos y carpetas protegidos que JAMÁS pueden ser tocados o sobrescritos por un parche
PROTECTED_TARGETS = {
    "config.json",
    "user_viral_brain.json",
    "python_win",
    "inbox_brutos",
    "clips_verticales",
    "logs",
    "models",
    "runtime_buffer",
    "_backup_prev_version"
}


def _get_ssl_context(allow_unverified: bool = False) -> ssl.SSLContext:
    """
    Construye un contexto SSL robusto para Windows y Linux:
    1. Intenta cargar certifi.where() y devolver ssl.create_default_context(cafile=certifi.where()).
    2. Si certifi no estuviera disponible, intenta ssl.create_default_context().
    3. Como último respaldo seguro para descargas verificadas por sha256 en Windows embebido,
       permite usar ssl._create_unverified_context() (únicamente cuando allow_unverified=True).
    """
    # 1. Intentar certifi
    try:
        import certifi
        cafile = certifi.where()
        if os.path.exists(cafile):
            return ssl.create_default_context(cafile=cafile)
    except Exception:
        pass

    # 2. Intentar contexto por defecto de OpenSSL + Windows Root Store
    try:
        ctx = ssl.create_default_context()
        if hasattr(ssl, "enum_certificates"):
            for store_name in ("ROOT", "CA"):
                try:
                    for cert, encoding, trust in ssl.enum_certificates(store_name):
                        if encoding == "x509_asn":
                            ctx.load_verify_locations(cdata=cert)
                except Exception:
                    pass
        return ctx
    except Exception:
        pass

    # 3. Respaldo unverified si está permitido
    if allow_unverified:
        try:
            return ssl._create_unverified_context()
        except Exception:
            pass

    return None


get_ssl_context = _get_ssl_context


def safe_urlopen(req, timeout: float = 10.0, allow_unverified: bool = False):
    """
    Ejecuta urllib.request.urlopen de forma tolerante a fallos de certificados SSL en Windows.
    Si la verificación estándar falla con CERTIFICATE_VERIFY_FAILED (típico en Python portable
    o entornos Windows corporativos/antivirus), reintenta automáticamente con contexto permisivo.
    La autenticidad e integridad del código se encuentra blindada al 100% por la validación
    criptográfica obligatoria de hash SHA-256 antes de la extracción.
    """
    ctx = _get_ssl_context(allow_unverified=allow_unverified)
    try:
        if ctx is not None:
            return urllib.request.urlopen(req, timeout=timeout, context=ctx)
        return urllib.request.urlopen(req, timeout=timeout)
    except (urllib.error.URLError, ssl.SSLCertVerificationError, ssl.SSLError) as e:
        err_str = str(e).lower()
        if allow_unverified and any(term in err_str for term in ("certificate_verify_failed", "certificate verify failed", "unable to get local issuer certificate", "self-signed certificate")):
            logger.warning(f"⚠️ [AutoUpdater] Falló verificación SSL estándar en Windows ({e}). Reintentando con contexto permisivo (integridad protegida por SHA-256)...")
            try:
                unverified_ctx = ssl._create_unverified_context()
                return urllib.request.urlopen(req, timeout=timeout, context=unverified_ctx)
            except Exception:
                pass
        raise


def parse_semantic_version(v_str: str) -> Tuple[int, ...]:
    """Convierte un string de versión (ej: '2.2.1' o 'v2.2.1') a una tupla de enteros."""
    clean = str(v_str).strip().lstrip("vV")
    parts = []
    for x in clean.split("."):
        try:
            parts.append(int(x))
        except ValueError:
            parts.append(0)
    return tuple(parts) if parts else (0, 0, 0)


def check_for_updates() -> Dict[str, Any]:
    """
    Consulta la última release pública del repositorio oficial de Anyelo Clip.
    Los parches se identifican como AnyeloClip_Patch_X.Y.Z.zip y se validan
    usando el SHA-256 que devuelve GitHub para el asset.
    Si no hay conexión, hay timeout o falla el JSON, retorna update_available=False
    sin bloquear ni demorar el arranque del servidor.
    """
    fallback_res = {
        "update_available": False,
        "current_version": VERSION,
        "latest_version": VERSION,
        "type": "none",
        "changelog": "",
        "download_url": "",
        "sha256": ""
    }

    try:
        req = urllib.request.Request(
            UPDATE_RELEASE_API_URL,
            headers={
                "User-Agent": f"Anyelo Clip-InAppUpdater/{VERSION}",
                "Accept": "application/json"
            }
        )
        with safe_urlopen(req, timeout=4.0) as resp:
            if resp.status != 200:
                logger.debug(f"Aviso en check_for_updates: HTTP {resp.status}")
                return fallback_res
            data = json.loads(resp.read(1024 * 1024).decode("utf-8"))
        if data.get("draft") or data.get("prerelease"):
            return fallback_res

        assets = data.get("assets") or []
        patch_asset = next((a for a in assets if re.fullmatch(
            r"AnyeloClip_Patch_(v?\d+(?:\.\d+){1,3})\.zip", str(a.get("name", "")), re.IGNORECASE
        )), None)
        body = str(data.get("body") or "")
        app_version_match = re.search(r"(?im)^App-Version:\s*v?(\d+(?:\.\d+){1,3})\s*$", body)

        if patch_asset:
            match = re.fullmatch(r"AnyeloClip_Patch_(v?\d+(?:\.\d+){1,3})\.zip", patch_asset["name"], re.IGNORECASE)
            remote_ver_str = match.group(1).lstrip("vV")
            remote_asset = patch_asset
            update_type = "patch"
        elif app_version_match:
            remote_ver_str = app_version_match.group(1)
            remote_asset = next((a for a in assets if re.fullmatch(
                r"AnyeloClip_Windows_Portable(?:_v\d+(?:\.\d+){1,3})?\.zip",
                str(a.get("name", "")), re.IGNORECASE
            )), None)
            update_type = "full"
        else:
            return fallback_res
        remote_tuple = parse_semantic_version(remote_ver_str)
        local_tuple = parse_semantic_version(VERSION)

        if remote_tuple > local_tuple:
            asset_digest = str((remote_asset or {}).get("digest") or "")
            sha256 = asset_digest.removeprefix("sha256:").strip().lower()
            download_url = str((remote_asset or {}).get("browser_download_url") or "")
            if update_type == "patch" and not re.fullmatch(r"[0-9a-f]{64}", sha256):
                logger.warning("La release no incluye SHA-256 válido para el parche; se omite la actualización.")
                return fallback_res
            if not download_url:
                return fallback_res
            logger.info(f"✨ [AutoUpdater] Nueva versión disponible: v{remote_ver_str} (Actual: v{VERSION})")
            return {
                "update_available": True,
                "current_version": VERSION,
                "latest_version": remote_ver_str,
                "type": update_type,
                "changelog": body[:500],
                "download_url": download_url,
                "release_url": data.get("html_url", UPDATE_RELEASE_PAGE),
                "sha256": sha256
            }
        else:
            return {
                "update_available": False,
                "current_version": VERSION,
                "latest_version": remote_ver_str,
                "type": "none",
                "changelog": "",
                "download_url": "",
                "sha256": ""
            }
    except Exception as e:
        logger.debug(f"Aviso: check_for_updates no pudo contactar el servidor de releases: {e}")
        return fallback_res


def apply_patch_update(download_url: str, expected_sha256: str) -> Dict[str, Any]:
    """
    Descarga, valida criptográficamente y aplica un parche de actualización:
    1. Descarga el zip en runtime_buffer/update_patch.zip.
    2. Comprueba el hash SHA256 (aborta y elimina si difiere).
    3. Inspecciona cada archivo contra lista blanca (.py, .html, .js, .css)
       y bloquea path traversal (..) y archivos protegidos (config.json, etc.).
    4. Respalda archivos previos en _backup_prev_version/.
    5. Extrae los archivos aprobados.
    6. Retorna {'ok': True, 'requires_restart': True}.
    """
    if not download_url or not expected_sha256:
        return {"ok": False, "error": "URL de descarga o hash SHA256 no proporcionado."}
    parsed_url = urlparse(download_url)
    if parsed_url.scheme != "https" or parsed_url.hostname != "github.com" or not parsed_url.path.startswith(TRUSTED_DOWNLOAD_PREFIX):
        return {"ok": False, "error": "La descarga no pertenece al repositorio oficial de Anyelo Clip."}
    if not re.fullmatch(r"[0-9a-fA-F]{64}", expected_sha256.strip()):
        return {"ok": False, "error": "El SHA-256 del parche no es válido."}

    runtime_dir = APP_DIR / "runtime_buffer"
    runtime_dir.mkdir(parents=True, exist_ok=True)
    patch_zip_path = runtime_dir / "update_patch.zip"

    # 1. Descarga del parche
    try:
        logger.info(f"📥 [AutoUpdater] Descargando parche desde: {download_url}")
        req = urllib.request.Request(
            download_url,
            headers={"User-Agent": f"Anyelo Clip-InAppUpdater/{VERSION}"}
        )
        downloaded = False
        try:
            with safe_urlopen(req, timeout=30.0) as response, open(patch_zip_path, "wb") as out_file:
                length_header = response.headers.get("Content-Length")
                if length_header and int(length_header) > MAX_PATCH_BYTES:
                    raise RuntimeError("El parche supera el tamaño máximo permitido.")
                total = 0
                while True:
                    block = response.read(64 * 1024)
                    if not block:
                        break
                    total += len(block)
                    if total > MAX_PATCH_BYTES:
                        raise RuntimeError("El parche supera el tamaño máximo permitido.")
                    out_file.write(block)
            downloaded = patch_zip_path.exists() and patch_zip_path.stat().st_size > 100
        except Exception as dl_err:
            raise RuntimeError(f"No se pudo descargar el parche: {dl_err}") from dl_err

        if not downloaded:
            raise RuntimeError("No se pudo descargar el archivo de parche tras intentar urllib y curl_cffi.")
    except Exception as e:
        if patch_zip_path.exists():
            patch_zip_path.unlink(missing_ok=True)
        logger.error(f"Error descargando parche de actualización: {e}")
        return {"ok": False, "error": f"Error descargando parche: {str(e)}"}

    # 2. Validación de Integridad SHA256
    sha256_hash = hashlib.sha256()
    try:
        with open(patch_zip_path, "rb") as f:
            for byte_block in iter(lambda: f.read(65536), b""):
                sha256_hash.update(byte_block)
        computed_sha = sha256_hash.hexdigest().lower()
        if computed_sha != expected_sha256.lower().strip():
            patch_zip_path.unlink(missing_ok=True)
            err_msg = f"Discrepancia de SHA256: esperado {expected_sha256[:12]}..., calculado {computed_sha[:12]}..."
            logger.error(f"❌ [AutoUpdater] {err_msg}")
            return {"ok": False, "error": err_msg}
    except Exception as e:
        if patch_zip_path.exists():
            patch_zip_path.unlink(missing_ok=True)
        return {"ok": False, "error": f"Error verificando SHA256: {str(e)}"}

    # 3. Lista blanca estricta e inspección de seguridad contra Path Traversal
    backup_dir = APP_DIR / "_backup_prev_version"
    backup_dir.mkdir(parents=True, exist_ok=True)

    extracted_count = 0
    try:
        with zipfile.ZipFile(patch_zip_path, "r") as zf:
            infolist = zf.infolist()

            # Fase de pre-auditoría
            approved_members = []
            for member in infolist:
                # Omitir directorios puros
                if member.is_dir():
                    continue

                raw_path = member.filename.replace("\\", "/")
                # Bloquear path traversal o rutas absolutas
                if ".." in raw_path.split("/") or raw_path.startswith("/") or ":" in raw_path:
                    logger.warning(f"⚠️ [AutoUpdater] Omitiendo ruta insegura en parche: {raw_path}")
                    continue

                p = Path(raw_path)
                # Validar extensión permitida
                if p.suffix.lower() not in ALLOWED_EXTENSIONS:
                    logger.warning(f"⚠️ [AutoUpdater] Omitiendo archivo con extensión no permitida: {raw_path}")
                    continue

                # Validar que no colisione con recursos protegidos
                top_part = p.parts[0] if p.parts else ""
                if top_part in PROTECTED_TARGETS or p.name in PROTECTED_TARGETS:
                    logger.warning(f"🛡️ [AutoUpdater] Omitiendo archivo protegido del sistema: {raw_path}")
                    continue

                try:
                    (APP_DIR / p).resolve().relative_to(APP_DIR.resolve())
                except ValueError:
                    logger.warning(f"⚠️ [AutoUpdater] Omitiendo destino fuera de la app: {raw_path}")
                    continue

                approved_members.append(member)

            if not approved_members:
                return {"ok": False, "error": "El parche no contiene archivos válidos de la lista blanca."}

            # Fase de Respaldo y Extracción
            for member in approved_members:
                rel_path = Path(member.filename.replace("\\", "/"))
                dest_file = APP_DIR / rel_path

                # Respaldar versión previa si existe
                if dest_file.is_file():
                    b_file = backup_dir / rel_path
                    b_file.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(dest_file, b_file)

                # Extraer archivo aprobado
                dest_file.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(member) as s_fp, open(dest_file, "wb") as d_fp:
                    shutil.copyfileobj(s_fp, d_fp)

                extracted_count += 1
                logger.info(f"📦 [AutoUpdater] Actualizado: {rel_path.as_posix()}")

        logger.info(f"✅ [AutoUpdater] Parche aplicado exitosamente ({extracted_count} archivos actualizados).")
        return {"ok": True, "requires_restart": True, "files_updated": extracted_count}

    except Exception as e:
        logger.error(f"Error extrayendo parche: {e}", exc_info=True)
        return {"ok": False, "error": f"Error aplicando parche: {str(e)}"}
    finally:
        if patch_zip_path.exists():
            try:
                patch_zip_path.unlink(missing_ok=True)
            except Exception:
                pass
