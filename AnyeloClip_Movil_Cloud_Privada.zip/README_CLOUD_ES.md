# Anyelo Clip móvil — backend privado en nube

Este paquete sirve la interfaz móvil y el backend FastAPI bajo el mismo origen HTTPS. Protege el acceso con una cuenta HTTP Basic y no expone directamente el puerto interno 8765. Está preparado para uso privado de una persona desde iPhone, no para compradores ni usuarios simultáneos.

## Necesitas

- Una VPS Linux con 4 vCPU, 8 GB de RAM y Docker Compose.
- Un dominio o subdominio cuyo registro A apunte a la IP pública de la VPS.
- Puertos TCP 80 y 443 abiertos en el firewall del proveedor.

## Despliegue

1. Sube esta carpeta a la VPS y entra en ella.
2. Crea el archivo de configuración del dominio:

   ```bash
   cp .env.example .env
   nano .env
   ```

   Cambia `ANYELO_DOMAIN` por el dominio que apunta a tu VPS.

3. Crea el acceso con una contraseña fuerte:

   ```bash
   bash preparar-acceso.sh
   ```

   El script pide la contraseña sin mostrarla y guarda solo su hash en `caddy/Caddyfile`. El usuario para entrar es `anyelo`.

4. Inicia el servidor:

   ```bash
   docker compose up -d --build
   docker compose ps
   docker compose logs -f app caddy
   ```

   Caddy obtiene el certificado HTTPS automáticamente si el DNS y los puertos están bien configurados. El primer build puede tardar varios minutos; la primera transcripción descarga el modelo de Whisper.

5. Abre `https://TU-DOMINIO` en Safari del iPhone, inicia sesión y, si quieres, usa **Compartir → Añadir a pantalla de inicio**.

## Licencias y datos

La licencia offline de Windows está ligada a su PC y no sirve en esta VPS. El servidor tiene otro ID de máquina; emite una clave para ese ID usando tu generador privado, que debe quedarse fuera de esta carpeta. La activación en el servidor es compartida por la instancia privada.

La configuración, los clips, los archivos entrantes, temporales y registros se guardan en `data/` o volúmenes Docker. Copia `data/` periódicamente.

## Límites

- Netlify solo hospeda la página estática; la app funcional abrirá desde el dominio HTTPS de la VPS.
- Este paquete aún no se ha instalado en una VPS: no se ha contratado ningún servidor ni hay una URL pública activa.
- No compartas el usuario y la contraseña con compradores. El software actual usa una cola y licencia compartidas; no implementa cuentas independientes por cliente.
- La VPS genera cargos mensuales y debe permanecer encendida.
