read -s -p "Contraseña para Anyelo Clip: " ANYELO_PASS; echo; docker run --rm caddy:2-alpine caddy hash-password --plaintext "$ANYELO_PASS"; unset ANYELO_PASS
