"""
ass_generator.py - Generador de subtítulos dinámicos .ASS para Shorts 9:16.
Produce subtítulos con formato SubStation Alpha v4.00+ compatibles con FFmpeg (libass).
Incluye:
1. Banner superior de enganche con título durante los primeros 3 segundos (Alignment=8, MarginV=150).
2. Subtítulos cinéticos en zona segura inferior-media (Alignment=2, MarginV=300) agrupados en 3-5 palabras.
"""

import os
import math
from pathlib import Path
from typing import Dict, Any, List, Optional

# Constantes de Zona Segura Universal (Shorts, TikTok, Reels)
SAFE_TOP = 0.14      # Evita barra superior / pestañas (y=0 a y=268 en 1080x1920)
SAFE_BOTTOM = 0.70   # Evita descripción y barra de progreso (y=1344 a 1920 en 1080x1920)
SAFE_LEFT = 0.06     # Evita bordes curvos (x=0 a x=64 en 1080x1920)
SAFE_RIGHT = 0.82    # Evita botones derechos Like/Comentar/Compartir (x=885 a 1080 en 1080x1920)


def chunk_words_with_cps(
    words: List[str],
    seg_start: float,
    seg_end: float,
    max_cps: float = 24.0,
    min_cps: float = 12.0
) -> List[Dict[str, Any]]:
    """
    Agrupa palabras en fragmentos cinéticos con velocidad de lectura calibrada (CPS: Caracteres por Segundo).
    Garantiza que la duración de cada fragmento sea proporcional a su longitud en caracteres,
    manteniendo la cadencia en el rango óptimo humano (14 a 22 CPS) para máxima retención.
    """
    if not words:
        return []

    # 1. Agrupar palabras en fragmentos de 2 a 4 palabras (máx ~24 caracteres)
    chunks: List[List[str]] = []
    curr_chunk: List[str] = []
    curr_len = 0

    for w in words:
        w_len = len(w)
        if curr_chunk and (len(curr_chunk) >= 4 or (curr_len + 1 + w_len) > 24):
            chunks.append(curr_chunk)
            curr_chunk = [w]
            curr_len = w_len
        else:
            curr_chunk.append(w)
            curr_len += (1 if len(curr_chunk) > 1 else 0) + w_len
    if curr_chunk:
        chunks.append(curr_chunk)

    total_duration = max(0.4, seg_end - seg_start)
    total_chars = sum(sum(len(w) for w in ch) + max(0, len(ch) - 1) for ch in chunks)
    total_chars = max(1, total_chars)

    # 2. Asignar duración proporcional al peso en caracteres de cada fragmento
    result = []
    t_cursor = seg_start
    for i, ch in enumerate(chunks):
        ch_chars = sum(len(w) for w in ch) + max(0, len(ch) - 1)
        prop_dur = total_duration * (ch_chars / total_chars)
        ch_dur = max(0.35, prop_dur)

        c_start = t_cursor
        c_end = min(seg_end, c_start + ch_dur) if i < len(chunks) - 1 else seg_end
        if c_end <= c_start:
            c_end = c_start + 0.35

        ch_text = " ".join(ch)
        actual_dur = max(0.1, c_end - c_start)
        cps = round(len(ch_text) / actual_dur, 1)

        result.append({
            "words": ch,
            "text": ch_text,
            "start": round(c_start, 3),
            "end": round(c_end, 3),
            "cps": cps
        })
        t_cursor = c_end

    return result


def format_ass_time(sec: float) -> str:
    """Convierte segundos flotantes a formato ASS (H:MM:SS.cs) con redondeo exacto de centésimas sin deriva."""
    if sec <= 0.0 or math.isnan(sec):
        return "0:00:00.00"
    total_cs = int(round(sec * 100.0))
    cs = total_cs % 100
    total_s = total_cs // 100
    s = total_s % 60
    total_m = total_s // 60
    m = total_m % 60
    h = total_m // 60
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def clean_ass_text(text: str) -> str:
    """Limpia caracteres que puedan romper la sintaxis de ASS."""
    return text.replace("{", "").replace("}", "").replace("\n", " ").strip()


def hex_to_ass_color(hex_str: Optional[str], default_ass: str = "&H00FFFFFF&") -> str:
    """Convierte '#RRGGBB' o 'RRGGBB' a formato ASS '&H00BBGGRR&'."""
    if not hex_str:
        return default_ass
    hex_clean = str(hex_str).strip().lstrip("#")
    if len(hex_clean) != 6:
        return default_ass
    r = hex_clean[0:2]
    g = hex_clean[2:4]
    b = hex_clean[4:6]
    return f"&H00{b}{g}{r}&".upper()


def remap_interval_through_segments(a: float, b: float, kept_segments: list) -> list:
    """Proyecta un intervalo [a, b] del tiempo original al tiempo concatenado."""
    mapped = []
    cum = 0.0
    for seg in kept_segments:
        s, e = float(seg["start"]), float(seg["end"])
        dur = max(0.0, e - s)
        ia, ib = max(a, s), min(b, e)
        if ib > ia + 1e-4:
            mapped.append((cum + (ia - s), cum + (ib - s)))
        cum += dur
    return mapped


def generate_ass_subtitles(
    clip_metadata: Dict[str, Any],
    output_ass_path: Path,
    custom_title: Optional[str] = None,
    start_trim: float = 0.0,
    end_trim: Optional[float] = None,
    show_banner: bool = True,
    banner_color: Optional[str] = None,
    show_progress_bar: bool = True,
    progress_bar_color: Optional[str] = "#00D7FF",
    watermark_text: Optional[str] = None,
    watermark_position: str = "top_right",
    subtitle_base_color: Optional[str] = "#FFFFFF",
    subtitle_highlight_color: Optional[str] = "#FFE600",
    subtitle_font_size: Optional[int] = 58,
    subtitle_margin_v: Optional[int] = 300,
    kept_segments: Optional[List[Dict[str, float]]] = None
) -> Path:
    """
    Genera el archivo .ass con los estilos y eventos configurados.
    Incluye:
    - Banner superior de impacto (0s a 3s) con color de destaque configurable.
    - Barra de progreso viral superior animada (12px en y=0, de 0px a 1080px).
    - Marca de agua fija de texto si está configurada (@handle con opacidad).
    - Subtítulos cinéticos en zona segura inferior con colores y tipografía personalizable.
    """
    output_ass_path = Path(output_ass_path)
    output_ass_path.parent.mkdir(parents=True, exist_ok=True)

    # Determinar título de gancho
    title = custom_title if custom_title is not None else clip_metadata.get("titulo_gancho", "¡MOMENTO DESTACADO!")
    title = clean_ass_text(title).upper()

    # Color del banner y subtítulos con márgenes de Zona Segura Universal
    banner_prim_col = hex_to_ass_color(banner_color, default_ass="&H00FFFFFF&")
    sub_base_col = hex_to_ass_color(subtitle_base_color, default_ass="&H00FFFFFF&")
    sub_high_col = hex_to_ass_color(subtitle_highlight_color, default_ass="&H0000FFFF&")
    sub_fsize = int(subtitle_font_size or 58)
    sub_margv = int(subtitle_margin_v or 300)

    # Márgenes de Zona Segura Universal (1080x1920):
    # - MarginL: 65px (evita bordes curvos y esquinas)
    # - MarginR: 194px (evita colisión con botones de Like/Comentar/Compartir en TikTok/Shorts)
    # - MarginV: >= 576px (evita descripción, sonido y barra de progreso inferior de plataformas)
    safe_margin_l = max(60, int(round(1080 * SAFE_LEFT)))
    safe_margin_r = max(180, int(round(1080 * (1.0 - SAFE_RIGHT))))
    safe_margin_v = max(int(round(1920 * (1.0 - SAFE_BOTTOM))), sub_margv)

    font_name = "Arial" if os.name == "nt" else "DejaVu Sans"
    header = f"""[Script Info]
; Script generated by Antigravity Anyelo Clip (Stage 2 & 4 Final)
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Banner,{font_name},54,{banner_prim_col},&H00000000,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,3,3,0,8,60,60,150,1
Style: Viral,{font_name},{sub_fsize},{sub_high_col},&H00000000,&H00000000,&HA0000000,-1,0,0,0,100,100,0,0,1,6,3,2,{safe_margin_l},{safe_margin_r},{safe_margin_v},1
Style: Watermark,{font_name},36,&H4DFFFFFF,&H00000000,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,2,1,9,40,40,50,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""

    dialogue_lines: List[str] = []

    has_multi_segments = isinstance(kept_segments, list) and len(kept_segments) > 1
    if has_multi_segments:
        clean_kept = sorted(kept_segments, key=lambda s: float(s["start"]))
        clip_dur = sum(max(0.0, float(s["end"]) - float(s["start"])) for s in clean_kept)
        clip_dur = max(0.5, clip_dur)
        effective_end = clip_dur
    else:
        if isinstance(kept_segments, list) and len(kept_segments) == 1:
            start_trim = float(kept_segments[0].get("start", start_trim))
            end_trim = float(kept_segments[0].get("end", end_trim)) if kept_segments[0].get("end") is not None else end_trim
        effective_end = (end_trim - start_trim) if end_trim else None
        clip_dur = effective_end if effective_end else float(clip_metadata.get("duration", 30.0))
        clip_dur = max(0.5, clip_dur)

    dur_ms = int(round(clip_dur * 1000))
    end_clip_str = format_ass_time(clip_dur)

    # 1. Evento Banner Superior (0s a 3s) si está habilitado
    if show_banner and title:
        banner_start = format_ass_time(0.0)
        banner_end = format_ass_time(min(clip_dur, 3.0))
        dialogue_lines.append(
            f"Dialogue: 1,{banner_start},{banner_end},Banner,,0,0,0,,{{\\fade(150,300)}}{title}"
        )

    # 2. Barra de Progreso Viral Superior (12px en y=0 de 0 a 1080px)
    if show_progress_bar:
        bar_fill_color = hex_to_ass_color(progress_bar_color, default_ass="&H00D7FF&")
        # Pista de fondo oscura
        dialogue_lines.append(
            f"Dialogue: 3,0:00:00.00,{end_clip_str},Banner,,0,0,0,,{{\\pos(0,0)\\an7\\bord0\\shad0\\p1\\1c&H202020&\\1a&H80&}}m 0 0 l 1080 0 l 1080 12 l 0 12{{\\p0}}"
        )
        # Relleno animado suave
        dialogue_lines.append(
            f"Dialogue: 4,0:00:00.00,{end_clip_str},Banner,,0,0,0,,{{\\pos(0,0)\\an7\\bord0\\shad0\\clip(0,0,0,12)\\t(0,{dur_ms},\\clip(0,0,1080,12))\\p1\\1c{bar_fill_color}\\1a&H00&}}m 0 0 l 1080 0 l 1080 12 l 0 12{{\\p0}}"
        )

    # 3. Marca de Agua de Texto fija (0% costo de CPU)
    if watermark_text:
        clean_wm = clean_ass_text(watermark_text)
        if clean_wm:
            pos_tag = "\\pos(1020,50)\\an9"
            if watermark_position == "top_left":
                pos_tag = "\\pos(60,50)\\an7"
            elif watermark_position == "bottom_center":
                pos_tag = "\\pos(540,1440)\\an2"
            
            dialogue_lines.append(
                f"Dialogue: 2,0:00:00.00,{end_clip_str},Watermark,,0,0,0,,{{{pos_tag}\\c&H4DFFFFFF&\\bord2\\shad1}}{clean_wm}"
            )

    # 2. Eventos Subtítulos Inferiores (Chunks de 3 a 5 palabras)
    transcription = clip_metadata.get("transcription")
    segments = []
    if isinstance(transcription, dict):
        segments = transcription.get("segments", [])
    elif isinstance(transcription, list):
        segments = transcription

    if not segments:
        segments = clip_metadata.get("segments") or clip_metadata.get("transcripcion_segmentos") or []

    if segments:
        # Detectar si los segmentos vienen con offset absoluto del video completo
        source_start_offset = 0.0
        meta_start = float(clip_metadata.get("start_sec", 0.0) or clip_metadata.get("start_time", 0.0) or 0.0)
        first_seg_start = float(segments[0].get("start", 0.0)) if segments else 0.0
        if meta_start > 0.0 and first_seg_start >= (meta_start - 0.5):
            source_start_offset = meta_start

        for seg in segments:
            raw_s = float(seg.get("start", 0.0))
            raw_e = float(seg.get("end", raw_s + 2.0))
            orig_s = max(0.0, raw_s - source_start_offset)
            orig_e = max(orig_s + 0.1, raw_e - source_start_offset)
            seg_text = clean_ass_text(seg.get("text", ""))
            words = seg_text.split()
            if not words:
                continue

            if has_multi_segments:
                mapped_intervals = remap_interval_through_segments(orig_s, orig_e, clean_kept)
            else:
                s_shifted = orig_s - start_trim
                e_shifted = orig_e - start_trim
                if e_shifted <= 0 or (effective_end and s_shifted >= effective_end):
                    mapped_intervals = []
                else:
                    s_clamped = max(0.0, s_shifted)
                    e_clamped = min(effective_end, e_shifted) if effective_end else e_shifted
                    if e_clamped > s_clamped + 1e-4:
                        mapped_intervals = [(s_clamped, e_clamped)]
                    else:
                        mapped_intervals = []

            for (seg_start, seg_end) in mapped_intervals:
                # Clampeo de seguridad estricto a 0.00 y clip_dur
                seg_start = max(0.0, float(seg_start))
                seg_end = min(clip_dur, max(seg_start + 0.05, float(seg_end)))

                # Agrupar en chunks calibrados por CPS dinámico y proporcional
                timed_chunks = chunk_words_with_cps(words, seg_start, seg_end, max_cps=24.0, min_cps=12.0)

                for chunk_info in timed_chunks:
                    chunk_words = chunk_info["words"]
                    chunk_text = chunk_info["text"].upper()
                    c_start = max(0.0, float(chunk_info["start"]))
                    c_end = min(clip_dur, max(c_start + 0.05, float(chunk_info["end"])))
                    
                    # Resaltar la primera o palabra clave con color primario/resaltado sobre color base
                    if len(chunk_words) > 1:
                        first_w = chunk_words[0].upper()
                        rest_w = " ".join(chunk_words[1:]).upper()
                        chunk_display = f"{{\\c{sub_high_col}}}{first_w}{{\\c{sub_base_col}}} {rest_w}"
                    else:
                        chunk_display = f"{{\\c{sub_high_col}}}{chunk_text}"

                    t_start_str = format_ass_time(c_start)
                    t_end_str = format_ass_time(c_end)
                    dialogue_lines.append(
                        f"Dialogue: 0,{t_start_str},{t_end_str},Viral,,0,0,0,,{{\\fad(80,80)}}{chunk_display}"
                    )
    else:
        # Si no hay transcripción segmentada pero hay texto general
        full_text = ""
        if isinstance(transcription, str):
            full_text = transcription
        elif isinstance(transcription, dict):
            full_text = transcription.get("text", "")

        words = clean_ass_text(full_text).split()
        if words:
            clip_dur = float(clip_metadata.get("duration", 30.0))
            if effective_end:
                clip_dur = effective_end
            
            timed_chunks = chunk_words_with_cps(words, 0.0, clip_dur, max_cps=24.0, min_cps=12.0)

            for chunk_info in timed_chunks:
                chunk_text = chunk_info["text"].upper()
                c_start = chunk_info["start"]
                c_end = chunk_info["end"]

                t_start_str = format_ass_time(c_start)
                t_end_str = format_ass_time(c_end)
                dialogue_lines.append(
                    f"Dialogue: 0,{t_start_str},{t_end_str},Viral,,0,0,0,,{{\\fad(80,80)}}{chunk_text}"
                )

    full_content = header + "\n".join(dialogue_lines) + "\n"
    output_ass_path.write_text(full_content, encoding="utf-8")
    return output_ass_path
