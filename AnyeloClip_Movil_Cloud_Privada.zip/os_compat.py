"""
os_compat.py - Capa de Compatibilidad Multiplataforma (Linux + Windows 10/11) para Anyelo Clip.
Centraliza la resolución de directorios volátiles (RAM/TEMP), rutas de binarios portables (FFmpeg, yt-dlp, Node),
gestión y exterminio limpio de árboles de procesos, flags de baja prioridad y escape de rutas ASS.
"""

import os
import sys

# Erradicar crash nativo 0xC0000005 (-1073741819) por conflicto OpenMP/MKL o falta de AVX2
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "2")
os.environ.setdefault("MKL_NUM_THREADS", "2")
os.environ.setdefault("CT2_USE_EXPERIMENTAL_PACKED_GEMM", "0")

import signal
import shutil
import logging
import tempfile
import threading
import subprocess
from pathlib import Path
from typing import Dict, Any, List, Optional, Union

logger = logging.getLogger("os_compat")

IS_WIN = (os.name == "nt")
BASE_DIR = Path(__file__).resolve().parent
BIN_DIR = BASE_DIR / "bin"

# Asegurar que las carpetas bin y Scripts de la app portable estén al frente de PATH
_portable_paths = [
    str((BASE_DIR / "bin").resolve()),
    str((BASE_DIR / "python_win" / "Scripts").resolve()),
    str((BASE_DIR / "python_win").resolve()),
]
_current_path = os.environ.get("PATH", "")
_valid_portable = [p for p in _portable_paths if os.path.exists(p)]
if _valid_portable:
    os.environ["PATH"] = os.pathsep.join(_valid_portable) + os.pathsep + _current_path


def get_shm_dir() -> Path:
    """
    Retorna el directorio de buffer rápido en memoria volátil o temporal:
    - En Linux: /dev/shm/live_clipper (si /dev/shm está disponible) o tempfile.
    - En Windows: <BASE_DIR>/runtime_buffer (portable, dentro del proyecto).
    Garantiza que el directorio exista.
    """
    if IS_WIN:
        # Portable: buffer dentro de la propia carpeta del proyecto
        target = BASE_DIR / "runtime_buffer"
    else:
        if Path("/dev/shm").exists() and os.access("/dev/shm", os.W_OK):
            target = Path("/dev/shm/live_clipper")
        else:
            target = Path(tempfile.gettempdir()) / "live_clipper_shm"
            
    try:
        target.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        logger.warning(f"Error creando directorio SHM {target}: {e}")
    return target


def get_ring_buffer_dir() -> Path:
    """Retorna el directorio dedicado para los fragmentos .ts del anillo en RAM."""
    rb = get_shm_dir() / "live_ring_buffer"
    rb.mkdir(parents=True, exist_ok=True)
    return rb


def get_shm_path(filename: str) -> Path:
    """Retorna una ruta absoluta para un archivo temporal dentro del directorio SHM."""
    return get_shm_dir() / filename


def get_python_cmd() -> str:
    """Retorna la ruta al ejecutable de Python (prioriza python_win local si existe)."""
    local_py = BASE_DIR / "python_win" / ("python.exe" if IS_WIN else "python")
    if local_py.is_file():
        return str(local_py.resolve())
    return sys.executable


def get_media_binary_path(name: str) -> str:
    """
    Busca un binario ejecutable (ffmpeg, ffprobe, etc.) dentro de la carpeta del proyecto:
    prioriza BASE_DIR, bin/, ffmpeg/, tools/ antes de recurrir al PATH del sistema.
    """
    search_dirs = [
        BASE_DIR / "bin",
        BASE_DIR,
        BASE_DIR / "ffmpeg" / "bin",
        BASE_DIR / "ffmpeg",
        BASE_DIR / "tools" / "bin",
        BASE_DIR / "tools",
    ]
    if IS_WIN:
        for d in search_dirs:
            for cand in [d / f"{name}.exe", d / name]:
                if cand.is_file():
                    return str(cand.resolve())
        which_path = shutil.which(f"{name}.exe") or shutil.which(name)
        if which_path:
            return str(Path(which_path).resolve())
        return f"{name}.exe"
    else:
        for d in search_dirs:
            cand = d / name
            if cand.is_file() and os.access(cand, os.X_OK):
                return str(cand.resolve())
        which_path = shutil.which(name)
        if which_path:
            return str(Path(which_path).resolve())
        return name


def get_binary_path(name: str) -> str:
    """
    Resuelve la ruta ejecutable de un binario buscando en carpetas portables y en PATH.
    """
    return get_media_binary_path(name)


def get_ffmpeg_cmd() -> str:
    """Ruta ejecutable para FFmpeg."""
    return get_media_binary_path("ffmpeg")


def get_ffprobe_cmd() -> str:
    """Ruta ejecutable para FFprobe."""
    return get_media_binary_path("ffprobe")


def get_streamlink_cmd() -> List[str]:
    """
    Resuelve el comando ejecutable para streamlink de forma portable:
    1. Prioriza [python, "-m", "streamlink"] si el módulo streamlink está disponible.
    2. O el .exe en Scripts/ o bin/ del proyecto portable.
    3. O shutil.which('streamlink').
    4. Fallback [python, "-m", "streamlink"].
    """
    py_exe = get_python_cmd()

    # 1. Comprobar si streamlink está disponible como módulo Python
    has_module = False
    try:
        import streamlink  # noqa: F401
        has_module = True
    except ImportError:
        site_packages = BASE_DIR / "python_win" / "Lib" / "site-packages" / "streamlink"
        if site_packages.is_dir():
            has_module = True

    if has_module:
        return [py_exe, "-m", "streamlink"]

    # 2. Buscar ejecutable en Scripts/ o bin/ o tools/
    search_dirs = [
        BASE_DIR / "python_win" / "Scripts",
        BASE_DIR / "Scripts",
        BASE_DIR / "bin",
        BASE_DIR / "tools",
        BASE_DIR,
    ]
    for d in search_dirs:
        for cand in [d / "streamlink.exe", d / "streamlink"]:
            if cand.is_file() and (not IS_WIN or cand.suffix.lower() == ".exe" or os.access(cand, os.X_OK)):
                return [str(cand.resolve())]

    # 3. Buscar en el PATH
    which_path = shutil.which("streamlink") or (shutil.which("streamlink.exe") if IS_WIN else None)
    if which_path:
        return [str(Path(which_path).resolve())]

    # 4. Fallback
    return [py_exe, "-m", "streamlink"]


def get_ytdlp_cmd() -> List[str]:
    """
    Resuelve el comando para ejecutar yt-dlp de forma portable:
    1. Prioriza [python, "-m", "yt_dlp"] si el módulo está disponible.
    2. O el .exe en bin/, Scripts/, tools/ o BASE_DIR de la carpeta portable.
    3. O shutil.which('yt-dlp').
    4. Fallback [python, "-m", "yt_dlp"].
    """
    py_exe = get_python_cmd()

    # 1. Comprobar si yt_dlp está disponible como módulo Python
    has_module = False
    try:
        import yt_dlp  # noqa: F401
        has_module = True
    except ImportError:
        site_packages = BASE_DIR / "python_win" / "Lib" / "site-packages" / "yt_dlp"
        if site_packages.is_dir():
            has_module = True

    if has_module:
        return [py_exe, "-m", "yt_dlp"]

    # 2. Buscar ejecutable en bin/, Scripts/, tools/ o BASE_DIR
    search_dirs = [
        BASE_DIR / "bin",
        BASE_DIR / "python_win" / "Scripts",
        BASE_DIR / "Scripts",
        BASE_DIR / "tools",
        BASE_DIR,
    ]
    for d in search_dirs:
        for cand in [d / "yt-dlp.exe", d / "yt-dlp"]:
            if cand.is_file() and (not IS_WIN or cand.suffix.lower() == ".exe" or os.access(cand, os.X_OK)):
                return [str(cand.resolve())]

    # 3. Buscar en el PATH
    which_path = shutil.which("yt-dlp") or (shutil.which("yt-dlp.exe") if IS_WIN else None)
    if which_path:
        return [str(Path(which_path).resolve())]

    # 4. Fallback
    return [py_exe, "-m", "yt_dlp"]


def get_deno_path() -> Optional[str]:
    """
    Resuelve la ruta al runtime de Deno (usado por yt-dlp para resolver firmas JS de YouTube).
    Prioriza bin/deno.exe portable.
    """
    local_deno = BIN_DIR / ("deno.exe" if IS_WIN else "deno")
    if local_deno.is_file() and (not IS_WIN or local_deno.suffix.lower() == ".exe" or os.access(local_deno, os.X_OK)):
        return str(local_deno.resolve())

    which_deno = shutil.which("deno.exe" if IS_WIN else "deno")
    if which_deno:
        return str(Path(which_deno).resolve())

    return None


def get_node_path() -> Optional[str]:
    """
    Resuelve la ruta al runtime de Node.js (usado por yt-dlp para resolver firmas JS de YouTube).
    Retorna None si no está instalado.
    """
    # 1. Chequear carpeta bin local
    local_node = BIN_DIR / ("node.exe" if IS_WIN else "node")
    if local_node.is_file():
        return str(local_node.resolve())

    # 2. Chequear PATH
    which_node = shutil.which("node")
    if which_node:
        return str(Path(which_node).resolve())

    # 3. Ubicaciones comunes en Linux
    if not IS_WIN:
        known_linux_paths = [
            "/home/snow/.proto/bin/node",
            "/usr/bin/node",
            "/usr/local/bin/node",
            os.path.expanduser("~/.nvm/current/bin/node")
        ]
        for p in known_linux_paths:
            path_obj = Path(p)
            if path_obj.is_file() and os.access(path_obj, os.X_OK):
                return str(path_obj.resolve())

    return None


def build_ytdlp_js_runtime_args(url: Optional[str] = None) -> List[str]:
    """
    Retorna los argumentos `--js-runtimes <deno|node>` y `--cookies` para yt-dlp.
    PARCHE RAM v2.2: Solo agrega --js-runtimes cuando la URL es de YouTube.
    Para Twitch, Kick y TikTok, omite --js-runtimes para no cargar deno.exe en RAM.
    """
    args = []
    # Solo cargar Deno/Node JS runtime para YouTube (donde es necesario para firmas JS)
    is_youtube = False
    if url:
        u = url.strip().lower()
        is_youtube = ("youtube.com" in u or "youtu.be" in u)
    elif url is None:
        # Compatibilidad hacia atras: si no se pasa url, asumir YouTube
        is_youtube = True

    if is_youtube:
        deno_p = get_deno_path()
        if deno_p:
            args.extend(["--js-runtimes", f"deno:{deno_p}"])
        else:
            node_p = get_node_path()
            if node_p:
                args.extend(["--js-runtimes", f"node:{node_p}"])

    cookies_file = BASE_DIR / "cookies.txt"
    if cookies_file.is_file() and cookies_file.stat().st_size > 0:
        args.extend(["--cookies", str(cookies_file.resolve())])

    return args


def kill_process_tree(pid):
    """
    Mata de forma exhaustiva el árbol completo de procesos (padre + todos los hijos):
    Acepta tanto un PID entero como un objeto subprocess.Popen.
    - En Windows: intenta primero proc.terminate() con espera breve (1.5s) y luego
      taskkill /F /T /PID oculto con CREATE_NO_WINDOW.
    - En Linux: utiliza psutil para terminar recursivamente todos los hijos + padre,
      con fallback a SIGKILL sobre el grupo de procesos `os.killpg(pgid)`.
    """
    if hasattr(pid, "pid"):
        pid = pid.pid
    if not pid or not isinstance(pid, int) or pid <= 0:
        return

    if IS_WIN:
        sub_flags = get_subprocess_flags(no_window=True)
        # 1. Intento cooperativo con psutil
        try:
            import psutil
            parent = psutil.Process(pid)
            children = parent.children(recursive=True)
            for child in children:
                try:
                    child.terminate()
                except Exception:
                    pass
            parent.terminate()
            gone, alive = psutil.wait_procs(children + [parent], timeout=1.5)
            if not alive:
                return
        except Exception:
            pass

        # 2. Forzado oculto con taskkill
        try:
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(pid)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=5,
                **sub_flags
            )
        except Exception as e:
            logger.debug(f"taskkill error para PID {pid}: {e}")
    else:
        try:
            import psutil
            parent = psutil.Process(pid)
            children = parent.children(recursive=True)
            for child in children:
                try:
                    child.kill()
                except Exception:
                    pass
            parent.kill()
        except Exception:
            try:
                pgid = os.getpgid(pid)
                os.killpg(pgid, signal.SIGKILL)
            except Exception:
                try:
                    os.kill(pid, signal.SIGKILL)
                except Exception:
                    pass


def kill_orphans_safety():
    """
    Barrido de seguridad contra procesos huérfanos de FFmpeg, yt-dlp y streamlink:
    - En Windows: ejecuta taskkill por nombre de imagen.
    - En Linux: ejecuta pkill sobre descriptores de ring buffer, yt-dlp y streamlink.
    """
    if IS_WIN:
        for proc_name in ["yt-dlp.exe", "ffmpeg.exe", "streamlink.exe"]:
            try:
                subprocess.run(
                    ["taskkill", "/F", "/IM", proc_name],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=3
                )
            except Exception:
                pass
    else:
        try:
            subprocess.run(["pkill", "-9", "-f", "live_ring_buffer"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            subprocess.run(["pkill", "-9", "-f", "seg_%03d.ts"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            subprocess.run(["pkill", "-9", "-f", "yt-dlp"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            subprocess.run(["pkill", "-9", "-f", "streamlink"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            subprocess.run(["pkill", "-9", "-f", "googlevideo.com"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass


def get_subprocess_flags(low_priority: bool = False, no_window: bool = True, new_session: bool = False) -> Dict[str, Any]:
    """
    Retorna kwargs compatibles para subprocess.Popen y subprocess.run:
    - En Windows: maneja `creationflags` (CREATE_NO_WINDOW, CREATE_NEW_PROCESS_GROUP, BELOW_NORMAL_PRIORITY_CLASS).
    - En Linux: maneja `start_new_session=True` para aislar grupos de procesos.
    """
    if IS_WIN:
        flags = 0
        if no_window:
            flags |= 0x08000000  # CREATE_NO_WINDOW (evita popups negros de CMD)
        if new_session:
            flags |= subprocess.CREATE_NEW_PROCESS_GROUP  # Permite matar el árbol sin cerrar la app padre
        if low_priority:
            flags |= 0x00004000  # BELOW_NORMAL_PRIORITY_CLASS
        return {"creationflags": flags}
    else:
        kwargs: Dict[str, Any] = {}
        if new_session:
            kwargs["start_new_session"] = True
        return kwargs


def set_low_priority():
    """Ajusta la prioridad del hilo o proceso actual para no congelar la máquina del usuario."""
    if IS_WIN:
        try:
            import psutil
            p = psutil.Process(os.getpid())
            p.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
        except Exception:
            pass
    else:
        try:
            os.nice(10)
        except Exception:
            pass


def escape_ass_path(ass_path: Union[str, Path]) -> str:
    """
    Escapa de forma segura la ruta de un archivo .ass para el filtro `ass='ruta'` de FFmpeg:
    - Si es ruta relativa simple (ej: 'sub_123.ass'): la mantiene relativa para ejecución con cwd.
    - Si es ruta absoluta en Windows: Convierte barras invertidas a `/`, y escapa los dos puntos `:` de la unidad (ej: `C\\:/Users/...`).
    - En Linux: Normaliza barras y escapa comillas.
    """
    p = Path(ass_path) if not isinstance(ass_path, Path) else ass_path
    if not p.is_absolute():
        s = p.as_posix()
    else:
        try:
            s = p.resolve().as_posix()
        except Exception:
            s = p.as_posix()

    # Si hay letra de unidad de disco en Windows (ej: C:/), escapar los dos puntos para FFmpeg
    if len(s) >= 2 and s[0].isalpha() and s[1] == ':':
        s = f"{s[0]}\\:{s[2:]}"

    # Escapar comillas simples internas si existen
    s = s.replace("'", r"\'")
    return s


def clean_dir_patterns(directory: Path, patterns: List[str]):
    """Borra de forma segura archivos temporales que coincidan con los patrones indicados."""
    if not directory.exists():
        return
    for pat in patterns:
        try:
            for f in directory.glob(pat):
                try:
                    if f.is_file():
                        f.unlink()
                except Exception:
                    pass
        except Exception:
            pass


def clean_incomplete_whisper_cache():
    """Limpia archivos .incomplete o temporales en la caché de faster-whisper para evitar modelos corruptos."""
    hf_home = os.environ.get("HF_HOME")
    cache_dirs = []
    if hf_home:
        cache_dirs.append(Path(hf_home))
    user_home = Path.home()
    cache_dirs.extend([
        user_home / ".cache" / "huggingface" / "hub",
        BASE_DIR / "models",
    ])
    for c_dir in cache_dirs:
        if c_dir.is_dir():
            try:
                for f in c_dir.rglob("*.incomplete"):
                    try:
                        f.unlink(missing_ok=True)
                        logger.info(f"🧹 Archivo corrupto de caché eliminado: {f}")
                    except Exception:
                        pass
                for f in c_dir.rglob("*.tmp"):
                    try:
                        f.unlink(missing_ok=True)
                    except Exception:
                        pass
            except Exception as e:
                logger.debug(f"Error limpiando caché HuggingFace: {e}")


def resolve_safe_whisper_profile() -> Dict[str, Any]:
    """
    Determina un perfil seguro y compatible de faster-whisper para la máquina actual.
    Para erradicar crashes nativos 0xC0000005 (-1073741819) en Windows (conflicto MKL/OMP o falta de AVX2):
    1. Si ya existe 'whisper_verified_profile' en config.json, lo devuelve directamente sin re-escanear.
    2. Si no existe, prueba perfiles en cascada ejecutando una sonda rápida en un SUBPROCESO AISLADO:
       - 1) small / int8
       - 2) small / float32 + CT2_FORCE_CPU_ISA=GENERIC
       - 3) base / float32 + CT2_FORCE_CPU_ISA=GENERIC
       - 4) tiny / float32 + CT2_FORCE_CPU_ISA=GENERIC
    3. El primer perfil cuyo subproceso retorne exitcode 0 se guarda en config.json para arranques futuros.
    """
    try:
        from config_manager import load_config, save_config
        cfg = load_config()
        verified = cfg.get("whisper_verified_profile")
        if isinstance(verified, dict) and "model_size" in verified and "compute_type" in verified:
            return verified
    except Exception as e:
        logger.warning(f"Error consultando config para whisper_verified_profile: {e}")

    logger.info("🔍 [Whisper Probe] Verificando perfil seguro de faster-whisper en subproceso aislado...")
    candidates = [
        {"model_size": "small", "compute_type": "int8", "force_isa": None},
        {"model_size": "small", "compute_type": "float32", "force_isa": "GENERIC"},
        {"model_size": "base", "compute_type": "float32", "force_isa": "GENERIC"},
        {"model_size": "tiny", "compute_type": "float32", "force_isa": "GENERIC"},
    ]

    py_exe = get_python_cmd()
    chosen = None

    for cand in candidates:
        m_size = cand["model_size"]
        c_type = cand["compute_type"]
        f_isa = cand["force_isa"]

        env = os.environ.copy()
        env["KMP_DUPLICATE_LIB_OK"] = "TRUE"
        env["OMP_NUM_THREADS"] = "2"
        env["MKL_NUM_THREADS"] = "2"
        env["CT2_USE_EXPERIMENTAL_PACKED_GEMM"] = "0"
        if f_isa:
            env["CT2_FORCE_CPU_ISA"] = f_isa
        elif "CT2_FORCE_CPU_ISA" in env:
            del env["CT2_FORCE_CPU_ISA"]

        probe_code = (
            "import os, sys\n"
            "from faster_whisper import WhisperModel\n"
            f"m = WhisperModel('{m_size}', device='cpu', compute_type='{c_type}', cpu_threads=2)\n"
            "sys.exit(0)\n"
        )

        sub_flags = get_subprocess_flags(no_window=True)
        try:
            res = subprocess.run(
                [py_exe, "-c", probe_code],
                env=env,
                capture_output=True,
                timeout=25,
                **sub_flags
            )
            if res.returncode == 0:
                chosen = cand
                logger.info(f"✅ [Whisper Probe] Perfil verificado con éxito: {m_size} / {c_type} (ISA: {f_isa or 'auto'})")
                break
            else:
                ret_hex = hex(res.returncode & 0xFFFFFFFF)
                logger.warning(f"⚠️ [Whisper Probe] Falló perfil {m_size}/{c_type} (code {res.returncode} / {ret_hex})")
                if m_size == "small":
                    clean_incomplete_whisper_cache()
        except subprocess.TimeoutExpired:
            logger.warning(f"⚠️ [Whisper Probe] Timeout sondeando {m_size}/{c_type}")
            if m_size == "small":
                clean_incomplete_whisper_cache()
        except Exception as e:
            logger.warning(f"⚠️ [Whisper Probe] Error sondeando {m_size}/{c_type}: {e}")
            if m_size == "small":
                clean_incomplete_whisper_cache()

    if not chosen:
        chosen = {"model_size": "tiny", "compute_type": "float32", "force_isa": "GENERIC"}
        logger.warning(f"⚠️ [Whisper Probe] Fallback universal forzado a: {chosen}")

    try:
        from config_manager import save_config
        save_config({"whisper_verified_profile": chosen})
    except Exception as e:
        logger.warning(f"No se pudo guardar whisper_verified_profile: {e}")

    return chosen


_BEST_H264_ENCODER_CACHE: Optional[str] = None
_BEST_H264_ENCODER_LOCK = threading.Lock()


def detect_best_h264_encoder(force_reprobe: bool = False) -> str:
    """
    Detecta y cachea en memoria una sola vez al arrancar el mejor codificador H.264 disponible:
    prueba h264_nvenc (NVIDIA), h264_amf (AMD) y h264_qsv (Intel) con un encode sintético de 0.2s.
    Si ninguno funciona en el hardware actual, retorna 'libx264'.
    """
    global _BEST_H264_ENCODER_CACHE
    with _BEST_H264_ENCODER_LOCK:
        if _BEST_H264_ENCODER_CACHE is not None and not force_reprobe:
            return _BEST_H264_ENCODER_CACHE

        ffmpeg_bin = get_ffmpeg_cmd()
        sub_flags = get_subprocess_flags(no_window=True)

        available_encoders_text = ""
        try:
            enc_res = subprocess.run(
                [ffmpeg_bin, "-hide_banner", "-encoders"],
                capture_output=True, text=True, timeout=5.0, **sub_flags
            )
            available_encoders_text = enc_res.stdout or ""
        except Exception as e:
            logger.debug(f"No se pudo listar encoders FFmpeg: {e}")

        candidates = [
            ("h264_nvenc", ["-pix_fmt", "yuv420p"]),
            ("h264_amf", ["-pix_fmt", "yuv420p"]),
            ("h264_qsv", ["-pix_fmt", "nv12"]),
        ]

        chosen = "libx264"
        for enc_name, extra_pix in candidates:
            if available_encoders_text and enc_name not in available_encoders_text:
                continue
            probe_out = get_shm_path(f"gpu_probe_{enc_name}.mp4")
            try:
                if probe_out.exists():
                    probe_out.unlink()
                probe_cmd = [
                    ffmpeg_bin, "-y", "-hide_banner", "-loglevel", "error",
                    "-f", "lavfi", "-i", "color=c=black:s=256x256:r=30:d=0.2",
                    "-c:v", enc_name,
                    *extra_pix,
                    str(probe_out)
                ]
                res = subprocess.run(
                    probe_cmd,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=5.0,
                    **sub_flags
                )
                if res.returncode == 0 and probe_out.exists() and probe_out.stat().st_size > 100:
                    chosen = enc_name
                    logger.info(f"⚡ [GPU Probe] Codificador hardware H.264 activo y verificado: {enc_name}")
                    break
            except Exception as e:
                logger.debug(f"[GPU Probe] {enc_name} no disponible: {e}")
            finally:
                try:
                    if probe_out.exists():
                        probe_out.unlink()
                except Exception:
                    pass

        if chosen == "libx264":
            logger.info("💻 [GPU Probe] Sin encoder GPU compatible; usando libx264 CPU optimizado.")

        _BEST_H264_ENCODER_CACHE = chosen
        return chosen
