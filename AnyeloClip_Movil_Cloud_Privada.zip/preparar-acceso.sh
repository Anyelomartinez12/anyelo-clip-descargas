#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
read -r -s -p 'Contraseña fuerte para el acceso móvil: ' ANYELO_PASS
printf '\n'
HASH="$(docker run --rm caddy:2-alpine caddy hash-password --plaintext "$ANYELO_PASS")"
unset ANYELO_PASS
sed -i "s|REEMPLAZA_ESTE_TEXTO_POR_EL_HASH_BCRYPT|$HASH|" caddy/Caddyfile
unset HASH
printf 'Acceso protegido configurado en caddy/Caddyfile. Guarda ese archivo en privado.\n'
