"""
stream_resolver.py - Resolutor Universal Multi-Plataforma de Streams (Live & VOD).
Soporta YouTube, Twitch, Kick y TikTok Live con detección automática, evasión de bloqueos
(Cloudflare TLS en Kick vía curl_cffi impersonate='chrome120', directos Twitch vía streamlink)
y alimentación optimizada para ring_buffer.py y vod_engine.py.
"""

import os
import re
import json
import logging
import shutil
import subprocess
from urllib.parse import urlparse
from typing import Dict, Any, Optional, Tuple

from os_compat import (
    get_ffmpeg_cmd, get_ffprobe_cmd, get_ytdlp_cmd, get_streamlink_cmd,
    build_ytdlp_js_runtime_args, IS_WIN
)

logger = logging.getLogger("stream_resolver")
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

# User-Agents modernos para evitar bloqueos
DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
MOBILE_UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"


def get_streamlink_quality(video_quality: str) -> str:
    """Mapea la calidad solicitada a perfiles de streamlink."""
    vq = (video_quality or "1080p").lower()
    if vq == "480p":
        return "480p,best"
    elif vq == "720p":
        return "720p60,720p,best"
    elif vq == "max":
        return "best"
    else:  # 1080p
        return "1080p60,1080p,best"


def get_ytdlp_format_filter(video_quality: str) -> str:
    """Mapea la calidad solicitada a selector de formato de yt-dlp priorizando H.264/AAC."""
    vq = (video_quality or "1080p").lower()
    if vq == "480p":
        return "bestvideo[height<=480][vcodec^=avc1]+bestaudio[acodec^=mp4a]/bestvideo[height<=480][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=480]+bestaudio/best[height<=480]/best"
    elif vq == "720p":
        return "bestvideo[height<=720][vcodec^=avc1]+bestaudio[acodec^=mp4a]/bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=720]+bestaudio/best[height<=720]/best"
    elif vq == "max":
        return "bestvideo[vcodec^=avc1]+bestaudio[acodec^=mp4a]/bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best"
    else:  # 1080p
        return "bestvideo[height<=1080][vcodec^=avc1]+bestaudio[acodec^=mp4a]/bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=1080]+bestaudio/best[height<=1080]/best"


def detect_platform(url: str) -> str:
    """
    Identifica la plataforma de transmisión a partir de la URL:
    - 'youtube'
    - 'twitch'
    - 'kick'
    - 'tiktok'
    - 'generic'
    """
    if not url:
        return "generic"
    clean_url = url.strip().lower()

    if "youtube.com" in clean_url or "youtu.be" in clean_url:
        return "youtube"
    elif "twitch.tv" in clean_url:
        return "twitch"
    elif "kick.com" in clean_url:
        return "kick"
    elif "tiktok.com" in clean_url:
        return "tiktok"
    return "generic"


def parse_channel_info(url: str) -> Dict[str, Any]:
    """
    Extrae el canal, ID de video o usuario según la plataforma.
    Twitch fuerza 'localhost' primero en embed_url para evitar bloqueos de embedding.
    Kick soporta Live y VOD con UUID.
    """
    clean_url = url.strip()
    norm_url = clean_url if clean_url.startswith(("http://", "https://")) else f"https://{clean_url}"
    platform = detect_platform(norm_url)
    result = {
        "platform": platform,
        "channel": None,
        "video_id": None,
        "is_vod": False,
        "embed_url": None,
        "raw_url": clean_url
    }

    try:
        parsed = urlparse(norm_url)
        path = parsed.path.strip("/")
        parts = [p for p in path.split("/") if p]

        if platform == "youtube":
            # YouTube VOD o Live
            m = re.search(r"(?:v=|youtu\.be/|live/|embed/|shorts/)([^&?#/]+)", clean_url)
            if m:
                result["video_id"] = m.group(1)
                result["channel"] = m.group(1)
            result["is_vod"] = "/live" not in clean_url and "/live/" not in clean_url
            if result["video_id"]:
                result["embed_url"] = f"https://www.youtube.com/embed/{result['video_id']}?autoplay=1&enablejsapi=1"

        elif platform == "twitch":
            # Twitch: twitch.tv/canal o twitch.tv/videos/123456
            # OBLIGATORIO: parent=localhost primero (Twitch bloquea 127.0.0.1)
            if len(parts) >= 2 and parts[0] == "videos":
                result["video_id"] = parts[1]
                result["is_vod"] = True
                result["embed_url"] = f"https://player.twitch.tv/?video={parts[1]}&parent=localhost&parent=127.0.0.1&autoplay=true"
            elif parts:
                result["channel"] = parts[0]
                result["is_vod"] = False
                result["embed_url"] = f"https://player.twitch.tv/?channel={parts[0]}&parent=localhost&parent=127.0.0.1&autoplay=true"

        elif platform == "kick":
            # Kick: kick.com/canal o kick.com/video/uuid o kick.com/slug/videos/uuid
            m_vod = re.search(r"(?:kick\.com/video/|kick\.com/[^/]+/videos/)([a-f0-9\-]+)", clean_url, re.IGNORECASE)
            if m_vod:
                result["video_id"] = m_vod.group(1)
                result["is_vod"] = True
                result["embed_url"] = None  # Kick no tiene iframe oficial público para VODs sin auth
            elif len(parts) >= 2 and parts[0] == "video":
                result["video_id"] = parts[1]
                result["is_vod"] = True
                result["embed_url"] = None
            elif parts:
                channel = parts[0]
                result["channel"] = channel
                result["is_vod"] = False
                result["embed_url"] = f"https://player.kick.com/{channel}?autoplay=true"

        elif platform == "tiktok":
            # TikTok: tiktok.com/@usuario/live (Siempre forzar LIVE)
            result["is_vod"] = False
            for part in parts:
                if part.startswith("@"):
                    result["channel"] = part
                    break
            result["embed_url"] = None

    except Exception as e:
        logger.warning(f"Error parseando info de canal ({url}): {e}")

    return result


def resolve_kick_m3u8(channel_slug: str) -> Optional[str]:
    """
    Resuelve el playback_url (.m3u8) de un canal en vivo de Kick usando curl_cffi con
    impersonate='chrome120' para atravesar la protección Cloudflare TLS y obtener el stream AWS IVS.
    """
    if not channel_slug:
        return None
    slug = channel_slug.strip().lstrip("@")
    if "/" in slug:
        slug = slug.split("/")[-1]

    # 1. Intento primario con curl_cffi impersonate chrome120
    try:
        from curl_cffi import requests as cffi_requests
        api_url = f"https://kick.com/api/v2/channels/{slug}"
        logger.info(f"🟢 [Kick Live] Consultando API v2 vía curl_cffi (chrome120) para '{slug}'...")
        r = cffi_requests.get(
            api_url,
            impersonate="chrome120",
            headers={
                "User-Agent": DESKTOP_UA,
                "Accept": "application/json",
                "Referer": "https://kick.com/",
                "Origin": "https://kick.com"
            },
            timeout=8
        )
        if r.status_code == 200:
            data = r.json()
            playback_url = data.get("playback_url")
            livestream = data.get("livestream")
            if playback_url:
                logger.info(f"✨ [Kick Live] Playback URL resuelta exitosamente (Live={bool(livestream)})")
                return playback_url
    except Exception as e:
        logger.warning(f"Aviso Kick API con curl_cffi (chrome120): {e}")

    # 2. Intento secundario con impersonate chrome genérico
    try:
        from curl_cffi import requests as cffi_requests
        api_url = f"https://kick.com/api/v2/channels/{slug}"
        r = cffi_requests.get(
            api_url,
            impersonate="chrome",
            headers={"User-Agent": DESKTOP_UA, "Accept": "application/json"},
            timeout=8
        )
        if r.status_code == 200:
            playback_url = r.json().get("playback_url")
            if playback_url:
                return playback_url
    except Exception:
        pass

    # 3. Intento con streamlink CLI
    try:
        st_cmd = get_streamlink_cmd()
        res = subprocess.run(
            [*st_cmd, "--stream-url", f"https://kick.com/{slug}", "best"],
            capture_output=True, text=True, timeout=8
        )
        if res.returncode == 0 and res.stdout.strip().startswith("http"):
            stream_url = res.stdout.strip().splitlines()[-1]
            logger.info(f"✨ [Kick Live] Playback URL resuelta vía streamlink: {stream_url[:60]}...")
            return stream_url
    except Exception as e:
        logger.debug(f"Aviso Kick streamlink fallback: {e}")

    # 4. Fallback yt-dlp impersonate chrome
    try:
        ytdlp = get_ytdlp_cmd()
        res = subprocess.run(
            [*ytdlp, "--no-update", "--impersonate", "chrome", "-g", "-f", "best", f"https://kick.com/{slug}"],
            capture_output=True, text=True, timeout=8
        )
        if res.returncode == 0 and res.stdout.strip().startswith("http"):
            return res.stdout.strip().splitlines()[0]
    except Exception:
        pass

    return None


def resolve_kick_vod_m3u8(video_uuid: str) -> Optional[str]:
    """
    Resuelve el master .m3u8 de un video o VOD grabado de Kick usando curl_cffi.
    Consulta https://kick.com/api/v1/video/{uuid}.
    """
    if not video_uuid:
        return None
    uuid = video_uuid.strip()

    # 1. Consultar API v1 de video de Kick
    try:
        from curl_cffi import requests as cffi_requests
        api_url = f"https://kick.com/api/v1/video/{uuid}"
        logger.info(f"🟢 [Kick VOD] Consultando API v1 para UUID '{uuid}'...")
        r = cffi_requests.get(
            api_url,
            impersonate="chrome120",
            headers={
                "User-Agent": DESKTOP_UA,
                "Accept": "application/json",
                "Referer": "https://kick.com/",
                "Origin": "https://kick.com"
            },
            timeout=8
        )
        if r.status_code == 200:
            data = r.json()
            source = data.get("source") or data.get("playback_url")
            if not source and isinstance(data.get("video"), dict):
                source = data.get("video", {}).get("playback_url") or data.get("video", {}).get("source")
            if source:
                logger.info(f"✨ [Kick VOD] URL master.m3u8 resuelta exitosamente: {source[:60]}...")
                return source
    except Exception as e:
        logger.warning(f"Aviso Kick VOD API v1 con curl_cffi: {e}")

    # 2. Fallback con yt-dlp
    try:
        ytdlp = get_ytdlp_cmd()
        res = subprocess.run(
            [*ytdlp, "--no-update", "--impersonate", "chrome", "-g", "-f", "best", f"https://kick.com/video/{uuid}"],
            capture_output=True, text=True, timeout=8
        )
        if res.returncode == 0 and res.stdout.strip().startswith("http"):
            return res.stdout.strip().splitlines()[0]
    except Exception:
        pass

    return None


def resolve_twitch_stream_url(url: str, video_quality: str = "1080p") -> Optional[str]:
    """
    Resuelve el stream directo de Twitch.
    PARCHE RAM v2.2: Prioriza resolver la URL HLS in-process con la libreria streamlink
    (sin lanzar un segundo python.exe) para ahorrar ~80MB de RAM en Windows.
    Fallback 1: CLI streamlink --stream-url. Fallback 2: yt-dlp -g.
    """
    st_quality = get_streamlink_quality(video_quality)

    # 1. Intentar resolver HLS in-process con la libreria streamlink (CERO subprocesos)
    try:
        import streamlink as sl_lib
        logger.info(f"🟣 [Twitch] Resolviendo HLS in-process con streamlink para {url} ({st_quality})...")
        session = sl_lib.Streamlink()
        streams = session.streams(url)
        if streams:
            # Buscar la mejor calidad disponible segun preferencia
            for q in st_quality.split(","):
                q = q.strip()
                if q in streams:
                    hls_url = streams[q].url
                    logger.info(f"✨ [Twitch] HLS in-process resuelto ({q}): {hls_url[:80]}...")
                    return hls_url
            # Si ninguna de las calidades preferidas esta, tomar 'best'
            if "best" in streams:
                hls_url = streams["best"].url
                logger.info(f"✨ [Twitch] HLS in-process resuelto (best): {hls_url[:80]}...")
                return hls_url
    except ImportError:
        logger.debug("[Twitch] Libreria streamlink no disponible in-process, usando CLI.")
    except Exception as e:
        logger.warning(f"Aviso resolviendo Twitch in-process con streamlink: {e}")

    # 2. Fallback: CLI streamlink --stream-url (lanza subproceso)
    try:
        st_cmd = get_streamlink_cmd()
        logger.info(f"🟣 [Twitch] Extrayendo stream ({st_quality}) con streamlink CLI para {url}...")
        res = subprocess.run(
            [*st_cmd, "--stream-url", url, st_quality],
            capture_output=True, text=True, timeout=8
        )
        if res.returncode == 0 and res.stdout.strip().startswith("http"):
            stream_url = res.stdout.strip().splitlines()[-1]
            return stream_url
    except Exception as e:
        logger.warning(f"Aviso resolviendo Twitch con streamlink CLI: {e}")

    # 3. Fallback a yt-dlp -g (sin --js-runtimes para Twitch)
    try:
        ytdlp = get_ytdlp_cmd()
        ytdlp_fmt = get_ytdlp_format_filter(video_quality)
        res = subprocess.run(
            [*ytdlp, "--no-update", "-g", "-f", ytdlp_fmt, url],
            capture_output=True, text=True, timeout=8
        )
        if res.returncode == 0 and res.stdout.strip().startswith("http"):
            return res.stdout.strip().splitlines()[0]
    except Exception as e:
        logger.debug(f"Aviso Twitch yt-dlp fallback: {e}")

    return None


def resolve_tiktok_live_url(url: str, video_quality: str = "1080p") -> Optional[str]:
    """
    Resuelve el stream en vivo de TikTok Live usando streamlink o yt-dlp
    con cabeceras de navegador móvil/escritorio.
    """
    st_quality = get_streamlink_quality(video_quality)
    # 1. Probar con streamlink
    try:
        st_cmd = get_streamlink_cmd()
        logger.info(f"🎵 [TikTok Live] Extrayendo stream ({st_quality}) con streamlink para {url}...")
        res = subprocess.run(
            [*st_cmd, "--http-header", f"User-Agent={DESKTOP_UA}", "--stream-url", url, st_quality],
            capture_output=True, text=True, timeout=10
        )
        if res.returncode == 0 and res.stdout.strip().startswith("http"):
            return res.stdout.strip().splitlines()[-1]
    except Exception as e:
        logger.warning(f"Aviso TikTok streamlink: {e}")

    # 2. Probar con yt-dlp pasando User-Agent
    try:
        ytdlp = get_ytdlp_cmd()
        ytdlp_fmt = get_ytdlp_format_filter(video_quality)
        cmd = [
            *ytdlp, "--no-update",
            "--user-agent", DESKTOP_UA,
            "--extractor-args", "tiktok:app_version=20.2.1",
            "-g", "-f", ytdlp_fmt,
            url
        ]
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if res.returncode == 0 and res.stdout.strip().startswith("http"):
            return res.stdout.strip().splitlines()[0]
    except Exception as e:
        logger.warning(f"Aviso TikTok yt-dlp fallback: {e}")

    return None


def resolve_direct_stream_url(url: str) -> Tuple[Optional[str], str]:
    """
    Punto de entrada universal para resolver la URL directa de video (.m3u8, flv o https)
    según la plataforma detectada.
    Retorna: (stream_url, platform)
    """
    clean_url = url.strip()
    norm_url = clean_url if clean_url.startswith(("http://", "https://")) else f"https://{clean_url}"
    platform = detect_platform(norm_url)
    info = parse_channel_info(norm_url)

    if platform == "kick":
        if info.get("is_vod") and info.get("video_id"):
            m3u8 = resolve_kick_vod_m3u8(info["video_id"])
            if m3u8:
                return m3u8, platform
        slug = info.get("channel") or ""
        m3u8 = resolve_kick_m3u8(slug)
        if m3u8:
            return m3u8, platform

    elif platform == "twitch":
        stream_url = resolve_twitch_stream_url(norm_url)
        if stream_url:
            return stream_url, platform

    elif platform == "tiktok":
        stream_url = resolve_tiktok_live_url(norm_url)
        if stream_url:
            return stream_url, platform

    return None, platform


def build_ring_buffer_cmd(
    url: str,
    segment_pattern: str,
    segment_duration_sec: int = 5,
    max_segments: int = 48,
    video_quality: str = "1080p"
) -> Dict[str, Any]:
    """
    Construye la especificación del pipeline de captura para alimentar el ring buffer.
    Retorna un dict con la estrategia a ejecutar:
    - {"type": "ffmpeg_direct", "args": [...]}  → un solo proceso ffmpeg (Kick HLS, TikTok HLS)
    - {"type": "pipe", "producer_args": [...], "consumer_args": [...]}  → stdout→stdin entre dos procesos
    Aplica la mejor estrategia según la plataforma y la calidad de video solicitada.
    """
    ffmpeg = get_ffmpeg_cmd()
    ytdlp = get_ytdlp_cmd()
    platform = detect_platform(url)
    js_args_list = build_ytdlp_js_runtime_args(url=url)
    st_quality = get_streamlink_quality(video_quality)
    ytdlp_format = get_ytdlp_format_filter(video_quality)

    # Argumentos comunes del segmentador FFmpeg
    seg_args = [
        "-c", "copy", "-f", "segment",
        "-segment_time", str(segment_duration_sec),
        "-segment_wrap", str(max_segments),
        "-reset_timestamps", "1",
        segment_pattern
    ]

    ffmpeg_base = [
        ffmpeg, "-hide_banner", "-nostats", "-loglevel", "warning",
        "-avoid_negative_ts", "make_zero",
        "-fflags", "+genpts"
    ]

    # 1. KICK: Intentar resolver m3u8 directo
    if platform == "kick":
        info = parse_channel_info(url)
        m3u8_url = None
        if info.get("is_vod") and info.get("video_id"):
            m3u8_url = resolve_kick_vod_m3u8(info["video_id"])
        else:
            channel = info.get("channel")
            m3u8_url = resolve_kick_m3u8(channel)

        if m3u8_url:
            logger.info("🟢 [Kick] Usando conexión directa FFmpeg a AWS IVS HLS...")
            return {
                "type": "ffmpeg_direct",
                "args": ffmpeg_base + [
                    "-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_delay_max", "5",
                    "-headers", f"User-Agent: {DESKTOP_UA}\r\nOrigin: https://kick.com\r\nReferer: https://kick.com/\r\n",
                    "-i", m3u8_url
                ] + seg_args
            }
        # Si falló resolución m3u8, usar streamlink pipe con cabeceras de navegador
        st_cmd = get_streamlink_cmd()
        return {
            "type": "pipe",
            "producer_args": st_cmd + ["--http-header", f"User-Agent={DESKTOP_UA}", "--stdout", url, st_quality],
            "consumer_args": ffmpeg_base + ["-i", "-"] + seg_args
        }

    # 2. TWITCH: PARCHE RAM v2.2 — Resolver HLS in-process y alimentar ffmpeg directo (sin pipe)
    if platform == "twitch":
        info = parse_channel_info(url)
        if not info.get("is_vod"):
            hls_url = resolve_twitch_stream_url(url, video_quality=video_quality)
            if hls_url:
                logger.info("🟣 [Twitch] Usando conexion directa FFmpeg a HLS (sin subproceso streamlink)...")
                return {
                    "type": "ffmpeg_direct",
                    "args": ffmpeg_base + [
                        "-reconnect", "1", "-reconnect_streamed", "1",
                        "-reconnect_delay_max", "5", "-rw_timeout", "15000000",
                        "-i", hls_url
                    ] + seg_args
                }
            # Fallback: pipe con streamlink --stdout --loglevel none
            st_cmd = get_streamlink_cmd()
            logger.info(f"🟣 [Twitch] Fallback: pipe streamlink --stdout --loglevel none | ffmpeg...")
            return {
                "type": "pipe",
                "producer_args": st_cmd + ["--stdout", "--loglevel", "none", url, st_quality],
                "consumer_args": ffmpeg_base + ["-i", "-"] + seg_args
            }

    # 3. TIKTOK LIVE: Forzar directo y headers móviles/escritorio
    if platform == "tiktok":
        direct_url = resolve_tiktok_live_url(url, video_quality=video_quality)
        if direct_url:
            logger.info("🎵 [TikTok Live] Transmitiendo flujo en vivo directo a FFmpeg...")
            return {
                "type": "ffmpeg_direct",
                "args": ffmpeg_base + [
                    "-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_delay_max", "5",
                    "-headers", f"User-Agent: {DESKTOP_UA}\r\nReferer: https://www.tiktok.com/\r\n",
                    "-i", direct_url
                ] + seg_args
            }
        st_cmd = get_streamlink_cmd()
        return {
            "type": "pipe",
            "producer_args": st_cmd + ["--http-header", f"User-Agent={DESKTOP_UA}", "--stdout", url, st_quality],
            "consumer_args": ffmpeg_base + ["-i", "-"] + seg_args
        }

    # 4. YOUTUBE O GENÉRICO: Pipeline robusto con yt-dlp
    ytdlp = get_ytdlp_cmd()
    ytdlp_args = ytdlp + ["--no-update"] + js_args_list + [
        "-f", ytdlp_format,
        "--no-part", "-o", "-", url
    ]
    return {
        "type": "pipe",
        "producer_args": ytdlp_args,
        "consumer_args": ffmpeg_base + ["-i", "-"] + seg_args
    }
