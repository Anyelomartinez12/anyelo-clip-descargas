# Anyelo Clip — descarga y móvil

Página web móvil de Anyelo Clip. GitHub Pages sirve la interfaz estática y puede añadirse a la pantalla de inicio del iPhone desde Safari.

**Aviso:** las funciones de IA, radar, subida y biblioteca requieren el backend de Anyelo Clip. Este repositorio solo publica el frontend; el backend para teléfono todavía no está desplegado.

Descarga para Windows: revisa Releases.
